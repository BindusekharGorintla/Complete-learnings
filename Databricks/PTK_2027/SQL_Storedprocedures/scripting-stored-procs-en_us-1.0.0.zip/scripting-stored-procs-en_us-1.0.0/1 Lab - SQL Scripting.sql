-- Databricks notebook source
-- MAGIC %md
-- MAGIC ![DBAcademy](./Includes/images/db-academy.png)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Lab - SQL Scripting
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Overview
-- MAGIC
-- MAGIC In this lab, we will explore advanced SQL scripting techniques in Databricks to create modular, flexible, and resilient workflows. Through a series of practical exercises, you will use compound statements to organize multi-step tasks, define and apply variables for dynamic calculations, implement conditional logic for business rule processing, control data flows with looping constructs, and handle errors with robust exception management. 
-- MAGIC
-- MAGIC By the end of this lab, you will be able to build well-structured, reusable, and fault-tolerant SQL scripts for complex data analysis in Databricks.
-- MAGIC
-- MAGIC ## Learning Objectives
-- MAGIC By the end of this lab, you will be able to:
-- MAGIC
-- MAGIC - Use compound statements (`BEGIN...END`) to group multiple SQL operations
-- MAGIC - Declare and use variables to parameterize SQL logic
-- MAGIC - Implement conditional logic (`IF`, `CASE`) to branch script behavior
-- MAGIC - Use loops to repeat operations over multiple parameters
-- MAGIC - Handle errors gracefully with exception handlers
-- MAGIC
-- MAGIC
-- MAGIC **Reference Documentation:** [SQL scripting](https://docs.databricks.com/aws/en/sql/language-manual/sql-ref-scripting) 

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## REQUIRED - SELECT A COMPUTE ENVIRONMENT
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select a SQL Warehouse</strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC Before starting this notebook, select the required compute environment.
-- MAGIC - **SQL Warehouse**
-- MAGIC
-- MAGIC To select a SQL Warehouse:
-- MAGIC
-- MAGIC 1. Select the compute tile in the top-right corner of the notebook.
-- MAGIC 2. If your SQL Warehouse is already listed, select it.
-- MAGIC 3. If it is not visible, select **More** > **SQL Warehouse**, then choose your SQL Warehouse from the list.
-- MAGIC
-- MAGIC **NOTE:**  This notebook was **developed and tested using a SQL Warehouse**. Other compute options may work but are not guaranteed to behave the same or support all features demonstrated.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## A. Classroom Setup
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #1976d2;
-- MAGIC   background: #e3f2fd;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size:1.1em;">
-- MAGIC     Option 1 - Databricks Academy Provided Workspace (Vocareum Workspace)
-- MAGIC   </strong>
-- MAGIC   <details>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC If you are running this notebook in a <strong>Databricks Academy provided Vocareum workspace</strong>, your Unity Catalog catalog is already created for you.
-- MAGIC
-- MAGIC Your catalog name matches your Vocareum username and looks like: <strong>labuser12345</strong> (series of unique numbers)
-- MAGIC   </div>
-- MAGIC   </details>
-- MAGIC </div>
-- MAGIC
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #1976d2;
-- MAGIC   background: #e3f2fd;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size:1.1em;">
-- MAGIC     Option 2 - Other Workspaces or Databricks Free Edition
-- MAGIC   </strong>
-- MAGIC   <details>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC If you are running this notebook in your own Databricks workspace or Databricks Free Edition, the setup will
-- MAGIC <strong>create a Unity Catalog catalog and schema for you</strong>. **Create catalog permission is required.**
-- MAGIC
-- MAGIC The catalog name is derived from your Databricks username and follows this pattern: <strong>labuser_username</strong>
-- MAGIC   </div>
-- MAGIC   </details>
-- MAGIC </div>
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Do Not Run in Production Environments</strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC   <ul>
-- MAGIC       <li>Only run this notebook in <strong>development or sandbox workspaces</strong>.</li>
-- MAGIC       <li>Do not run this in production environments. The setup script creates a catalog and schemas in your workspace.</li>
-- MAGIC   </ul>
-- MAGIC   </div>
-- MAGIC </div>
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### A1. Configure Your Catalog and Schema
-- MAGIC
-- MAGIC 1. Run the cell below to initialize your lab environment. This setup step will:
-- MAGIC
-- MAGIC - Assume that you have **permission to create a catalog**
-- MAGIC - Create a catalog named `labuser_your_username` if running outside of a Databricks Vocareum provided Workspace
-- MAGIC - Create a schema named `sql_script_lab`
-- MAGIC - Ingest **nyctaxi** dataset into your schema 
-- MAGIC
-- MAGIC #### Troubleshooting
-- MAGIC If you do not have permission to create a new catalog but already have one available, you can explicitly specify an existing catalog by using the `catalog_forced` argument in the `build_user_catalog_name` function.
-- MAGIC
-- MAGIC This function is defined in the notebook: `./Includes/Classroom-Setup-Common`

-- COMMAND ----------

-- MAGIC %run ./Includes/Classroom-Setup-Common

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 2. In the workspace sidebar, navigate to your catalog and schema. Confirm the following:
-- MAGIC
-- MAGIC - A catalog named **labuser_your_username** exists
-- MAGIC - The catalog contains a schema named **sql_script_lab**
-- MAGIC - The schema contains a table named **trips**

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### A2. Dataset Overview
-- MAGIC
-- MAGIC **Schema:** `sql_script_lab`  
-- MAGIC **Table:** `trips`
-- MAGIC
-- MAGIC | Column | Type | Description |
-- MAGIC |--------|------|-------------|
-- MAGIC | `tpep_pickup_datetime` | timestamp | When the trip started |
-- MAGIC | `tpep_dropoff_datetime` | timestamp | When the trip ended |
-- MAGIC | `trip_distance` | double | Distance traveled in miles |
-- MAGIC | `fare_amount` | double | Fare in dollars |
-- MAGIC | `pickup_zip` | int | Pickup ZIP code |
-- MAGIC | `dropoff_zip` | int | Dropoff ZIP code |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### A3. Explore the Dataset
-- MAGIC
-- MAGIC Query a few rows of the trips table by running the following cell to see what the data looks like. 

-- COMMAND ----------

SELECT * 
FROM trips 
LIMIT 10;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now we will explore the key components of SQL Scripting in Databricks SQL one by one.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## B. Compound Statements
-- MAGIC
-- MAGIC Compound statements group multiple SQL operations into a single executable unit using `BEGIN...END` blocks. This approach:
-- MAGIC
-- MAGIC - Organizes related operations logically
-- MAGIC - Enables transaction-like behavior
-- MAGIC - Provides foundation for variables and control flow
-- MAGIC
-- MAGIC **Reference:** [Compound Statement](https://docs.databricks.com/aws/en/sql/language-manual/control-flow/compound-stmt) 
-- MAGIC
-- MAGIC **When to use:** When you have multiple related steps that should run together as a single unit.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B1. Add Unique Trip Identifier
-- MAGIC
-- MAGIC We do not have a unique trip identifier in the `trips` table. So, we'll create a temporary view and select data from `trips` table while adding a column `trip_id` in the temporary view which will act as the unique trip identifier. We'll print this view and combine all of this code in a compound statement.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC The following query will create a temporary view named `trips_with_id` that contains the same data as the `trips` table, but with an additional column `trip_id` which will act as the unique identifier for each trip.

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW------------------->
-- MAGIC CREATE OR REPLACE TEMP VIEW trips_with_id AS
-- MAGIC   SELECT
-- MAGIC     ROW_NUMBER() OVER (ORDER BY tpep_pickup_datetime, pickup_zip, dropoff_zip) AS trip_id,
-- MAGIC     tpep_pickup_datetime,
-- MAGIC     tpep_dropoff_datetime,
-- MAGIC     trip_distance,
-- MAGIC     fare_amount,
-- MAGIC     pickup_zip,
-- MAGIC     dropoff_zip
-- MAGIC   FROM trips;
-- MAGIC <!-------------------END SOLUTION CODE------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   // Preferred modern API
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC The following query will perform a select operation on the temporary view that we will create:

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW------------------->
-- MAGIC SELECT
-- MAGIC   trip_id,
-- MAGIC   tpep_pickup_datetime,
-- MAGIC   pickup_zip,
-- MAGIC   dropoff_zip,
-- MAGIC   trip_distance,
-- MAGIC   fare_amount
-- MAGIC FROM trips_with_id
-- MAGIC ORDER BY trip_id
-- MAGIC LIMIT 10;
-- MAGIC <!-------------------END SOLUTION CODE------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   // Preferred modern API
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now add these two queries in the following cell to wrap the entire logic in a single compound statement. 

-- COMMAND ----------

BEGIN
  -- Step 1: Create a temp view with a synthetic trip_id column
  -- <FILL IN>

  -- Step 2: Query the temporary view
  -- <FILL IN>
END;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now try running the above cell.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC As you can see, all the statements within `BEGIN...END` execute as a unified block, establishing the foundation for more complex procedural logic.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B2. Daily Anomaly Check
-- MAGIC
-- MAGIC Create a data quality monitoring block that can be executed for any given day before generating revenue reports.
-- MAGIC
-- MAGIC **Task:**
-- MAGIC
-- MAGIC Create a compound `BEGIN...END` block that:
-- MAGIC
-- MAGIC 1. Creates a temporary view `daily_trip_quality_tmp` containing all trips `DATE(tpep_pickup_datetime) = '2016-01-26'`
-- MAGIC 2. Inserts a summary into another temporary view `daily_quality_summary` with:
-- MAGIC    - `trip_date` (as a string: `'2016-01-26'`)
-- MAGIC    - `total_trips` (count of trips)
-- MAGIC    - `zero_distance_count` (trips where `trip_distance <= 0`)
-- MAGIC    - `negative_fare_count` (trips where `fare_amount < 0`)
-- MAGIC 3. Selects from the summary table to display results
-- MAGIC

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ##### ANSWER
-- MAGIC
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW------------------->
-- MAGIC BEGIN
-- MAGIC   -- Step 1: Create temporary table with trips for the day
-- MAGIC   CREATE OR REPLACE TEMP VIEW daily_trip_quality_tmp AS
-- MAGIC   SELECT * FROM trips
-- MAGIC   WHERE DATE(tpep_pickup_datetime) = '2016-01-26';
-- MAGIC
-- MAGIC   -- Step 2: Insert summary into a results table
-- MAGIC   CREATE OR REPLACE TEMP VIEW daily_quality_summary AS
-- MAGIC   SELECT
-- MAGIC     '2016-01-26' AS trip_date,
-- MAGIC     COUNT(*) AS total_trips,
-- MAGIC     COUNT_IF(trip_distance <= 0) AS zero_distance_count,
-- MAGIC     COUNT_IF(fare_amount < 0) AS negative_fare_count
-- MAGIC   FROM daily_trip_quality_tmp;
-- MAGIC
-- MAGIC   -- Step 3: Display results
-- MAGIC   SELECT * FROM daily_quality_summary;
-- MAGIC END;
-- MAGIC <!-------------------END SOLUTION CODE------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   // Preferred modern API
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC **Expected Output:**
-- MAGIC
-- MAGIC | trip_date | total_trips | zero_distance_count | negative_fare_count |
-- MAGIC |-----------|-------------|---------------------|---------------------|
-- MAGIC | 2016-01-26 | 306 | 1 | 1 |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## C. Variables
-- MAGIC
-- MAGIC Variables enable script parameterization, allowing the same logic to work with different inputs. This approach:
-- MAGIC
-- MAGIC - Eliminates hard-coded values
-- MAGIC - Increases script reusability
-- MAGIC - Simplifies maintenance
-- MAGIC - Reduces error-prone copy-paste operations
-- MAGIC
-- MAGIC You can use the `DECLARE` keyword to create a variable and the `SET` keyword to modify its value. 
-- MAGIC
-- MAGIC **References:** 
-- MAGIC - [Variables](https://docs.databricks.com/aws/en/sql/language-manual/sql-ref-variables)
-- MAGIC - [DECLARE VARIABLE](https://docs.databricks.com/aws/en/sql/language-manual/sql-ref-syntax-ddl-declare-variable)
-- MAGIC - [SET VARIABLE](https://docs.databricks.com/aws/en/sql/language-manual/sql-ref-syntax-aux-set-variable)
-- MAGIC
-- MAGIC **When to use:** When running similar queries with different parameters (dates, thresholds, identifiers).

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C1. Parameterized Date Filter
-- MAGIC
-- MAGIC Instead of hard-coding dates in queries, variables allow easy modification without changing the entire script logic.
-- MAGIC
-- MAGIC Run the code below:

-- COMMAND ----------

BEGIN
  DECLARE v_trip_date DATE;
  SET v_trip_date = '2016-01-26';

  SELECT
    v_trip_date AS trip_date,
    COUNT(*) AS total_trips,
    ROUND(SUM(fare_amount), 2) AS total_fare,
    ROUND(AVG(trip_distance), 2) AS avg_distance
  FROM trips
  WHERE DATE(tpep_pickup_datetime) = v_trip_date;
END;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC The variable `v_trip_date` is defined once and reused throughout the script. Modify the date in one location to update the entire query.<p>
-- MAGIC **Try it:** Change the date to `2016-01-27` and re-run the cell to see the parameterization in action.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C2. Trips Data Quality Monitoring
-- MAGIC
-- MAGIC Create a flexible trip data quality report where analysts can adjust thresholds based on their requirements.
-- MAGIC
-- MAGIC **Task:**
-- MAGIC Create a script with multiple variables that:
-- MAGIC
-- MAGIC 1. Declares:
-- MAGIC    - `v_trip_date DATE` (set to `'2016-01-26'`)
-- MAGIC    - `v_min_distance DOUBLE` (set to `0.5`)
-- MAGIC    - `v_max_distance DOUBLE` (set to `25.0`)
-- MAGIC    - `v_min_fare DOUBLE` (set to `2.5`)
-- MAGIC
-- MAGIC 2. Uses these variables in a `SELECT` statement that calculates the total number of trips and classifies them into:
-- MAGIC    - `valid_trips` – trips meeting all threshold criteria
-- MAGIC    - `short_distance_outliers` – distance < `v_min_distance`
-- MAGIC    - `long_distance_outliers` – distance > `v_max_distance`
-- MAGIC    - `negative_fare_trips` – fare < `v_min_fare`
-- MAGIC
-- MAGIC 3. Prints the summary with the bifurcation of trips

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ##### ANSWER
-- MAGIC
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW------------------->
-- MAGIC BEGIN
-- MAGIC   DECLARE v_trip_date DATE DEFAULT '2016-01-26';
-- MAGIC   DECLARE v_min_distance DOUBLE DEFAULT 0.5;
-- MAGIC   DECLARE v_max_distance DOUBLE DEFAULT 25.0;
-- MAGIC   DECLARE v_min_fare DOUBLE DEFAULT 2.5;
-- MAGIC
-- MAGIC   SELECT
-- MAGIC     v_trip_date AS trip_date,
-- MAGIC     COUNT(*) AS total_trips,
-- MAGIC     COUNT_IF(trip_distance >= v_min_distance AND trip_distance <= v_max_distance AND fare_amount >= v_min_fare) AS valid_trips,
-- MAGIC     COUNT_IF(trip_distance < v_min_distance) AS short_distance_outliers,
-- MAGIC     COUNT_IF(trip_distance > v_max_distance) AS long_distance_outliers,
-- MAGIC     COUNT_IF(fare_amount < v_min_fare) AS negative_fare_trips
-- MAGIC   FROM trips
-- MAGIC   WHERE DATE(tpep_pickup_datetime) = v_trip_date;
-- MAGIC END;
-- MAGIC <!-------------------END SOLUTION CODE------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   // Preferred modern API
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC %md
-- MAGIC
-- MAGIC **Expected Output:**
-- MAGIC
-- MAGIC | trip_date | total_trips | valid_trips | short_distance_outliers | long_distance_outliers | negative_fare_trips |
-- MAGIC |-----------|-------------|-------------|-------------------------|------------------------|---------------------|
-- MAGIC | 2016-01-26 | 306 | 289 | 17 | 0 | 1 |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## D. Conditional Logic
-- MAGIC
-- MAGIC Conditional logic lets your script make decisions based on data. Instead of running the same query every time, you can adjust thresholds, rules, or outputs based on changing conditions.
-- MAGIC
-- MAGIC You can use `CASE` or `IF THEN ELSE` statement for defining conditional logic.
-- MAGIC
-- MAGIC **References:**
-- MAGIC - [CASE statement](https://docs.databricks.com/aws/en/sql/language-manual/control-flow/case-stmt)
-- MAGIC - [IF THEN ELSE statement](https://docs.databricks.com/aws/en/sql/language-manual/control-flow/if-stmt)
-- MAGIC
-- MAGIC **When to use:** When you need to branch behavior (e.g., stricter checks during high-volume days, looser during quiet days).

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D1. Classify Trips by Distance
-- MAGIC
-- MAGIC We need a quick way to label trips as short, medium, or long distance.
-- MAGIC
-- MAGIC Run the code below:

-- COMMAND ----------

BEGIN
  SELECT
    row_number() OVER (ORDER BY tpep_pickup_datetime) AS trip_id,
    trip_distance,
    CASE
      WHEN trip_distance < 2 THEN 'SHORT'
      WHEN trip_distance <= 10 THEN 'MEDIUM'
      ELSE 'LONG'
    END AS distance_category,
    fare_amount
  FROM trips
  WHERE DATE(tpep_pickup_datetime) = '2016-01-26'
  LIMIT 10;
END;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC As we can see, the `CASE` statement classifies each trip based on distance. This is conditional logic in action.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D2. Trip Existence Check
-- MAGIC
-- MAGIC Check whether any trips exist for a given date.
-- MAGIC
-- MAGIC Run the code below:

-- COMMAND ----------

BEGIN
  DECLARE v_trip_date DATE;
  DECLARE v_trip_count INT;

  SET v_trip_date = DATE '2016-01-26';

  SET v_trip_count = (SELECT COUNT(*)
                      FROM trips
                      WHERE DATE(tpep_pickup_datetime) = v_trip_date);

  IF v_trip_count > 0 THEN
    SELECT 'Has trips' AS status;
  ELSE
    SELECT 'No trips' AS status;
  END IF;
END;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D3. Low Fare Trips
-- MAGIC
-- MAGIC You need a script that checks whether a day was busy or quiet based on the trip volume and, based on it, assigns a minimum fare threshold which will be used to flag low fare trips.
-- MAGIC
-- MAGIC **Task:**
-- MAGIC Create a script that:
-- MAGIC
-- MAGIC 1. Declares:
-- MAGIC    - `v_trip_date DATE` (set to `'2016-01-26'`)
-- MAGIC    - `v_trip_count INT` 
-- MAGIC    - `v_min_fare DOUBLE`
-- MAGIC    - `v_low_fare_count INT`
-- MAGIC
-- MAGIC 2. Computes the number of trips for `v_trip_date` into `v_trip_count`
-- MAGIC
-- MAGIC 3. Uses an `IF` or `CASE` block to set:
-- MAGIC    - `v_min_fare = 5.0` if `v_trip_count >= 1000` (busy day, strict)
-- MAGIC    - `v_min_fare = 2.5` otherwise (quiet day, lenient)
-- MAGIC
-- MAGIC 4. Computes the number of low fare trips and outputs: trip_date, trip_count, minimum fare threshold, and count of low fare trips

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ##### ANSWER
-- MAGIC
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW------------------->
-- MAGIC BEGIN
-- MAGIC   DECLARE v_trip_date DATE;
-- MAGIC   DECLARE v_trip_count INT;
-- MAGIC   DECLARE v_min_fare DOUBLE;
-- MAGIC   DECLARE v_low_fare_count INT;
-- MAGIC
-- MAGIC   SET v_trip_date = DATE '2016-01-26';
-- MAGIC
-- MAGIC   -- Count trips for that day
-- MAGIC   SET v_trip_count = (SELECT COUNT(*)
-- MAGIC                       FROM trips
-- MAGIC                       WHERE DATE(tpep_pickup_datetime) = v_trip_date);
-- MAGIC
-- MAGIC   -- Method 1: Using IF/ELSE statement 
-- MAGIC
-- MAGIC   IF v_trip_count >= 1000 THEN
-- MAGIC     SET v_min_fare = 5.0;
-- MAGIC   ELSE
-- MAGIC     SET v_min_fare = 2.5;
-- MAGIC   END IF;
-- MAGIC
-- MAGIC   -- Method 2: Using CASE...WHEN statement
-- MAGIC   
-- MAGIC     SET v_min_fare = CASE
-- MAGIC     WHEN v_trip_count >= 1000 THEN 5.0
-- MAGIC     ELSE 2.5
-- MAGIC   END;
-- MAGIC
-- MAGIC   SET v_low_fare_count = (SELECT COUNT(*)
-- MAGIC                       FROM trips
-- MAGIC                       WHERE DATE(tpep_pickup_datetime) = v_trip_date
-- MAGIC                       AND fare_amount < v_min_fare);
-- MAGIC
-- MAGIC   SELECT
-- MAGIC     v_trip_date AS trip_date,
-- MAGIC     v_trip_count AS total_trips,
-- MAGIC     v_min_fare AS applied_min_fare,
-- MAGIC     v_low_fare_count AS low_fare_trips;
-- MAGIC END;
-- MAGIC <!-------------------END SOLUTION CODE------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   // Preferred modern API
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC %md
-- MAGIC
-- MAGIC **Expected Output:**
-- MAGIC
-- MAGIC | trip_date | total_trips | applied_min_fare | low_fare_trips |
-- MAGIC |-----------|-------------|------------------|----------------|
-- MAGIC | 2016-01-26 | 306 | 2.5 | 1 |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## E. Looping
-- MAGIC
-- MAGIC Loops let you repeat similar operations over multiple parameters (dates, zones, etc.) without copy-pasting code. This makes batch operations clean and maintainable.
-- MAGIC
-- MAGIC **References:**
-- MAGIC - [LOOP statement](https://docs.databricks.com/aws/en/sql/language-manual/control-flow/loop-stmt)
-- MAGIC - [FOR statement](https://docs.databricks.com/aws/en/sql/language-manual/control-flow/for-stmt)
-- MAGIC - [WHILE statement](https://docs.databricks.com/aws/en/sql/language-manual/control-flow/while-stmt)
-- MAGIC
-- MAGIC **When to use:** When you need to process multiple dates, zones, or other parameters in sequence.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### E1. Three-Day Trip Counter
-- MAGIC
-- MAGIC Count trips for three consecutive days using a loop.
-- MAGIC
-- MAGIC Run the code below:

-- COMMAND ----------

BEGIN
  DECLARE v_current_date DATE;
  DECLARE v_end_date DATE;

  SET v_current_date = DATE '2016-01-15';
  SET v_end_date = DATE '2016-01-17';

  trip_loop:
  LOOP
    SELECT
      COUNT(*) AS total_trips
    FROM trips
    WHERE DATE(tpep_pickup_datetime) = v_current_date;

    IF v_current_date >= v_end_date THEN
      LEAVE trip_loop;
    END IF;

    SET v_current_date = DATE_ADD(v_current_date, 1);
  END LOOP trip_loop;
END;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### E2. Find First Busy Day
-- MAGIC
-- MAGIC Starting from a given date, keep moving one day forward until a “busy” day is found (e.g., at least 400 trips), or until a max date is reached.
-- MAGIC
-- MAGIC **Task:**
-- MAGIC Create a loop that:
-- MAGIC
-- MAGIC 1. Declares:
-- MAGIC    - `v_current_date DATE` (set to `'2016-01-15'`)
-- MAGIC    - `v_max_date DATE` (set to `'2016-01-31'`)
-- MAGIC    - `v_trip_count INT`
-- MAGIC
-- MAGIC 2. Loops through each day starting with `v_current_date` and for each day:
-- MAGIC    - Compute `v_trip_count`
-- MAGIC    - Check whether it exceeds 400 or not.
-- MAGIC    - If it exceeds 400, print the date and the trip count
-- MAGIC    - If it does not exceed 400 for any day before `v_max_date`, print `No busy day found in range`
-- MAGIC
-- MAGIC

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ##### ANSWER
-- MAGIC
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW------------------->
-- MAGIC BEGIN
-- MAGIC   DECLARE v_current_date DATE;
-- MAGIC   DECLARE v_max_date DATE;
-- MAGIC   DECLARE v_trip_count INT;
-- MAGIC
-- MAGIC   SET v_current_date = DATE '2016-01-15';
-- MAGIC   SET v_max_date = DATE '2016-01-31';
-- MAGIC
-- MAGIC   find_busy_day:
-- MAGIC   LOOP
-- MAGIC     SET v_trip_count = (SELECT COUNT(*)
-- MAGIC                         FROM trips
-- MAGIC                         WHERE DATE(tpep_pickup_datetime) = v_current_date);
-- MAGIC
-- MAGIC     IF v_trip_count >= 400 THEN
-- MAGIC       SELECT
-- MAGIC         v_current_date AS first_busy_date,
-- MAGIC         v_trip_count AS total_trips;
-- MAGIC       LEAVE find_busy_day;
-- MAGIC     END IF;
-- MAGIC
-- MAGIC     IF v_current_date >= v_max_date THEN
-- MAGIC       SELECT 'No busy day found in range' AS message;
-- MAGIC       LEAVE find_busy_day;
-- MAGIC     END IF;
-- MAGIC
-- MAGIC     SET v_current_date = DATE_ADD(v_current_date, 1);
-- MAGIC   END LOOP find_busy_day;
-- MAGIC END;
-- MAGIC <!-------------------END SOLUTION CODE------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   // Preferred modern API
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC **Expected Output:**
-- MAGIC
-- MAGIC | first_busy_date | total_trips |
-- MAGIC |-----------|-------------|
-- MAGIC | 2016-01-16 | 416 |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## F. Error Handling
-- MAGIC
-- MAGIC Without error handling, a single bad record or missing table can crash your entire job. Error handlers let you catch issues and either recover gracefully or log them for later review.
-- MAGIC
-- MAGIC **References:** 
-- MAGIC
-- MAGIC - [Error handling in Databricks](https://docs.databricks.com/aws/en/error-messages/)
-- MAGIC - [SIGNAL statement](https://docs.databricks.com/aws/en/sql/language-manual/control-flow/signal-stmt)
-- MAGIC - [RESIGNAL statement](https://docs.databricks.com/aws/en/sql/language-manual/control-flow/resignal-stmt)
-- MAGIC
-- MAGIC **When to use:** When processing unpredictable data or when jobs must be resilient to failures.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### F1. Minimum Distance Check
-- MAGIC
-- MAGIC In the following example, we deliberately assign a default value of 0 to `v_min_distance` and create a custom error message which would be printed during the conditional check using the `SIGNAL SQLSTATE` statement.
-- MAGIC
-- MAGIC Run the code below to see how this works:

-- COMMAND ----------

BEGIN
  DECLARE v_min_distance DOUBLE DEFAULT 0.0;

  -- Simple validation: must be > 0
  IF v_min_distance <= 0 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'v_min_distance must be greater than zero.';
  END IF;

  -- Only runs if value is valid
  SELECT v_min_distance;
END;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC As expected, it returned an error which we defined with SIGNAL statement.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### F2. Fail Fast When Data Quality is Bad
-- MAGIC
-- MAGIC Operations run a daily 'trusted metrics' job that must not completely fail if one part encounters bad data.
-- MAGIC
-- MAGIC **Task:**
-- MAGIC Create a script that:
-- MAGIC
-- MAGIC 1. Declares: 
-- MAGIC    -    `v_trip_date DATE` (set to `'2016-01-26'`)
-- MAGIC    -    `v_bad_trips INT` <p>
-- MAGIC 2. Checks if there are any trips for the given day that have fare amount less than 0 and stores the number of such trips in `v_bad_trips` <p>
-- MAGIC 3. Prints a custom error message **_Found trips with negative fare for the given date_** if `v_bad_trips` > 0 <p>
-- MAGIC 4. If there is no error then print `v_trip_date` and `status` as **OK** 

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ##### ANSWER
-- MAGIC
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW------------------->
-- MAGIC BEGIN
-- MAGIC   DECLARE v_trip_date DATE DEFAULT DATE '2016-01-26';
-- MAGIC   DECLARE v_bad_trips INT;
-- MAGIC
-- MAGIC   SET v_bad_trips = (SELECT COUNT(*)
-- MAGIC                     FROM trips
-- MAGIC                     WHERE DATE(tpep_pickup_datetime) = v_trip_date
-- MAGIC                     AND fare_amount < 0);
-- MAGIC
-- MAGIC   IF v_bad_trips > 0 THEN
-- MAGIC     SIGNAL SQLSTATE '45000'
-- MAGIC       SET MESSAGE_TEXT = 'Found trips with negative fare for the given date.';
-- MAGIC   END IF;
-- MAGIC
-- MAGIC   SELECT
-- MAGIC     v_trip_date AS trip_date,
-- MAGIC     'OK' AS status;
-- MAGIC END;
-- MAGIC <!-------------------END SOLUTION CODE------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   // Preferred modern API
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ---

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Conclusion
-- MAGIC
-- MAGIC In this lab, you have learned the fundamental components of SQL scripting in Databricks:
-- MAGIC
-- MAGIC - **Compound Statements:** Grouping multiple operations into logical units
-- MAGIC - **Variables:** Parameterizing scripts for reusability and maintainability
-- MAGIC - **Conditional Logic:** Making data-driven decisions in your scripts
-- MAGIC - **Loops:** Processing multiple parameters efficiently
-- MAGIC - **Error Handling:** Building resilient scripts that handle unexpected conditions
-- MAGIC
-- MAGIC These techniques enable you to create sophisticated, maintainable SQL workflows that can handle complex business logic and adapt to changing requirements.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Clean-up
-- MAGIC
-- MAGIC Run the following cell to remove the resources created during this lab:

-- COMMAND ----------

DROP SCHEMA IF EXISTS sql_script_lab CASCADE;

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
-- MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
-- MAGIC <script>
-- MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
-- MAGIC </script>