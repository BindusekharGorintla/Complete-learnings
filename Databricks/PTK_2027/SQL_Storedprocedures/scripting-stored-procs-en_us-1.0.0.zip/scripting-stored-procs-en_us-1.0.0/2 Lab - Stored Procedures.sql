-- Databricks notebook source
-- MAGIC %md
-- MAGIC ![DBAcademy](./Includes/images/db-academy.png)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Lab - Stored Procedures

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Overview
-- MAGIC
-- MAGIC Stored procedures are powerful tools for encapsulating complex business logic and creating reusable SQL components in Databricks. Building on the SQL Scripting fundamentals, you'll learn to encapsulate procedural logic in reusable stored procedures that can be called repeatedly with different parameters. You'll use parameters, return values, and modular design patterns with the NYC Taxi dataset.
-- MAGIC
-- MAGIC By the end of this lab, you'll be able to create stored procedures that implement business logic, enforce data quality, and enable consistent data processing workflows.
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Learning Objectives
-- MAGIC
-- MAGIC By completing this lab, you will:
-- MAGIC
-- MAGIC - Create and execute stored procedures in Databricks SQL
-- MAGIC - Implement parameterized procedures with different input types and validation
-- MAGIC - Return results from procedures using CALL statements
-- MAGIC - Design conditional logic and error handling within procedures
-- MAGIC - Create dynamic stored procedures with `EXECUTE IMMEDIATE` statement

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## REQUIRED - SELECT A COMPUTE ENVIRONMENT
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select a SQL Warehouse</strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC Before starting this notebook, select the required compute environment.
-- MAGIC - **SQL Warehouse**
-- MAGIC
-- MAGIC To select a SQL Warehouse:
-- MAGIC
-- MAGIC 1. Select the compute tile in the top-right corner of the notebook.
-- MAGIC 2. If your SQL Warehouse is already listed, select it.
-- MAGIC 3. If it is not visible, select **More** > **SQL Warehouse**, then choose your SQL Warehouse from the list.
-- MAGIC
-- MAGIC **NOTE:**  This notebook was **developed and tested using a SQL Warehouse**. Other compute options may work but are not guaranteed to behave the same or support all features demonstrated.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## A. Classroom Setup
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #1976d2;
-- MAGIC   background: #e3f2fd;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size:1.1em;">
-- MAGIC     Option 1 - Databricks Academy Provided Workspace (Vocareum Workspace)
-- MAGIC   </strong>
-- MAGIC   <details>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC If you are running this notebook in a <strong>Databricks Academy provided Vocareum workspace</strong>, your Unity Catalog catalog is already created for you.
-- MAGIC
-- MAGIC Your catalog name matches your Vocareum username and looks like: <strong>labuser12345</strong> (series of unique numbers)
-- MAGIC   </div>
-- MAGIC   </details>
-- MAGIC </div>
-- MAGIC
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #1976d2;
-- MAGIC   background: #e3f2fd;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size:1.1em;">
-- MAGIC     Option 2 - Other Workspaces or Databricks Free Edition
-- MAGIC   </strong>
-- MAGIC   <details>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC If you are running this notebook in your own Databricks workspace or Databricks Free Edition, the setup will
-- MAGIC <strong>create a Unity Catalog catalog and schema for you</strong>. **Create catalog permission is required.**
-- MAGIC
-- MAGIC The catalog name is derived from your Databricks username and follows this pattern: <strong>labuser_username</strong>
-- MAGIC   </div>
-- MAGIC   </details>
-- MAGIC </div>
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Do Not Run in Production Environments</strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC   <ul>
-- MAGIC       <li>Only run this notebook in <strong>development or sandbox workspaces</strong>.</li>
-- MAGIC       <li>Do not run this in production environments. The setup script creates a catalog and schemas in your workspace.</li>
-- MAGIC   </ul>
-- MAGIC   </div>
-- MAGIC </div>
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### A1. Configure Your Catalog and Schema
-- MAGIC
-- MAGIC 1. Run the cell below to initialize your lab environment. This setup step will:
-- MAGIC
-- MAGIC - Assume that you have **permission to create a catalog**
-- MAGIC - Create a catalog named `labuser_your_username` if running outside of a Databricks Vocareum provided Workspace
-- MAGIC - Create a schema named `sql_script_lab`
-- MAGIC - Ingest **nyctaxi** dataset into your schema 
-- MAGIC
-- MAGIC #### Troubleshooting
-- MAGIC If you do not have permission to create a new catalog but already have one available, you can explicitly specify an existing catalog by using the `catalog_forced` argument in the `build_user_catalog_name` function.
-- MAGIC
-- MAGIC This function is defined in the notebook: `./Includes/Classroom-Setup-Common`

-- COMMAND ----------

-- MAGIC %run ./Includes/Classroom-Setup-Common

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 2. In the workspace sidebar, navigate to your catalog and schema. Confirm the following:
-- MAGIC
-- MAGIC - A catalog named **labuser_your_username** exists
-- MAGIC - The catalog contains a schema named **sql_script_lab**
-- MAGIC - The schema contains a table named **trips**

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### A2. Dataset Overview
-- MAGIC
-- MAGIC **Schema:** `sql_script_lab`  
-- MAGIC **Table:** `trips`
-- MAGIC
-- MAGIC | Column | Type | Description |
-- MAGIC |--------|------|-------------|
-- MAGIC | `tpep_pickup_datetime` | timestamp | When the trip started |
-- MAGIC | `tpep_dropoff_datetime` | timestamp | When the trip ended |
-- MAGIC | `trip_distance` | double | Distance traveled in miles |
-- MAGIC | `fare_amount` | double | Fare in dollars |
-- MAGIC | `pickup_zip` | int | Pickup ZIP code |
-- MAGIC | `dropoff_zip` | int | Dropoff ZIP code |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### A3. Validate Environment Setup
-- MAGIC
-- MAGIC This catalog and schema should be set as the default ones for you. Validate this by running the following cell:

-- COMMAND ----------

SELECT CURRENT_CATALOG(), CURRENT_SCHEMA();

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ---

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## B. Creating Your First Stored Procedure
-- MAGIC
-- MAGIC Stored procedures are reusable SQL blocks stored in the schema. Unlike compound statements that run once, procedures are saved and can be called multiple times with different inputs. They're perfect for:
-- MAGIC
-- MAGIC - Encapsulating business logic
-- MAGIC - Reducing code duplication
-- MAGIC - Enabling consistent data processing
-- MAGIC - Scheduling as jobs with parameters
-- MAGIC
-- MAGIC **When to use:** When you have logic that's called multiple times, needs parameters, or should be managed centrally.
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B1. Simple Trip Counter Procedure
-- MAGIC
-- MAGIC Our goal is to create a basic procedure that counts trips for a given date. Let's start by understanding why we need a stored procedure here in the first place.
-- MAGIC
-- MAGIC Let's start with a simple query that retrieves the trip data for a given date.

-- COMMAND ----------

SELECT
  DATE(tpep_pickup_datetime) AS trip_date,
  COUNT(*) AS total_trips
FROM trips
WHERE DATE(tpep_pickup_datetime) = '2016-01-26'
GROUP BY DATE(tpep_pickup_datetime);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC The problem with this approach is that the code lacks reusability. Instead of doing this manually every time we want to extract this information, we can simply wrap this query in a compound statement in a stored procedure using `CREATE OR REPLACE PROCEDURE`.<p>
-- MAGIC **NOTE:** We include `SQL SECURITY INVOKER` in the following code block. This is an important part of any procedure definition in Databricks and is used to specify that any SQL statements in the body of the procedure will be executed under the authority of the user invoking the procedure.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Run the code below to create your first stored procedure:

-- COMMAND ----------

CREATE OR REPLACE PROCEDURE count_trips()
SQL SECURITY INVOKER
AS
BEGIN
  SELECT
    DATE(tpep_pickup_datetime) AS trip_date,
    COUNT(*) AS total_trips
  FROM trips
  WHERE DATE(tpep_pickup_datetime) = DATE '2016-01-26'
  GROUP BY DATE(tpep_pickup_datetime);
END;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now let's try calling the stored procedure:

-- COMMAND ----------

CALL count_trips();

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now we can call this procedure whenever we want without rewriting the entire code. But to make this procedure truly reusable, we need to pass the date as a parameter instead of hardcoding it. Run the following code to see how this works:

-- COMMAND ----------

CREATE OR REPLACE PROCEDURE count_trips_by_date(trip_date STRING)
SQL SECURITY INVOKER
COMMENT 'Returns the total number of trips for a given date' -- Adding comment to the procedure to add context in the definition  
AS
BEGIN
  SELECT
    trip_date AS trip_date,
    COUNT(*) AS total_trips
  FROM trips
  WHERE DATE(tpep_pickup_datetime) = TO_DATE(trip_date);
END;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **NOTE:** We are passing the `trip_date` parameter as a `STRING` and are converting it to `DATE` later using `TO_DATE()` function rather than passing it as a `DATE` parameter. This is a good practice in order to avoid TYPE errors during conditional checks. 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now call the procedure with a specific date:

-- COMMAND ----------

CALL count_trips_by_date(trip_date => '2016-01-26');

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Try calling the procedure with a different date (e.g. `2016-01-27`) 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B2. Exploring Procedure Metadata
-- MAGIC
-- MAGIC Running the following code will retrieve detailed information about the procedure. Look for the comment we included in the definition. Then scroll down to the bottom of the output and observe the body of the procedure by clicking the body dropdown. You can also see the owner of the procedure and its creation time amongst other details.

-- COMMAND ----------

DESCRIBE PROCEDURE EXTENDED count_trips_by_date;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Run the following code to query the list of existing procedures:

-- COMMAND ----------

SHOW PROCEDURES;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC You can delete your procedure by running the following command:

-- COMMAND ----------

DROP PROCEDURE count_trips_by_date;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **Read more here:**
-- MAGIC
-- MAGIC - [Introducing SQL Stored Procedures in Databricks](https://www.databricks.com/blog/introducing-sql-stored-procedures-databricks)
-- MAGIC - [CREATE PROCEDURE](https://docs.databricks.com/aws/en/sql/language-manual/sql-ref-syntax-ddl-create-procedure)
-- MAGIC - [CALL](https://docs.databricks.com/aws/en/sql/language-manual/sql-ref-syntax-aux-call)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B3. Create Your First Procedure
-- MAGIC
-- MAGIC You need a reusable procedure that validates a single day's trip data.
-- MAGIC
-- MAGIC **Task:**
-- MAGIC Create a stored procedure named `validate_daily_trips` that:
-- MAGIC
-- MAGIC 1. Takes one parameter: `trip_date STRING`
-- MAGIC 2. Returns a table with:
-- MAGIC    - `trip_date` (the input parameter)
-- MAGIC    - `total_trips` (count of all trips for that day)
-- MAGIC    - `zero_distance_trips` (count where `trip_distance <= 0`)
-- MAGIC    - `negative_fare_trips` (count where `fare_amount < 0`)
-- MAGIC
-- MAGIC Add a comment in the procedure definition to add more context about what the procedure is doing. 
-- MAGIC
-- MAGIC **Hints:**
-- MAGIC - Use `CREATE OR REPLACE PROCEDURE` syntax
-- MAGIC - Use `COUNT_IF()` to count conditional rows
-- MAGIC - Test with `CALL validate_daily_trips(DATE '2016-01-26')`
-- MAGIC - Convert `trip_date` to `DATE` type during conditional check using `TO_DATE()` function
-- MAGIC

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC
-- MAGIC #### ANSWER
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW--------------------->
-- MAGIC CREATE OR REPLACE PROCEDURE validate_daily_trips(trip_date STRING)
-- MAGIC SQL SECURITY INVOKER
-- MAGIC COMMENT 'validates a single day trips data'
-- MAGIC AS
-- MAGIC BEGIN
-- MAGIC   SELECT
-- MAGIC     trip_date AS trip_date,
-- MAGIC     COUNT(*) AS total_trips,
-- MAGIC     COUNT_IF(trip_distance <= 0) AS zero_distance_trips,
-- MAGIC     COUNT_IF(fare_amount < 0) AS negative_fare_trips
-- MAGIC   FROM trips
-- MAGIC   WHERE DATE(tpep_pickup_datetime) = TO_DATE(trip_date);
-- MAGIC END;
-- MAGIC <!-------------------END SOLUTION CODE--------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC
-- MAGIC </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now test your procedure:

-- COMMAND ----------

CALL validate_daily_trips(trip_date => '2016-01-26');

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **Expected Output:**
-- MAGIC
-- MAGIC | trip_date | total_trips | zero_distance_trips | negative_fare_trips |
-- MAGIC |-----------|-------------|---------------------|---------------------|
-- MAGIC | 2016-01-26 | 306 | 1 | 1 |
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **NOTE:** You can `GRANT `access to stored procedures to other principals who can then invoke the procedure using `CALL` statement.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ## C. Using Multiple Parameters in Procedures
-- MAGIC
-- MAGIC Procedures with parameters become truly reusable. Instead of creating different procedures for each date or threshold, you parameterize them once and call with different values.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C1. Multi-Parameter Data Quality procedure
-- MAGIC
-- MAGIC We want to segregate the trips into different categories - SHORT, MEDIUM and LONG based on trip distance using a CASE statement for a given date and then display the summary for the different categories (trip count and average fare)
-- MAGIC
-- MAGIC Run the following cell:

-- COMMAND ----------

SELECT
  DATE(tpep_pickup_datetime) AS trip_date,
  CASE
    WHEN trip_distance < 2 THEN 'SHORT'
    WHEN trip_distance <= 10 THEN 'MEDIUM'
    ELSE 'LONG'
  END AS distance_category,
  COUNT(*) AS trip_count,
  ROUND(AVG(fare_amount), 2) AS avg_fare
FROM trips
WHERE DATE(tpep_pickup_datetime) = DATE('2016-01-26')
GROUP BY trip_date, distance_category
ORDER BY trip_date, distance_category;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now we can make this query more dynamic and reusable by wrapping it inside a procedure and defining the parameters for date and distance. <p> We will define the procedure in a very similar fashion as we did before, but this time we will include multiple parameters: `trip_date`, `min_distance` and `max_distance`.  

-- COMMAND ----------

CREATE OR REPLACE PROCEDURE classify_trips_by_distance(
  trip_date STRING,
  min_distance DOUBLE,
  max_distance DOUBLE
)
SQL SECURITY INVOKER
COMMENT 'classify trips by distance and calculate trip count & average fare'  
AS
BEGIN
  SELECT
    trip_date AS trip_date,
    CASE
      WHEN trip_distance < min_distance THEN 'SHORT'
      WHEN trip_distance <= max_distance THEN 'MEDIUM'
      ELSE 'LONG'
    END AS distance_category,
    COUNT(*) AS trip_count,
    ROUND(AVG(fare_amount), 2) AS avg_fare
  FROM trips
  WHERE DATE(tpep_pickup_datetime) = TO_DATE(trip_date)
  GROUP BY distance_category
  ORDER BY
    CASE
      WHEN distance_category = 'SHORT' THEN 1
      WHEN distance_category = 'MEDIUM' THEN 2
      ELSE 3
    END;
END;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Call it with different distance thresholds:

-- COMMAND ----------

CALL classify_trips_by_distance(trip_date => '2016-01-26', min_distance => 2.0, max_distance => 10.0);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC As we can see, multiple input parameters allow the same procedure to work with different thresholds. Call with different parameter values to see how the procedure adapts.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C2. Zone-wise Fare Analysis
-- MAGIC
-- MAGIC You need a procedure that analyzes fares for trips from a specific pickup zone, classifying them into fare brackets.
-- MAGIC
-- MAGIC **Task:**
-- MAGIC Create a stored procedure named `analyze_zone_fares` that:
-- MAGIC
-- MAGIC 1. Takes three parameters:
-- MAGIC    - `analysis_date STRING`
-- MAGIC    - `pickup_zipcode INT`
-- MAGIC    - `fare_threshold DOUBLE` (to split low/high fare trips)
-- MAGIC
-- MAGIC 2. Returns a table with:
-- MAGIC    - `pickup_zip` (the input zipcode)
-- MAGIC    - `total_trips` (count for that zone on the given date)
-- MAGIC    - `low_fare_trips` (count where `fare_amount <= fare_threshold`)
-- MAGIC    - `high_fare_trips` (count where `fare_amount > fare_threshold`)
-- MAGIC    - `avg_fare` (average fare, rounded to 2 decimals)
-- MAGIC
-- MAGIC 3. Filters for the given date and `pickup_zip`
-- MAGIC
-- MAGIC **Hint:**
-- MAGIC
-- MAGIC - Use `COUNT_IF()` for conditional counting
-- MAGIC

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC
-- MAGIC ##### ANSWER
-- MAGIC
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW--------------------->
-- MAGIC CREATE OR REPLACE PROCEDURE analyze_zone_fares(
-- MAGIC   analysis_date STRING,
-- MAGIC   pickup_zipcode INT,
-- MAGIC   fare_threshold DOUBLE
-- MAGIC )
-- MAGIC SQL SECURITY INVOKER
-- MAGIC COMMENT 'analyzes fares for trips from a specific pickup zone, classifying them into fare brackets'
-- MAGIC AS
-- MAGIC BEGIN
-- MAGIC   SELECT
-- MAGIC     pickup_zipcode AS pickup_zip,
-- MAGIC     COUNT(*) AS total_trips,
-- MAGIC     COUNT_IF(fare_amount <= fare_threshold) AS low_fare_trips,
-- MAGIC     COUNT_IF(fare_amount > fare_threshold) AS high_fare_trips,
-- MAGIC     ROUND(AVG(fare_amount), 2) AS avg_fare
-- MAGIC   FROM trips
-- MAGIC   WHERE DATE(tpep_pickup_datetime) = TO_DATE(analysis_date)
-- MAGIC   AND pickup_zip = pickup_zipcode;
-- MAGIC END;
-- MAGIC <!-------------------END SOLUTION CODE--------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC
-- MAGIC </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now test your procedure:

-- COMMAND ----------

CALL analyze_zone_fares(analysis_date => '2016-01-26', pickup_zipcode => 10002, fare_threshold => 12.0);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **Expected Output:**
-- MAGIC
-- MAGIC | pickup_zip | total_trips | low_fare_trips | high_fare_trips | avg_fare |
-- MAGIC |------------|-------------|----------------|-----------------|----------|
-- MAGIC | 10002 | 9 | 6 | 3 | 11.67 |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ---

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## D. Procedures with Conditional Logic
-- MAGIC
-- MAGIC Procedures with conditional logic make decisions based on input parameters or data conditions. This enables sophisticated business logic that adapts to different scenarios.
-- MAGIC
-- MAGIC **When to use:** When the procedure behavior needs to vary based on inputs or data state.
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D1. Trip Quality Flag with Conditional Message
-- MAGIC
-- MAGIC We will create a procedure that returns different messages based on data quality. We will identify the trips where either distance or fare is less than zero and flag such trips as anomaly in our data. Then we will set an anomaly count threshold we will pass as a parameter. We will define the conditional logic based on data conditions around this threshold and label the data quality for a given date as `PASS`, `WARN` or `FAIL`. Lastly we query the summary of data anomaly for the given date.
-- MAGIC
-- MAGIC
-- MAGIC
-- MAGIC Run the code below:

-- COMMAND ----------

CREATE OR REPLACE PROCEDURE check_trip_quality_status(
  trip_date STRING,
  quality_threshold INT
)
SQL SECURITY INVOKER
COMMENT 'returns different messages based on data quality'
AS
BEGIN
  DECLARE v_anomaly_count INT;
  DECLARE v_quality_status STRING;

  -- Count anomalies once
  SET v_anomaly_count = (
    SELECT COUNT(*)
    FROM trips
    WHERE DATE(tpep_pickup_datetime) = TO_DATE(trip_date)
      AND (trip_distance <= 0 OR fare_amount < 0)
  );

  -- Derive quality_status using IF / ELSEIF / ELSE
  IF v_anomaly_count = 0 THEN
    SET v_quality_status = 'PASS';
  ELSEIF v_anomaly_count <= quality_threshold THEN
    SET v_quality_status = 'WARN';
  ELSE
    SET v_quality_status = 'FAIL';
  END IF;

  -- Use the derived variable in the final SELECT
  SELECT
    trip_date AS trip_date,
    COUNT(*) AS total_trips,
    v_anomaly_count AS anomaly_count,
    v_quality_status AS quality_status
  FROM trips
  WHERE DATE(tpep_pickup_datetime) = TO_DATE(trip_date);
END;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC Call it with different quality thresholds:

-- COMMAND ----------

CALL check_trip_quality_status(trip_date => '2016-01-26', quality_threshold => 1);


-- COMMAND ----------

CALL check_trip_quality_status(trip_date => '2016-01-26', quality_threshold => 5);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **What this shows:** The `quality_status` changes based on the anomaly count versus the threshold, demonstrating conditional logic inside procedures.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D2. Busy Day Analyzer with Conditional Thresholds
-- MAGIC
-- MAGIC We need a procedure that determines if a day was busy or quiet based on trip volume, then returns different insights based on that classification.
-- MAGIC
-- MAGIC **Task:**
-- MAGIC Create a stored procedure named `analyze_day_activity` that:
-- MAGIC
-- MAGIC 1. Takes two parameters:
-- MAGIC    - `analysis_date STRING`
-- MAGIC    - `busy_threshold INT` (number of trips that defines a "busy" day; default: 350)
-- MAGIC
-- MAGIC 2. Internally calculates `v_day_trip_count` for the given date
-- MAGIC
-- MAGIC 3. Uses conditional logic to set a `v_day_classification` as:
-- MAGIC    - `'BUSY'` if trip count >= `busy_threshold`
-- MAGIC    - `'QUIET'` otherwise
-- MAGIC
-- MAGIC 4. Returns a table with:
-- MAGIC    - `trip_date`
-- MAGIC    - `total_trips`
-- MAGIC    - `day_classification`
-- MAGIC    - `avg_fare` (rounded to 2 decimals)
-- MAGIC
-- MAGIC 5. Include a compound `BEGIN...END` block inside the procedure
-- MAGIC
-- MAGIC **Hints:**
-- MAGIC - Use `DECLARE` to create internal variables
-- MAGIC - Use `SET` to compute the trip count from the table
-- MAGIC - Use `IF` or `CASE` for conditional classification
-- MAGIC - Test with: `CALL analyze_day_activity(DATE '2016-01-26', 300)`
-- MAGIC

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC
-- MAGIC ##### ANSWER
-- MAGIC
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW--------------------->
-- MAGIC CREATE OR REPLACE PROCEDURE analyze_day_activity(
-- MAGIC   analysis_date STRING,
-- MAGIC   busy_threshold INT
-- MAGIC )
-- MAGIC SQL SECURITY INVOKER
-- MAGIC COMMENT 'determines if a day was busy or quiet based on trip volume, then returns different insights based on that classification'
-- MAGIC AS
-- MAGIC BEGIN
-- MAGIC   DECLARE v_day_trip_count INT;
-- MAGIC   DECLARE v_day_classification STRING;
-- MAGIC
-- MAGIC   -- Count trips for the day
-- MAGIC   SET v_day_trip_count = (
-- MAGIC     SELECT COUNT(*)
-- MAGIC     FROM trips
-- MAGIC     WHERE DATE(tpep_pickup_datetime) = TO_DATE(analysis_date)
-- MAGIC   );
-- MAGIC
-- MAGIC   -- Classify based on trip count using IF / ELSE
-- MAGIC   IF v_day_trip_count >= busy_threshold THEN
-- MAGIC     SET v_day_classification = 'BUSY';
-- MAGIC   ELSE
-- MAGIC     SET v_day_classification = 'QUIET';
-- MAGIC   END IF;
-- MAGIC
-- MAGIC   -- Return results with classification
-- MAGIC   SELECT
-- MAGIC     analysis_date AS trip_date,
-- MAGIC     v_day_trip_count AS total_trips,
-- MAGIC     v_day_classification AS day_classification,
-- MAGIC     ROUND(AVG(fare_amount), 2) AS avg_fare
-- MAGIC   FROM trips
-- MAGIC   WHERE DATE(tpep_pickup_datetime) = TO_DATE(analysis_date);
-- MAGIC END;
-- MAGIC <!-------------------END SOLUTION CODE--------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC
-- MAGIC </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now test your procedure:

-- COMMAND ----------

CALL analyze_day_activity(analysis_date => '2016-01-26', busy_threshold => 300);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **Expected Output:**
-- MAGIC
-- MAGIC | trip_date | total_trips | day_classification | avg_fare |
-- MAGIC |-----------|-------------|-------------------|----------|
-- MAGIC | 2016-01-26 | 306 | BUSY | 13.63 |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## E. Procedures with Error Handling
-- MAGIC
-- MAGIC Procedures are often scheduled as automated jobs that run unattended. Without error handling, a single bad parameter or data anomaly can fail the entire job. Error handling lets you validate inputs and gracefully handle problems.
-- MAGIC
-- MAGIC **When to use:** When procedures process user inputs, run on unpredictable data, or are scheduled as production jobs.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### E1. Procedure with Input Validation
-- MAGIC
-- MAGIC We will create a procedure that validates its inputs before processing. If it encounters an error, it will print a custom message with the help of SIGNAL statement.
-- MAGIC
-- MAGIC Read more on [SIGNAL statement](https://docs.databricks.com/aws/en/sql/language-manual/control-flow/signal-stmt#:~:text=Raises%20a%20condition.,conditions%20from%20within%20a%20handler.)
-- MAGIC
-- MAGIC Run the code below:

-- COMMAND ----------

CREATE OR REPLACE PROCEDURE validate_and_process(
  trip_date STRING,
  min_fare DOUBLE
)
SQL SECURITY INVOKER
COMMENT 'validates input parameters before processing'
AS
BEGIN
  -- Validate that min_fare is positive
  IF min_fare <= 0 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'min_fare must be greater than zero.';
  END IF;

  -- Process if validation passes
  SELECT
    trip_date AS trip_date,
    COUNT(*) AS total_trips,
    COUNT_IF(fare_amount >= min_fare) AS trips_above_min_fare
  FROM trips
  WHERE DATE(tpep_pickup_datetime) = TO_DATE(trip_date);
END;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Call with valid and invalid inputs:

-- COMMAND ----------

-- -- Valid call
CALL validate_and_process(trip_date => '2016-01-26', min_fare=> 10.0);

-- Invalid call (uncomment to see error)
-- CALL validate_and_process(trip_date => '2016-01-26', min_fare=> -5.0);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **What this shows:** The procedure checks inputs and raises an error with a clear message if validation fails.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### E2. Quality Check with Error Recovery
-- MAGIC
-- MAGIC You need a procedure that validates a day's data, raises an error if anomalies exceed a threshold, but still reports the anomaly count even if it fails.
-- MAGIC
-- MAGIC **Task:**
-- MAGIC Create a stored procedure named `safe_quality_report` that:
-- MAGIC
-- MAGIC 1. Takes two parameters:
-- MAGIC    - `check_date STRING`
-- MAGIC    - `max_allowed_anomalies INT` (maximum anomalies before raising an error)
-- MAGIC
-- MAGIC 2. Calculates `v_anomaly_count` as count of trips where `trip_distance <= 0 OR fare_amount < 0`
-- MAGIC
-- MAGIC 3. Validates:
-- MAGIC    - If `v_anomaly_count > max_allowed_anomalies`, raise an error with message: `"Data quality check failed: X anomalies found, maximum allowed is Y"`
-- MAGIC    - Replace X and Y with actual values
-- MAGIC
-- MAGIC 4. Returns a table with:
-- MAGIC    - `check_date`
-- MAGIC    - `total_trips`
-- MAGIC    - `anomaly_count`
-- MAGIC    - `status` (either 'PASS' or 'FAIL' based on validation)
-- MAGIC
-- MAGIC 5. Ensure the return table is generated regardless of whether validation passes or fails
-- MAGIC
-- MAGIC **Hints:**
-- MAGIC - Use `v_anomaly_count` to check against `max_allowed_anomalies`
-- MAGIC - Use `SIGNAL SQLSTATE '45000'` with dynamic message text
-- MAGIC - Construct error message using string concatenation: `'Data quality check failed: ' || v_anomaly_count || ' anomalies found, maximum allowed is ' || max_allowed_anomalies`
-- MAGIC - Test with: `CALL safe_quality_report(DATE '2016-01-26', 0)` (should fail)
-- MAGIC - And: `CALL safe_quality_report(DATE '2016-01-26', 5)` (should pass)
-- MAGIC

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC
-- MAGIC ##### ANSWER
-- MAGIC
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW--------------------->
-- MAGIC CREATE OR REPLACE PROCEDURE safe_quality_report(
-- MAGIC   check_date STRING,
-- MAGIC   max_allowed_anomalies INT
-- MAGIC )
-- MAGIC SQL SECURITY INVOKER
-- MAGIC AS
-- MAGIC BEGIN
-- MAGIC   DECLARE v_anomaly_count INT;
-- MAGIC   DECLARE v_total_trips INT;
-- MAGIC   DECLARE v_status STRING;
-- MAGIC
-- MAGIC   -- Count anomalies
-- MAGIC   SET v_anomaly_count = (
-- MAGIC     SELECT COUNT(*)
-- MAGIC     FROM trips
-- MAGIC     WHERE DATE(tpep_pickup_datetime) = TO_DATE(check_date)
-- MAGIC     AND (trip_distance <= 0 OR fare_amount < 0)
-- MAGIC   );
-- MAGIC
-- MAGIC   -- Count total trips
-- MAGIC   SET v_total_trips = (
-- MAGIC     SELECT COUNT(*)
-- MAGIC     FROM trips
-- MAGIC     WHERE DATE(tpep_pickup_datetime) = TO_DATE(check_date)
-- MAGIC   );
-- MAGIC
-- MAGIC   -- Determine status and validate
-- MAGIC   IF v_anomaly_count > max_allowed_anomalies THEN
-- MAGIC     SET v_status = 'FAIL';
-- MAGIC     SIGNAL SQLSTATE '45000'
-- MAGIC       SET MESSAGE_TEXT = 'Data quality check failed: ' || CAST(v_anomaly_count AS STRING) || ' anomalies found, maximum allowed is ' || CAST(max_allowed_anomalies AS STRING);
-- MAGIC   ELSE
-- MAGIC     SET v_status = 'PASS';
-- MAGIC   END IF;
-- MAGIC
-- MAGIC   -- Return results
-- MAGIC   SELECT
-- MAGIC     check_date AS check_date,
-- MAGIC     v_total_trips AS total_trips,
-- MAGIC     v_anomaly_count AS anomaly_count,
-- MAGIC     v_status AS status;
-- MAGIC END;
-- MAGIC <!-------------------END SOLUTION CODE--------------------->
-- MAGIC </code></pre>
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC
-- MAGIC </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now test your procedure:

-- COMMAND ----------

-- Should pass
CALL safe_quality_report(check_date => '2016-01-26', max_allowed_anomalies => 5);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **Expected Output (Pass case):**
-- MAGIC
-- MAGIC | check_date | total_trips | anomaly_count | status |
-- MAGIC |-----------|-------------|---------------|--------|
-- MAGIC | 2016-01-26 | 306 | 2 | PASS |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Try the failure case:

-- COMMAND ----------

-- Should fail with error message
CALL safe_quality_report(check_date => '2016-01-26', max_allowed_anomalies => 0);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## F. (Optional) Advanced Stored Procedures with EXECUTE IMMEDIATE
-- MAGIC
-- MAGIC EXECUTE IMMEDIATE executes a SQL statement provided as a `STRING`. It enables dynamic SQL execution within procedures, allowing you to construct and execute SQL statements at runtime. EXECUTE IMMEDIATE lets you build and execute parameterized queries on-the-fly. This is more efficient for batch processing multiple parameters without creating intermediate tables or explicit loops.
-- MAGIC
-- MAGIC Standard SQL cannot use variables for table names or column names in DDL statements. 
-- MAGIC `EXECUTE IMMEDIATE` solves this limitation.
-- MAGIC
-- MAGIC **When to use:** When you need to dynamically construct and execute SQL based on procedure parameters, process multiple items without explicit loops, or execute pre-defined SQL patterns with different parameter combinations.
-- MAGIC
-- MAGIC Read more on [EXECUTE IMMEDIATE](https://docs.databricks.com/aws/en/sql/language-manual/sql-ref-syntax-aux-execute-immediate)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC EXECUTE IMMEDIATE constructs the SQL dynamically and uses the `?` placeholder syntax with `USING` to pass parameters. Let's see a quick example of how this works:

-- COMMAND ----------

EXECUTE IMMEDIATE 
'SELECT 
  pickup_zip,
  COUNT(*) AS total_trips
FROM trips WHERE pickup_zip = ? 
GROUP BY pickup_zip '
USING '10001';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### F1. Dynamic Table Creation with EXECUTE IMMEDIATE
-- MAGIC
-- MAGIC We need a procedure that creates summary tables with names based on date parameter.
-- MAGIC
-- MAGIC We will need EXECUTE IMMEDIATE to do this standard SQL cannot use parameters for table names in DDL statements.
-- MAGIC
-- MAGIC Run the code below:

-- COMMAND ----------

CREATE OR REPLACE PROCEDURE create_dynamic_summary_table(
  summary_date STRING
)
SQL SECURITY INVOKER
COMMENT 'Creates a summary table with a dynamic name based on date parameter'
AS
BEGIN
  DECLARE v_table_name STRING;
  
  -- Build the dynamic table name
  SET v_table_name = 'trip_summary_' || REPLACE(summary_date, '-', '_');
  
  -- This CANNOT be done with regular parameterized SQL because table names cannot be parameters
  EXECUTE IMMEDIATE
    'CREATE OR REPLACE TABLE ' || v_table_name || ' AS
     SELECT
       DATE(tpep_pickup_datetime) AS trip_date,
       COUNT(*) AS total_trips,
       ROUND(AVG(trip_distance), 2) AS avg_distance,
       ROUND(AVG(fare_amount), 2) AS avg_fare,
       COUNT_IF(trip_distance <= 0 OR fare_amount < 0) AS anomaly_count
     FROM trips
     WHERE DATE(tpep_pickup_datetime) = TO_DATE(?)
     GROUP BY DATE(tpep_pickup_datetime)'
  USING summary_date;
  
  -- Confirm table creation
  SELECT 'Table created: ' || v_table_name AS result;
END;

-- COMMAND ----------

CALL create_dynamic_summary_table(summary_date => '2016-01-26')

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Run the following cell to confirm the table exists:

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ### F2. Dynamic Column Selection with Conditional Logic
-- MAGIC
-- MAGIC  You need a procedure that builds different SELECT statements based on analysis type parameters, where the actual columns and aggregations change based on the analysis requested.
-- MAGIC
-- MAGIC  **Task:**
-- MAGIC  Create a stored procedure named `flexible_trip_analysis` that:
-- MAGIC
-- MAGIC  1. Takes three parameters:
-- MAGIC     - `analysis_date STRING`
-- MAGIC     - `analysis_type STRING` (either 'BASIC', 'DETAILED', or 'QUALITY')
-- MAGIC     - `group_by_zone BOOLEAN` (whether to group by pickup_zip)
-- MAGIC
-- MAGIC  2. Uses conditional logic to build different SQL queries:
-- MAGIC     - **'BASIC'**: Select date, total trips, avg fare
-- MAGIC     - **'DETAILED'**: Select date, total trips, avg fare, avg distance, min/max fare
-- MAGIC     - **'QUALITY'**: Select date, total trips, anomaly count, quality score (10 if no anomalies, 5 if <=2 anomalies, 0 otherwise)
-- MAGIC
-- MAGIC  3. Conditionally adds `pickup_zip` to SELECT and GROUP BY if `group_by_zone` is true
-- MAGIC
-- MAGIC  4. Uses `EXECUTE IMMEDIATE` to execute the dynamically constructed query
-- MAGIC
-- MAGIC  **Hints:**
-- MAGIC  - Use IF statements to build different `v_sql_query` strings based on `analysis_type`
-- MAGIC  - Conditionally prepend `pickup_zip,` to the SELECT list if `group_by_zone` is true
-- MAGIC  - Conditionally append `GROUP BY pickup_zip` (or `GROUP BY DATE(...), pickup_zip`) if `group_by_zone` is true
-- MAGIC  - Use string concatenation with `||` to build the query
-- MAGIC  - Test with different combinations: `CALL flexible_trip_analysis('2016-01-26', 'BASIC', false)`
-- MAGIC  - Test with: `CALL flexible_trip_analysis('2016-01-26', 'QUALITY', true)`

-- COMMAND ----------

--<FILL-IN>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC
-- MAGIC #### ANSWER
-- MAGIC  <details>
-- MAGIC    <summary>EXPAND FOR SOLUTION CODE</summary>
-- MAGIC
-- MAGIC  <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC  <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC  <code>
-- MAGIC  <!-------------------ADD SOLUTION CODE BELOW----------------------->
-- MAGIC  CREATE OR REPLACE PROCEDURE flexible_trip_analysis(
-- MAGIC    analysis_date STRING,
-- MAGIC    analysis_type STRING,
-- MAGIC    group_by_zone BOOLEAN
-- MAGIC  )
-- MAGIC  SQL SECURITY INVOKER
-- MAGIC  COMMENT 'Builds different SELECT statements based on analysis type parameters'
-- MAGIC  AS
-- MAGIC  BEGIN
-- MAGIC    DECLARE v_sql_query STRING;
-- MAGIC    DECLARE v_select_columns STRING;
-- MAGIC    DECLARE v_group_by_clause STRING;
-- MAGIC
-- MAGIC    -- Build SELECT columns based on analysis type
-- MAGIC    IF analysis_type = 'BASIC' THEN
-- MAGIC      SET v_select_columns = 'DATE(tpep_pickup_datetime) AS trip_date,
-- MAGIC                              COUNT(*) AS total_trips,
-- MAGIC                              ROUND(AVG(fare_amount), 2) AS avg_fare';
-- MAGIC    ELSEIF analysis_type = 'DETAILED' THEN
-- MAGIC      SET v_select_columns = 'DATE(tpep_pickup_datetime) AS trip_date,
-- MAGIC                              COUNT(*) AS total_trips,
-- MAGIC                              ROUND(AVG(fare_amount), 2) AS avg_fare,
-- MAGIC                              ROUND(AVG(trip_distance), 2) AS avg_distance,
-- MAGIC                              ROUND(MIN(fare_amount), 2) AS min_fare,
-- MAGIC                              ROUND(MAX(fare_amount), 2) AS max_fare';
-- MAGIC    ELSEIF analysis_type = 'QUALITY' THEN
-- MAGIC      SET v_select_columns = 'DATE(tpep_pickup_datetime) AS trip_date,
-- MAGIC                              COUNT(*) AS total_trips,
-- MAGIC                              COUNT_IF(trip_distance <= 0 OR fare_amount < 0) AS anomaly_count,
-- MAGIC                              CASE
-- MAGIC                                WHEN COUNT_IF(trip_distance <= 0 OR fare_amount < 0) = 0 THEN 10
-- MAGIC                                WHEN COUNT_IF(trip_distance <= 0 OR fare_amount < 0) <= 2 THEN 5
-- MAGIC                                ELSE 0
-- MAGIC                              END AS quality_score';
-- MAGIC    ELSE
-- MAGIC      SIGNAL SQLSTATE '45000'
-- MAGIC        SET MESSAGE_TEXT = 'Invalid analysis_type. Must be BASIC, DETAILED, or QUALITY';
-- MAGIC    END IF;
-- MAGIC
-- MAGIC    -- Add pickup_zip to SELECT if grouping by zone
-- MAGIC    IF group_by_zone THEN
-- MAGIC      SET v_select_columns = 'pickup_zip, ' || v_select_columns;
-- MAGIC      SET v_group_by_clause = ' GROUP BY pickup_zip, DATE(tpep_pickup_datetime) ORDER BY pickup_zip, trip_date';
-- MAGIC    ELSE
-- MAGIC      SET v_group_by_clause = ' GROUP BY DATE(tpep_pickup_datetime) ORDER BY trip_date';
-- MAGIC    END IF;
-- MAGIC
-- MAGIC    -- Build complete query
-- MAGIC    SET v_sql_query = 'SELECT ' || v_select_columns ||
-- MAGIC                      ' FROM trips' ||
-- MAGIC                      ' WHERE DATE(tpep_pickup_datetime) = TO_DATE(?)' ||
-- MAGIC                      v_group_by_clause;
-- MAGIC
-- MAGIC    -- Execute the dynamically built query
-- MAGIC    EXECUTE IMMEDIATE v_sql_query USING analysis_date;
-- MAGIC  END;
-- MAGIC  <!-------------------END SOLUTION CODE----------------------->
-- MAGIC  </code></pre>
-- MAGIC
-- MAGIC  <script>
-- MAGIC  function copyBlock() {
-- MAGIC    const el = document.getElementById("copy-block");
-- MAGIC    if (!el) return;
-- MAGIC
-- MAGIC    const text = el.innerText;
-- MAGIC
-- MAGIC    if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC      navigator.clipboard.writeText(text)
-- MAGIC        .then(() => alert("Copied to clipboard"))
-- MAGIC        .catch(err => {
-- MAGIC          console.error("Clipboard write failed:", err);
-- MAGIC          fallbackCopy(text);
-- MAGIC        });
-- MAGIC    } else {
-- MAGIC      fallbackCopy(text);
-- MAGIC    }
-- MAGIC  }
-- MAGIC
-- MAGIC  function fallbackCopy(text) {
-- MAGIC    const textarea = document.createElement("textarea");
-- MAGIC    textarea.value = text;
-- MAGIC    textarea.style.position = "fixed";
-- MAGIC    textarea.style.left = "-9999px";
-- MAGIC    document.body.appendChild(textarea);
-- MAGIC    textarea.select();
-- MAGIC    try {
-- MAGIC      document.execCommand("copy");
-- MAGIC      alert("Copied to clipboard");
-- MAGIC    } catch (err) {
-- MAGIC      console.error("Fallback copy failed:", err);
-- MAGIC      alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC    } finally {
-- MAGIC      document.body.removeChild(textarea);
-- MAGIC    }
-- MAGIC  }
-- MAGIC  </script>
-- MAGIC
-- MAGIC  </details>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Now test your procedure:

-- COMMAND ----------

-- BASIC Analysis
CALL flexible_trip_analysis(analysis_date => '2016-01-26', analysis_type => 'BASIC', group_by_zone => false);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **Expected Output:**
-- MAGIC
-- MAGIC | trip_date | total_trips | avg_fare |
-- MAGIC |-----------|-------------|----------| 
-- MAGIC | 2016-01-26 | 306 | 13.63 |
-- MAGIC

-- COMMAND ----------

-- QUALITY Analysis with zone grouping
CALL flexible_trip_analysis(analysis_date => '2016-01-26', analysis_type => 'QUALITY', group_by_zone => true);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC **Expected Output:**
-- MAGIC
-- MAGIC 59 rows each showing the analysis for all the zones for the given date
-- MAGIC
-- MAGIC First five rows of the output illustrated:
-- MAGIC
-- MAGIC | pickup_zip | trip_date | total_trips | anomaly_count | quality score |
-- MAGIC |------------|-----------|-------------|---------------|---------------| 
-- MAGIC | 10001 | 2016-01-26 | 16 | 0 | 10 |
-- MAGIC | 10002 | 2016-01-26 | 9 | 0 | 10 |
-- MAGIC | 10003 | 2016-01-26 | 20 | 0 | 10 |
-- MAGIC | 10005 | 2016-01-26 | 1 | 0 | 10 |
-- MAGIC | 10007 | 2016-01-26 | 3 | 0 | 10 |

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ---

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Conclusion
-- MAGIC
-- MAGIC Congratulations on completing this lab. Here are the key concepts and best practices to remember:
-- MAGIC
-- MAGIC ### Key Concepts Learned
-- MAGIC
-- MAGIC 1. **Basic Stored Procedures**: Encapsulate reusable SQL logic with parameters
-- MAGIC 2. **Multi-Parameter Procedures**: Handle complex business logic with multiple inputs
-- MAGIC 3. **Conditional Logic**: Implement decision-making within procedures using IF/ELSE statements
-- MAGIC 4. **Error Handling**: Validate inputs and provide meaningful error messages
-- MAGIC 5. **Dynamic SQL**: Use EXECUTE IMMEDIATE for flexible, runtime SQL construction
-- MAGIC
-- MAGIC ### Best Practices
-- MAGIC
-- MAGIC - **Always use `SQL SECURITY INVOKER`** for proper permission handling
-- MAGIC - **Add meaningful comments** to document procedure purpose and parameters
-- MAGIC - **Validate input parameters** before processing to prevent errors
-- MAGIC - **Use consistent naming conventions** for procedures and variables
-- MAGIC - **Handle edge cases** with appropriate error messages
-- MAGIC - **Test procedures thoroughly** with various parameter combinations
-- MAGIC
-- MAGIC ### When to Use Stored Procedures
-- MAGIC
-- MAGIC - **Reusable business logic** that needs to be called multiple times
-- MAGIC - **Data quality validation** and automated checks
-- MAGIC - **Scheduled jobs** that require parameterized execution
-- MAGIC - **Complex data transformations** with conditional logic
-- MAGIC - **Dynamic reporting** where query structure varies by parameters

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Cleanup
-- MAGIC
-- MAGIC Run the following cell to remove the resources created during this lab:

-- COMMAND ----------

DROP SCHEMA IF EXISTS sql_script_lab CASCADE;

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
-- MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
-- MAGIC <script>
-- MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
-- MAGIC </script>