-- Databricks notebook source
-- Create safe function for catalog name
CREATE OR REPLACE TEMPORARY FUNCTION safe_uc_name(value STRING)
RETURNS STRING
RETURN
  COALESCE(
    NULLIF(
      REGEXP_REPLACE(
        REGEXP_REPLACE(
          LOWER(TRIM(value)),
          '[^a-z0-9_]',
          '_'
        ),
        '_+',
        '_'
      ),
      ''
    ),
    'user'
  );


-- Create temp view of all available catalogs
CREATE OR REPLACE TEMPORARY VIEW list_of_catalogs AS
SELECT LOWER(catalog_name) AS catalog_names
FROM system.information_schema.catalogs;

-- COMMAND ----------

-- Start SQL scripting block to create and or set catalog based on Workspace
BEGIN

-- =========================================
-- 1. Declare variables
-- =========================================
  DECLARE user_email STRING;
  DECLARE user_name STRING;
  DECLARE safe_user_name STRING;
  DECLARE vocareum_catalog_name STRING DEFAULT 'NA';
  DECLARE catalog_name STRING DEFAULT 'NA';
  DECLARE catalog_already_exists BOOLEAN DEFAULT FALSE;
  DECLARE create_catalog_statement STRING DEFAULT '';
  DECLARE create_view_with_catalog_name STRING DEFAULT '';
  DECLARE test STRING DEFAULT '';


-- =========================================
-- 2. Capture current user
-- =========================================
  SET user_email = current_user();
  SET user_name = SPLIT(user_email, '@')[0];
  SET safe_user_name = (SELECT safe_uc_name(SPLIT(current_user(), '@')[0]));


-- ==================================================================================
-- 3. Determine Vocareum or Non Vocareum Workspace and set and/or create catalog (Non Vocareum)
-- ==================================================================================
  -- Check to see if the user is in Vocareum by email address then setting the catalog name to the labuser name.
  IF (LOWER(user_email) LIKE '%@vocareum.com')
    THEN
      
      SET vocareum_catalog_name = safe_user_name;
      
      -- Check existence using the temp view of catalogs
      IF EXISTS (
        SELECT 1
        FROM list_of_catalogs
        WHERE catalog_names = LOWER(vocareum_catalog_name)
      ) THEN  

        SET catalog_already_exists = TRUE;

        -- Create Temp View to Store the SQL Variable Value for Global Use
        SET create_view_with_catalog_name = CONCAT(
              "CREATE OR REPLACE TEMP VIEW catalog_name_vw AS ",
              "SELECT '", vocareum_catalog_name, "' AS catalog_name"
            );


      END IF; 

  -- If Vocareum check fails, setup assuming you are in another Workspace like Free Edition. Create a catalog using labuser_username
  ELSE

    SET catalog_name = CONCAT('labuser_', safe_user_name);

    -- Create Temp View to Store the SQL Variable Value for Global Use
    SET create_view_with_catalog_name = CONCAT(
      "CREATE OR REPLACE TEMP VIEW catalog_name_vw AS ",
      "SELECT '", catalog_name, "' AS catalog_name"
    );

    -- Check existence using the temp view of catalogs
    IF EXISTS (
      SELECT 1
      FROM list_of_catalogs
      WHERE catalog_names = LOWER(catalog_name)
    ) 
      THEN 
      
        SET catalog_already_exists = TRUE;
        SET test = 'catalog exists';
    
    ELSE 

      SET create_catalog_statement = CONCAT(
        'CREATE CATALOG IF NOT EXISTS ',
        catalog_name
      );

      SET test = 'catalog does not exist';

      EXECUTE IMMEDIATE create_catalog_statement;
    END IF;


  END IF;


  EXECUTE IMMEDIATE create_view_with_catalog_name;


-- ===================================================================
-- 4. Return Final Script Results (Workspace Assumed and Catalog Name
-- ===================================================================
  SELECT
    CASE
      WHEN vocareum_catalog_name <> 'NA' THEN 'Vocareum Workspace'
      ELSE 'Non Vocareum Workspace'
    END AS Workspace,
    CASE
      WHEN vocareum_catalog_name <> 'NA' THEN vocareum_catalog_name
      ELSE catalog_name
    END AS `User Catalog Name`,
    CASE
      WHEN catalog_already_exists = TRUE THEN 'Catalog Already Exists'
      ELSE 'Catalog Created'
    END AS `Catalog Status`;
END;

-- COMMAND ----------

-- Create the global SQL variable with the catalog name using the temp view
DECLARE OR REPLACE my_catalog STRING;
SET VAR my_catalog = (SELECT catalog_name FROM catalog_name_vw);

-- Set default catalog
USE CATALOG IDENTIFIER(my_catalog);

-- Confirm the default catalog
SELECT current_catalog()


-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS sql_script_lab;
USE SCHEMA sql_script_lab;

-- COMMAND ----------

CREATE OR REPLACE TABLE trips AS
SELECT * FROM samples.nyctaxi.trips;