# SQL Scripting and Stored Procedures in Databricks

| Field           | Details       | Description                                                                 |
|-----------------|---------------|-----------------------------------------------------------------------------|
| Duration        | 45 minutes   | Estimated duration to complete the lab(s). |
| Level           | 200 | Target difficulty level for participants (100 = beginner, 200 = intermediate, 300 = advanced). |
| Lab Status      | Active | See descriptions in main repo README. |
| Course Location | N/A           | Indicates where the lab is hosted. <br> - **N/A** - Lab is only available in this repo. <br> - **Course name** - Lab has been moved into a full Databricks Academy course. |
| Developer       | Rupesh Sharma | Primary developer(s) of the lab, separated by commas.  |
| Reviewer        | Peter Styliadis | Subject matter expert reviewer(s), separated by commas.|
| Product Version         | N/A         | Specify a product version if applicable If not, use **N/A**. | 
---

## Description  
This lab covers advanced SQL programming techniques in Databricks, progressing from foundational scripting concepts to sophisticated stored procedures. Learners will master SQL scripting fundamentals including compound statements, variables, conditional logic, loops, and error handling using NYC taxi data. Building on these skills, they'll create reusable stored procedures with parameters, conditional logic, error handling, and dynamic SQL execution. By completion, learners will confidently build modular, fault-tolerant SQL workflows that encapsulate complex business logic and enable consistent data processing.

## Learning Objectives
- Organize SQL operations using compound statements and variables to create parameterized, reusable scripts
- Implement control flow with conditional logic and loops to automate repetitive data processing tasks
- Build resilient scripts using error handling to validate data quality and manage exceptions gracefully
- Create and execute parameterized stored procedures with conditional logic and error handling for reusable workflows
- Implement dynamic SQL execution using EXECUTE IMMEDIATE to build flexible procedures for automated data quality monitoring and business reporting

## Requirements & Prerequisites  
Before starting this lab, ensure you have:  
- A **Databricks** Workspace with Unity Catalog enabled 
- Basic familiarity with Databricks notebooks and the Databricks Workspace
- Access to a SQL Warehouse
- Ability to create a catalog in your Workspace
- Intermediate knowledge of SQL


## Contents  

This repository includes: 

- **1 Lab - SQL Scripting** notebook 
- **2 Lab - Stored Procedures** notebook  
- Images and supporting materials


## Getting Started  
1. Open the main lab notebook **1 Lab - SQL Scripting**.  
1. Follow the instructions step by step. 
