-- Databricks notebook source
-- MAGIC %run ./Classroom-Setup-Common

-- COMMAND ----------


CREATE OR REPLACE PROCEDURE create_table_from_file (
  -- Name of the source file located in user's volume
  input_file_name STRING,

  -- Catalog that owns the raw file in the volume under /Volumes/<catalog>
  user_catalog STRING,

  -- Target Unity Catalog catalog where the table will be created
  out_catalog STRING,

  -- Target schema within the output catalog
  out_schema STRING,

  -- Name of the output table to create
  out_table_name STRING
)
LANGUAGE SQL
SQL SECURITY INVOKER
COMMENT '
  Creates a managed Delta table from a file stored in a Databricks volume.

  The procedure constructs a source file path using the volume and
  input file name, then creates a fully qualified output table using the provided
  catalog, schema, and table name.

  If the target table already exists, it is dropped and recreated. The table is
  created using read_files(), and the _rescued_data column is excluded from the
  final schema.

  Upon completion, the procedure returns a small result set describing the
  operation, including the source file path and target table details.
'
AS
BEGIN
  -- Fully qualified target table name: catalog.schema.table
  DECLARE full_output_table STRING;

  -- Dynamic SQL statement used to drop the target table if it exists
  DECLARE drop_table STRING;

  -- Full volume path to the source file in the user's catalog
  DECLARE users_volume_path STRING;

  -- Dynamic SQL statement used to create the table from the source file
  DECLARE sql_create_table STRING;

  -- Build catalog.schema.table name
  SET full_output_table = out_catalog || '.' || out_schema || '.' || out_table_name;

  -- Build the marketplace volume file path
  SET users_volume_path =
    '/Volumes/' || user_catalog || '/' || out_schema || '/full_data/' || input_file_name;

  -- Drop table if it exists so it can be recreated
  SET drop_table = 'DROP TABLE IF EXISTS ' || full_output_table;
  EXECUTE IMMEDIATE drop_table;

  -- Create the table from the source file, excluding _rescued_data
  SET sql_create_table = 'CREATE TABLE IF NOT EXISTS ' || full_output_table || ' AS
                          SELECT * EXCEPT (_rescued_data)
                          FROM read_files("' || users_volume_path || '")';

  EXECUTE IMMEDIATE sql_create_table;

  -- Return a small result set indicating success
  DROP TEMPORARY TABLE IF EXISTS create_table_notes;

  CREATE TEMPORARY TABLE create_table_notes (
    Info STRING,
    Details STRING
  );

  INSERT INTO create_table_notes VALUES
    ('Table Created','Success'),
    ('Source File Used', users_volume_path),
    ('Catalog', out_catalog),
    ('Schema', out_schema),
    ('Created Table', out_table_name);

  SELECT *
  FROM create_table_notes;
END;


-- COMMAND ----------

-- line_items_poutine_sales_expanded_multi_basket.csv
CALL create_table_from_file (
  input_file_name => 'line_items_poutine_sales_expanded_multi_basket.csv',
  user_catalog => my_catalog,
  out_catalog => my_catalog,
  out_schema => my_schema,
  out_table_name => 'line_items_poutine_sales'
)

-- COMMAND ----------

-- products_poutine_expanded.csv
CALL create_table_from_file (
  input_file_name => 'products_poutine_expanded.csv',
  user_catalog => my_catalog,
  out_catalog => my_catalog,
  out_schema => my_schema,
  out_table_name => 'products_poutine'
)

-- COMMAND ----------

-- products_poutine_expanded.csv
CALL create_table_from_file (
  input_file_name => 'stores_canada_with_latlong.csv',
  user_catalog => my_catalog,
  out_catalog => my_catalog,
  out_schema => my_schema,
  out_table_name => 'stores_canada'
)