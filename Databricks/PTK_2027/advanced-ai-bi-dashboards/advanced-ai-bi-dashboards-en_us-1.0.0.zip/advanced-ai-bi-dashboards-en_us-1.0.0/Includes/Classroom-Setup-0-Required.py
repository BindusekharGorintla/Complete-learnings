# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------


####################################################################################
## Use the SQL variable from the common setup to make a python variable to use in the setup below
####################################################################################
my_catalog = (
    spark.sql("SELECT my_catalog AS my_catalog")
         .collect()[0]["my_catalog"]
)


my_schema = (
    spark.sql("SELECT my_schema AS my_schema")
         .collect()[0]["my_schema"]
)


#####################
## Create Volumes 
#####################
volume_name = 'full_data'
spark.sql(f'CREATE VOLUME IF NOT EXISTS {my_catalog}.{my_schema}.{volume_name}')

graphic_volume_name = 'corporate_images'
spark.sql(f'CREATE VOLUME IF NOT EXISTS {my_catalog}.{my_schema}.{graphic_volume_name}')

# COMMAND ----------

import os
import shutil

# COMMAND ----------

def copy_file_to_volume(
    src_workspace_path: str,
    target_volume_path: str,
    overwrite: bool = False
):
    """
    Copy a file from a Databricks workspace path to a Unity Catalog volume.

    Parameters
    ----------
    src_workspace_path : str
        Full workspace path, for example
        /Workspace/Users/user@databricks.com/data/file.csv

    target_volume_path : str
        Full volume path, for example
        /Volumes/catalog/schema/volume/file.csv

    overwrite : bool, default False
        Whether to overwrite the file if it already exists
    """
    print('------------------------------------------------------')
    # Check if source file exists
    if not os.path.exists(src_workspace_path):
        raise FileNotFoundError(
            f'Source file does not exist: {src_workspace_path}'
        )

    # Check if target file exists
    if os.path.exists(target_volume_path) and not overwrite:
        print(f'File already exists at target location. Skipping copy: {target_volume_path}')
    else:
        # Copy file
        shutil.copy(src_workspace_path, target_volume_path)
        print(f'Copied file from "{src_workspace_path}" ---> "{target_volume_path}"')
    print('------------------------------------------------------\n')

# COMMAND ----------

########################################
## Get user's source file path
########################################
# Get the current working directory
current_dir = os.getcwd()

# Build the data folder path
data_folder = os.path.join(current_dir, "Includes", "data")

# Print the source file path
print(f"User's source file path: {data_folder}/")


########################################
## Move files to volumes
########################################

## Copy file to volume
poutine_sales_src = copy_file_to_volume(
    src_workspace_path=f"{data_folder}/line_items_poutine_sales_expanded_multi_basket.csv",
    target_volume_path=f"/Volumes/{my_catalog}/{my_schema}/{volume_name}/line_items_poutine_sales_expanded_multi_basket.csv",
    overwrite=False
)

## Copy file to volume
poutine_sales_src = copy_file_to_volume(
    src_workspace_path=f"{data_folder}/products_poutine_expanded.csv",
    target_volume_path=f"/Volumes/{my_catalog}/{my_schema}/{volume_name}/products_poutine_expanded.csv",
    overwrite=False
)

## Copy file to volume
poutine_sales_src = copy_file_to_volume(
    src_workspace_path=f"{data_folder}/stores_canada_with_latlong.csv",
    target_volume_path=f"/Volumes/{my_catalog}/{my_schema}/{volume_name}/stores_canada_with_latlong.csv",
    overwrite=False
)

## Copy file to volume (image file)
copy_file_to_volume(
    src_workspace_path=f"{data_folder}/poutine_corporate_icon.png",
    target_volume_path=f"/Volumes/{my_catalog}/{my_schema}/{graphic_volume_name}/poutine_corporate_icon.png",
    overwrite=False
)


# COMMAND ----------

def display_config_values(config_values):
    """
    Displays list of key-value pairs as rows of HTML text and textboxes
    
    param config_values: 
        list of (key, value) tuples
        
    Returns
    ----------
    HTML output displaying the config values
    Example
    --------
    display_config_values([('catalog', 'your catalog'),('schema','your schema')])
    """
    html = """<table style="width:100%">"""
    for name, value in config_values:
        html += f"""
        <tr>
            <td style="white-space:nowrap; width:1em">{name}:</td>
            <td><input type="text" value="{value}" style="width: 100%"></td></tr>"""
    html += "</table>"
    displayHTML(html)


display_config_values(
    [
        ("User Catalog", my_catalog),
        ("User Schema", my_schema),
        ("Volume", volume_name)
    ]
)