-- Databricks notebook source
-- MAGIC %md
-- MAGIC ![DB Academy](./Includes/images/db-academy.png)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Lab - Sales Overview Page
-- MAGIC
-- MAGIC ## Overview
-- MAGIC
-- MAGIC This hands-on lab guides you through building a comprehensive AI/BI dashboard in Databricks that visualizes poutine sales data across Canada using a metric view. 
-- MAGIC
-- MAGIC You will create an interactive Sales Overview page featuring multiple visualization types including counter widgets, combo charts, area charts, pivot tables, and maps. The lab demonstrates how to leverage semantic metadata from metric views to automatically format currency values, apply display names, and create professional-looking dashboards with minimal configuration.
-- MAGIC
-- MAGIC Through this exercise, you will learn to build production-ready business intelligence dashboards that provide stakeholders with actionable insights into sales performance, product categories, geographic distribution, and key performance indicators. The dashboard will serve as a foundation for data-driven decision making and can be easily extended with additional pages and visualizations.
-- MAGIC
-- MAGIC ## Learning Objectives
-- MAGIC
-- MAGIC By the end of this notebook, you will be able to:
-- MAGIC
-- MAGIC - Create interactive counter widgets to display key performance indicators with year-over-year comparisons
-- MAGIC - Build combo charts that effectively combine multiple measures (bar and line) on shared axes
-- MAGIC - Implement area charts for time-series analysis of rolling metrics by category
-- MAGIC - Design pivot tables with conditional formatting and color scales for hierarchical data exploration
-- MAGIC - Configure geographic visualizations using point maps with size and color encoding for location-based insights
-- MAGIC
-- MAGIC #### Final Deliverable - Page 1 Sales Overview
-- MAGIC A fully functional Sales Overview dashboard page with 8+ interactive visualizations displaying poutine sales metrics, ready for stakeholder consumption and decision-making.
-- MAGIC <br></br>
-- MAGIC <img src="./Includes/images/dashboard_01_sales_overview.png" width="800">
-- MAGIC

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## REQUIRED - SELECT A COMPUTE ENVIRONMENT
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select a SQL Warehouse</strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC Before starting this notebook, select the required compute environment.
-- MAGIC - **SQL Warehouse** (X-Small is sufficient)
-- MAGIC
-- MAGIC To select a SQL Warehouse:
-- MAGIC
-- MAGIC 1. Select the compute tile in the top-right corner of the notebook.
-- MAGIC 2. If your SQL Warehouse is already listed, select it.
-- MAGIC 3. If it is not visible, select **More** > **SQL Warehouse**, then choose your SQL Warehouse from the list.
-- MAGIC
-- MAGIC **NOTE:**  This notebook was **developed and tested using a SQL Warehouse**. Other compute options may work but are not guaranteed to behave the same or support all features demonstrated.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## A. REQUIRED - Classroom Setup

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC #### PREREQUISITE - ENVIRONMENT SETUP
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     1 Lab - Create the Metric View for the AI-BI Dashboard
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC   Before running this notebook, make sure you have completed the previous notebook, <strong>1 Lab - Create the Metric View for the AI-BI Dashboard</strong>.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## B. Create Page 1 - Sales Overview

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B1. Add a Text Box Page Description
-- MAGIC
-- MAGIC 1. Select the **Sales Overview** tab.
-- MAGIC
-- MAGIC 2. Select **Add a text box** and drag it to the top of the canvas.
-- MAGIC
-- MAGIC 3. Resize the text box to a height of two blocks.
-- MAGIC
-- MAGIC 4. Enter the following markdown into the text box:
-- MAGIC
-- MAGIC ```text
-- MAGIC # Poutine Sales Overview
-- MAGIC This page provides a high-level view of poutine sales performance across Canada.
-- MAGIC ```

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_sales_overview_title.png" width="1000">

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B2. Add 4 Key Value Counter Widgets
-- MAGIC
-- MAGIC Because this dataset is fictional and does not receive new daily data, the [**Counter** widgets](https://docs.databricks.com/aws/en/dashboards/visualizations/types#counter-visualization) in this section compare **total sales for the current year to total sales for the previous year**.
-- MAGIC
-- MAGIC **NOTE:** In a production scenario with continuously ingested data, you would typically build counter widgets that compare **year-to-date sales for the current year against year-to-date sales for the same period last year**.
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### B2.1. Total Yearly Sales vs Last Year Counter Widget
-- MAGIC
-- MAGIC 1. Add the **Total Yearly Sales vs Last Year** counter widget.
-- MAGIC
-- MAGIC    a. Select the **Add a Visualization** icon <img src="./Includes/images/icons/add_visualization.png" width="20"> from the toolbar.  
-- MAGIC    b. Drag the widget to the far left, directly below the text box.  
-- MAGIC    c. Resize the widget to **2W x 3H** blocks.
-- MAGIC
-- MAGIC 2. In the **Widget** configuration panel on the far right, set the following options:
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Select **Title** |
-- MAGIC | **Dataset** | **poutine_sales_metrics** |
-- MAGIC | **Visualization** | Counter |
-- MAGIC | **Date** | **YEARLY(transaction_date)**. By default, this is set to `MONTHLY(transaction_date)`. Select the value and change it to `YEARLY`. |
-- MAGIC | **Value** | **MEASURE(total_sales)** |
-- MAGIC | **Comparison** | **MEASURE(total_sales)** |
-- MAGIC | **Years ago offset** | Set to **1**, and for **Change** select **%** |
-- MAGIC
-- MAGIC 3. Double-click **Widget title** and replace it with: `Total Yearly Sales vs Last Year`
-- MAGIC
-- MAGIC 4. Notice that the values are automatically formatted and abbreviated. This is because semantic metadata was defined for the **total_sales** measure in the metric view.
-- MAGIC
-- MAGIC ##### **total_sales** `measure` in the metric view:
-- MAGIC <br>
-- MAGIC
-- MAGIC ```yaml
-- MAGIC   - name: total_sales
-- MAGIC     expr: sum(source.unit_price)
-- MAGIC     comment: Total sales amount (sum of unit prices)
-- MAGIC     display_name: Total Sales
-- MAGIC     format:
-- MAGIC       type: currency
-- MAGIC       currency_code: CAD
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC       abbreviation: compact
-- MAGIC     synonyms:
-- MAGIC       - sales
-- MAGIC       - revenue
-- MAGIC ```
-- MAGIC
-- MAGIC **NOTE:** This dataset is fictional. The most recent sales date available is **01/05/2026**. This counter compares **total sales for the current year to total sales for the entire previous year**, not year-to-date sales for the same date last year.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_01_counter1value.png" width="1000">

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### B2.2. Add 3 Additional Counter Widgets by Province
-- MAGIC
-- MAGIC Complete the steps below to add three additional counter widgets, arranged in a 2 x 2 grid as shown in the example.
-- MAGIC
-- MAGIC **Checkpoint**
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_checkpoint-02counters.png" width="900">
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### B2.2A. Clone the Original Counter Widget
-- MAGIC
-- MAGIC 1. Clone the first **Counter** widget and place it to the right of the original widget: **More options** icon > **Clone**.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### B2.2B. Configure the Gross Profit Counter
-- MAGIC
-- MAGIC 1. Configure the cloned widget to the right of the first counter using the following options:
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Confirm **Title** is selected |
-- MAGIC | **Dataset** | **poutine_sales_metrics** |
-- MAGIC | **Visualization** | Counter |
-- MAGIC | **Date** | **YEARLY(transaction_date)** |
-- MAGIC | **Value** | **MEASURE(gross_profit)** |
-- MAGIC | **Comparison** | **MEASURE(gross_profit)** |
-- MAGIC | **Years ago offset** | Set to **1**, and for **Change** select **%** |
-- MAGIC
-- MAGIC 2. Set the widget title to: `Gross Profit This Year vs Last Year`
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### B2.2C. Configure the Units Sold Counter
-- MAGIC
-- MAGIC 1. Clone the previous widget and place it below the **Total Yearly Sales vs Last Year** counter. Update the following options:
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Confirm **Title** is selected |
-- MAGIC | **Dataset** | **poutine_sales_metrics** |
-- MAGIC | **Visualization** | Counter |
-- MAGIC | **Date** | **YEARLY(transaction_date)** |
-- MAGIC | **Value** | **MEASURE(units_sold)** |
-- MAGIC | **Comparison** | **MEASURE(units_sold)** |
-- MAGIC | **Years ago offset** | Set to **1**, and for **Change** select **%** |
-- MAGIC
-- MAGIC 2. Set the widget title to: `Units Sold This Year vs Last Year`
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### B2.2D. Configure the Cost of Goods Sold Counter
-- MAGIC
-- MAGIC 1. Clone the previous widget and place it below the **Gross Profit This Year vs Last Year** counter. Update the following options:
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Confirm **Title** is selected |
-- MAGIC | **Dataset** | **poutine_sales_metrics** |
-- MAGIC | **Visualization** | Counter |
-- MAGIC | **Date** | **YEARLY(transaction_date)** |
-- MAGIC | **Value** | **MEASURE(cost_of_goods_sold)** |
-- MAGIC | **Comparison** | **MEASURE(cost_of_goods_sold)** |
-- MAGIC | **Years ago offset** | Set to **1**, and for **Change** select **%** |
-- MAGIC
-- MAGIC 2. Set the widget title to: `COGS This Year vs Last Year`
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B3. Add a Yearly Total Sales and Gross Profit Combo (Bar–Line) Chart
-- MAGIC
-- MAGIC In this section, you will create a [**Combo** widget](https://docs.databricks.com/aws/en/dashboards/visualizations/types#combo-chart) that displays **Total Sales** and **Gross Profit** by year on a **shared Y axis**.
-- MAGIC
-- MAGIC 1. In the toolbar, select the **Visualization** icon.
-- MAGIC
-- MAGIC 2. Drag a new widget onto the dashboard.
-- MAGIC
-- MAGIC 3. Resize the widget match the height of your counter widgets, and the remaining width to the right.
-- MAGIC
-- MAGIC 4. Move the widget to the right of the **2 x 2 counter widgets**.
-- MAGIC
-- MAGIC 5. In the **Widget** configuration panel, set the following options:
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Confirm **Title** is selected |
-- MAGIC | **Dataset** | **poutine_sales_metrics** |
-- MAGIC | **Visualization** | Combo |
-- MAGIC | **X axis** | **YEARLY(transaction_date)**. The default is **MONTHLY(transaction_date)**. Modify it. |
-- MAGIC | **Y axis** | - Bar **MEASURE(total_sales)** <br> - Line **MEASURE(gross_profit)** |
-- MAGIC | **Y axis options** | - Select **More options** for the Y axis <br> - Deselect `Show axis title` and `Show gridlines` |
-- MAGIC
-- MAGIC 6. Set the widget title to: `Sales and Gross Profit Comparison in ($)`
-- MAGIC
-- MAGIC 7. Notice that the visualization automatically uses the following from the metric view:
-- MAGIC    - The `display_name` for **Transaction Date**
-- MAGIC    - Currency formatting and compact notation for both measures on the Y axis

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_checkpoint-combo_chart.png" width="1000">

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B4. Add an Area Widget
-- MAGIC
-- MAGIC In this section, you will use the assistant to create an [**Area** widget](https://docs.databricks.com/aws/en/dashboards/visualizations/types#area-visualization) that displays **rolling 7-day sales by category**.
-- MAGIC
-- MAGIC 1. In the toolbar, select the **Visualization** icon.
-- MAGIC
-- MAGIC 2. Drag a new widget onto the dashboard.
-- MAGIC
-- MAGIC 3. Resize the widget to **6H** blocks and across the entire canvas width.
-- MAGIC
-- MAGIC 4. Move the widget below the counters and combo chart.
-- MAGIC
-- MAGIC 5. Ask the assistant to create the following visualization: `Rolling 7-day sales area chart by each product category`
-- MAGIC
-- MAGIC 6. Check if the visualization looks similar to the checkpoint example below. If needed, adjust the widget settings manually. 
-- MAGIC Notice that:
-- MAGIC    - The `display_names` use the names defined in the metric view
-- MAGIC    - **Trailing 7 Day Total Sales** and **Transaction Date** are automatically formatted using the `format` and `display_name` defined in the metric view

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_area_ai.png" alt='Checkpoint' width="1000">  
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B5. Add a Sales by Category and Subcategory Pivot Table
-- MAGIC
-- MAGIC In this section, you will create a [**Pivot** widget](https://docs.databricks.com/aws/en/dashboards/visualizations/types#pivot-visualization) that displays sales by category and subcategory.
-- MAGIC
-- MAGIC 1. In the toolbar, select the **Visualization** icon.
-- MAGIC
-- MAGIC 2. Drag a new widget onto the dashboard.
-- MAGIC
-- MAGIC 3. Resize the widget to **7H** blocks and half the canvas width.
-- MAGIC
-- MAGIC 4. Move the widget below the **Area** widget on the far left.
-- MAGIC
-- MAGIC 5. In the **Widget** configuration panel, configure the following options:
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Select **Title** |
-- MAGIC | **Dataset** | **poutine_sales_metrics** |
-- MAGIC | **Visualization** | Pivot |
-- MAGIC | **Rows** | - **product_category** <br> - **product_subcategory** <br> - **product_name** |
-- MAGIC | **Values** | - **MEASURE(total_sales)** |
-- MAGIC | **Color scale** | Select **MEASURE(total_sales)** > **Style** > **Color scale** to apply a color scale to the values. You may choose any color scale you prefer. |
-- MAGIC
-- MAGIC 6. Set the widget title to: `Sales by Product Category, Subcategory, and Product Name`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_checkpoint-pivot.png" width="1000">

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B6. Add a Gross Margin by Subcategory Horizontal Bar Chart
-- MAGIC
-- MAGIC In this section, we will use the assistant to create a [**Bar** widget](https://docs.databricks.com/aws/en/dashboards/visualizations/types#bar-chart) that displays gross profit by subcategory.
-- MAGIC
-- MAGIC 1. In the toolbar, select the **Visualization** icon.
-- MAGIC
-- MAGIC 2. Resize the widget the same size as the pivot chart and place to the right of it.
-- MAGIC
-- MAGIC 3. Ask the assistant to create the following visualization: `Gross Profit by Subcategory Grouped by Product Category`
-- MAGIC
-- MAGIC 4. Check if the visualization looks similar to the checkpoint example below.  
-- MAGIC    - The bar chart will initially be vertical. We will convert it to a horizontal bar chart in the next step.
-- MAGIC    - If needed, adjust the widget settings manually.
-- MAGIC
-- MAGIC 5. After the visualization is created, select the arrows between the **X axis** and **Y axis** to convert the chart to a horizontal bar chart.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_checkpoint-category_horizontal.png" alt='Checkpoint' width="1000">  

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B7. Add a Point Map of Store Locations Sized by Gross Profit
-- MAGIC
-- MAGIC In this section, you will create a [**Point Map** widget](https://docs.databricks.com/aws/en/dashboards/visualizations/types#point-map) that displays store locations sized by gross profit.
-- MAGIC
-- MAGIC 1. In the toolbar, select the **Visualization** icon.
-- MAGIC
-- MAGIC 2. Drag a new widget onto the dashboard.
-- MAGIC
-- MAGIC 3. Resize the widget to **8H** blocks and half the canvas.
-- MAGIC
-- MAGIC 4. Move the widget below the **Pivot** widget.
-- MAGIC
-- MAGIC 5. In the **Widget** configuration panel, configure the following options:
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Select **Title** |
-- MAGIC | **Dataset** | **poutine_sales_metrics** |
-- MAGIC | **Visualization** | Point map |
-- MAGIC | **Coordinates** | Longitude: **store_longitude** <br> Latitude: **store_latitude** |
-- MAGIC | **Color** | **store_location** |
-- MAGIC | **Size** | **MEASURE(gross_profit)** |
-- MAGIC | **Tooltip** | - **MEASURE(gross_profit)** <br> - **MEASURE(total_sales)** |
-- MAGIC
-- MAGIC 6. Set the widget title to: `Store Locations Sized by Gross Profit`
-- MAGIC
-- MAGIC 7. Hover over locations on the map and observe the tooltip, which displays additional information for the end user.
-- MAGIC
-- MAGIC    **NOTE:** The `display_name` defined in the metric view is not currently shown in the tooltip.
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_point_map.png" alt='Checkpoint' width="1000">  

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B8. Add a Sankey Diagram for Total Sales by Province, Category, and Subcategory
-- MAGIC
-- MAGIC In this section, you will create a [**Sankey** widget](https://docs.databricks.com/aws/en/dashboards/visualizations/types#sankey-diagram) that visualizes the flow of **total sales from provinces to product categories and subcategories**.
-- MAGIC
-- MAGIC 1. In the toolbar, select the **Visualization** icon.
-- MAGIC
-- MAGIC 2. Drag a new widget onto the dashboard to the right of the **Point Map**.
-- MAGIC
-- MAGIC 3. Move the widget to the right of the **Point Map**.
-- MAGIC
-- MAGIC 4. In the **Widget** configuration panel, configure the following options:
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Select **Title** |
-- MAGIC | **Dataset** | **poutine_sales_metrics** |
-- MAGIC | **Visualization** | Sankey |
-- MAGIC | **Stages** | **store_provinces** <br> **product_category** <br> **product_subcategory** |
-- MAGIC | **Value** | **MEASURE(total_sales)** |
-- MAGIC
-- MAGIC 5. Set the widget title to: `Total Sales Flow: Provinces > Category > Subcategory`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_sankey.png" alt='Checkpoint' width="1000">  

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## C. Modify Dashboard Theme
-- MAGIC
-- MAGIC Now that the **Sales Overview** page is complete, we will update the [theme of the AI/BI dashboard](https://docs.databricks.com/aws/en/dashboards/settings#theme-settings).
-- MAGIC
-- MAGIC While dashboards support extensive customization to match your organization’s branding and preferences, this workshop will use a specific theme for consistency.
-- MAGIC
-- MAGIC 1. Select the **More options** icon (three ellipses) near the compute selector.
-- MAGIC
-- MAGIC 2. Select **Settings**.
-- MAGIC
-- MAGIC 3. In the **Settings** panel on the **Theme** tab, notice that you can customize various options such as colors and themes to align with your organization's standards.
-- MAGIC
-- MAGIC 4. For this workshop, set the **Theme** to `Cascade`.
-- MAGIC
-- MAGIC 5. Scroll through the dashboard to review the updated theme.
-- MAGIC
-- MAGIC 6. Optionally, explore other settings you may want to customize in your own dashboards themes.
-- MAGIC
-- MAGIC 7. While in **Settings**, select the **General** tab. 
-- MAGIC
-- MAGIC 8. In the **General** tab you can:
-- MAGIC     - Add **Tags**
-- MAGIC     - Specify the **Locale**
-- MAGIC     - Modify how to **Apply filters**
-- MAGIC     - **Enable Genie**. By default, an **Auto-generate Genie space** is created.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC <br/>
-- MAGIC <img src="./Includes/images/dashboard_01_sales_overview.png" width="800">

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## D. Proceed to the Next Notebook
-- MAGIC
-- MAGIC After completing Page 1, proceed to the next notebook **3 Lab - Dashboard Management and Automation** to learn how to publish the dashboard, schedule automatic refreshes to keep it up to date for downstream consumers, and use AI/BI Genie.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## E. Summary and Key Takeaways
-- MAGIC
-- MAGIC #### Summary:
-- MAGIC - Successfully built a comprehensive Sales Overview dashboard with 8+ interactive visualizations
-- MAGIC - Leveraged semantic metadata from metric views for automatic formatting and display names
-- MAGIC - Created diverse visualization types including counters, combo charts, maps, and pivot tables
-- MAGIC - Applied professional theming and customization options for production-ready dashboards
-- MAGIC
-- MAGIC
-- MAGIC #### Key Takeaways:
-- MAGIC - Counter widgets provide effective year-over-year KPI comparisons with minimal configuration
-- MAGIC - Semantic metadata in metric views eliminates manual formatting and ensures consistency
-- MAGIC - AI assistant accelerates visualization creation while maintaining customization flexibility
-- MAGIC - Geographic visualizations with size/color encoding reveal location-based performance insights
-- MAGIC - Sankey diagrams effectively show data flow relationships across multiple dimensions
-- MAGIC - Dashboard themes and settings enable organizational branding and user experience optimization

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
-- MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
-- MAGIC <script>
-- MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
-- MAGIC </script>