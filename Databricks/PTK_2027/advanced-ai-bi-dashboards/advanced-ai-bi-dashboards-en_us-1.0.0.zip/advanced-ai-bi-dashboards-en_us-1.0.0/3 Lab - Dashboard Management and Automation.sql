-- Databricks notebook source
-- MAGIC %md
-- MAGIC ![DB Academy](./Includes/images/db-academy.png)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Lab - Dashboard Management and Automation
-- MAGIC
-- MAGIC ## Overview
-- MAGIC
-- MAGIC In this notebook, you will learn how to publish, certify, and manage AI/BI Dashboards in Databricks. You'll explore the complete lifecycle of dashboard management, from publishing for business users to setting up automated refresh schedules. The lab covers essential production practices including dashboard certification, integration with Databricks One, and using Genie for natural language analytics.
-- MAGIC
-- MAGIC You'll work with a poutine sales dashboard, learning how to make it available to stakeholders, add visual elements like corporate images, and implement automated data refresh workflows using both built-in scheduling and Lakeflow Jobs. This lab emphasizes real-world scenarios where dashboards need to stay current with changing data and be accessible to business users who may not have technical backgrounds.
-- MAGIC
-- MAGIC ## Learning Objectives
-- MAGIC
-- MAGIC - Publish AI/BI Dashboards with appropriate data permission settings for business users
-- MAGIC - Apply certification status to dashboards to indicate data quality and governance standards
-- MAGIC - Navigate and utilize Databricks One interface for business user dashboard access
-- MAGIC - Configure automated dashboard refresh schedules and subscription notifications
-- MAGIC - Implement advanced orchestration workflows using Lakeflow Jobs with table update triggers

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## REQUIRED - SELECT A COMPUTE ENVIRONMENT
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select a SQL Warehouse</strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC Before starting this notebook, select the required compute environment listed below.
-- MAGIC
-- MAGIC - **SQL Warehouse**  (X-Small is sufficient)
-- MAGIC
-- MAGIC **NOTE:**  This notebook was **developed and tested using a SQL Warehouse**. Other compute options may work but are not guaranteed to behave the same or support all features demonstrated.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## A. REQUIRED - Classroom Setup

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC #### PREREQUISITE - ENVIRONMENT SETUP
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     Complete All Prior Notebooks (0 - Required Setup, 1 Lab, 2 Lab)
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC Before running this notebook, make sure you have completed all of the previous notebooks.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 1. Run the cell below to set your default catalog and schema. 

-- COMMAND ----------

-- MAGIC %run ./Includes/Classroom-Setup-3

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## B. Publish and Certify an AI/BI Dashboard
-- MAGIC Once your dashboard is complete, you'll want to publish and certify it for business users.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B1. Publish an AI/BI Dashboard
-- MAGIC
-- MAGIC In this section, you will publish the AI/BI Dashboard for downstream consumers. When [publishing a dashboard](https://docs.databricks.com/aws/en/dashboards/share), you can choose how data access is handled for viewers.
-- MAGIC
-- MAGIC
-- MAGIC For this workshop, complete the following steps:
-- MAGIC
-- MAGIC 1. In the top-right corner of the dashboard, select **Publish**.
-- MAGIC
-- MAGIC    **Share data permission (default):** Viewers run queries using the publisher's data permissions. This allows users to view the dashboard even if they do not have direct access to the underlying data. 
-- MAGIC
-- MAGIC    ✅ **Why teams typically use this**
-- MAGIC    - Faster viewer experience via shared dashboard caching
-- MAGIC    - Lower compute cost (fewer repeated queries across viewers)
-- MAGIC    - Simpler sharing experience — viewers don’t need direct access to the underlying data to view the dashboard
-- MAGIC
-- MAGIC
-- MAGIC    **Individual data permission:**  Viewers run queries using their own credentials. Their data permissions determine what results they see, and they must have access to the underlying data.
-- MAGIC    
-- MAGIC    💡 **When to use this**
-- MAGIC    - You need per-viewer enforcement (for example, row-level or column-level access)
-- MAGIC    - Different viewers should see different results from the same dashboard
-- MAGIC
-- MAGIC **NOTE:** Compute access is still granted using the publisher's credentials. Cache is per-user and not shared. 
-- MAGIC
-- MAGIC 2. Select **Share data permission (default)**.
-- MAGIC
-- MAGIC 3. Select **Publish**.
-- MAGIC
-- MAGIC 4. After publishing, select **View Published** at the top of the dashboard and scroll through your published dashboard.  
-- MAGIC    - **NOTE:** To return to editing mode, select **Edit Draft** at the top of the dashboard.
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B2. Add a Certified Status to a Dashboard
-- MAGIC
-- MAGIC The **certified status** system tag allows you to label objects, such as catalogs, schemas, dashboards, and tables, with indicators of data quality or lifecycle status. This is a system-governed tag with two possible values: **certified** and **deprecated**.
-- MAGIC
-- MAGIC Complete the following steps to certify the dashboard:
-- MAGIC
-- MAGIC 1. Return to **Edit Draft** mode in your dashboard.
-- MAGIC
-- MAGIC 2. Select the **More options** icon ![More Options](./Includes/images/more_options.png) at the top of the dashboard.
-- MAGIC
-- MAGIC 3. Select **Assign certification** > **Certified**.
-- MAGIC
-- MAGIC 4. Select **Save**.
-- MAGIC
-- MAGIC 5. Near the dashboard name you should see the **Certified** icon.
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_certified.png" width="500">
-- MAGIC
-- MAGIC <br></br>
-- MAGIC
-- MAGIC **NOTES:** [Flag data as certified or deprecated](https://docs.databricks.com/aws/en/data-governance/unity-catalog/certify-deprecate-data)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B3. View the AI/BI Dashboard in Databricks One
-- MAGIC
-- MAGIC Databricks One is a user interface designed for business users. It provides a single, intuitive entry point to interact with data and AI in Databricks without needing to navigate technical concepts such as clusters, queries, models, or notebooks.
-- MAGIC
-- MAGIC Complete the following steps to view the AI/BI Dashboard in **Databricks One**:
-- MAGIC
-- MAGIC 1. Select the **App** <img src="./Includes/images/workspace_apps.png" width="25"> icon in the top-right corner of the workspace.
-- MAGIC
-- MAGIC 2. Right-click **Databricks One** and select **Open Link in New Tab**.
-- MAGIC
-- MAGIC 3. In **Databricks One**, locate your dashboard and select the tile to open it. Business users can quickly discover and access available resources from this interface.
-- MAGIC
-- MAGIC 4. Close the **Databricks One** tab and return to your dashboard.
-- MAGIC
-- MAGIC **NOTES:**  
-- MAGIC - [What is Databricks One?](https://docs.databricks.com/aws/en/workspace/databricks-one)
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B4. Publish Updates in Your AI/BI Dashboard (Adding an Image)
-- MAGIC
-- MAGIC After creating a dashboard, you may need to make updates, such as adding new visualizations, text, pages, or images.
-- MAGIC
-- MAGIC In this example, you will add a corporate poutine image to the **Sales Overview** page. The image is stored in a Databricks volume: **labuser.poutine_aibi.corporate_images**.
-- MAGIC
-- MAGIC Complete the following steps:
-- MAGIC
-- MAGIC 1. Navigate to your AI/BI Dashboard and select **Edit Draft**.  
-- MAGIC    - If you are already in draft mode, the top of the dashboard will display **View Published**.
-- MAGIC
-- MAGIC 2. Reduce the **Poutine Sales Overview** header text widget one block to the left.
-- MAGIC
-- MAGIC 3. In the open space, add a **Text box** sized **1L x 1H**.
-- MAGIC
-- MAGIC 4. From your AI/BI Dashboard page, copy the Workspace URL from the beginning all the way after `.com` and paste it as the value for the `workspace_URL` SQL variable below.  
-- MAGIC    - **Example:** `https://databricks-instance.cloud.databricks.com`
-- MAGIC
-- MAGIC 5. Get the path to the **poutine_corporate_icon.png** image using the workspace sidebar:
-- MAGIC    - Select the **Catalog** icon
-- MAGIC    - Expand the **labuser** catalog
-- MAGIC    - Expand the **poutine_aibi** schema
-- MAGIC    - Expand **Volumes**
-- MAGIC    - Expand **corporate_images**
-- MAGIC    - Right-click **poutine_corporate_icon.png** and select **Copy volume file path**
-- MAGIC    - Paste the value into the `img_vol_path` SQL variable below
-- MAGIC
-- MAGIC 6. Run the cell below and copy the output.  
-- MAGIC    - **Example output:** ```https://myworkspace.cloud.databricks.com/ajax-api/2.0/fs/files/Volumes/labuser_peter_styliadis/poutine_aibi/corporate_images/poutine_corporate_icon.png```
-- MAGIC
-- MAGIC 7. In your dashboard, add the image to the new text box:
-- MAGIC    - Select the new blank text widget
-- MAGIC    - In the toolbar, select the **Image** icon
-- MAGIC    - Paste the copied image URL into the URL field
-- MAGIC    - Select **Save**
-- MAGIC
-- MAGIC <img src="./Includes/images/add_image_to_dashboard.png" width="600">
-- MAGIC
-- MAGIC <br></br>
-- MAGIC
-- MAGIC **NOTES:**  
-- MAGIC For more information, see the documentation on  [Image paths and URLs](https://docs.databricks.com/aws/en/dashboards/#image-paths-and-urls).
-- MAGIC

-- COMMAND ----------

DECLARE OR REPLACE VARIABLE workspace_URL STRING;
DECLARE OR REPLACE VARIABLE img_vol_path STRING;

SET VAR workspace_URL = 'YOUR_WORKSPACE_URL';
SET VAR img_vol_path = 'YOUR_VOLUME_PATH';

SELECT CONCAT(workspace_URL, '/ajax-api/2.0/fs/files/', img_vol_path) AS `Copy Image Path`;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_poutine_image.png" width="1000">

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B5. View the Published Dashboard
-- MAGIC
-- MAGIC After updating your dashboard, verify whether the changes have been published.
-- MAGIC
-- MAGIC 1. At the top of your AI/BI Dashboard, select **View Published**.
-- MAGIC
-- MAGIC 2. In published mode, notice that the **recent changes are not yet reflected in the dashboard**.
-- MAGIC
-- MAGIC 3. Select **Edit Draft** to return to edit mode.
-- MAGIC
-- MAGIC 4. Select **Publish** > **Share data permission** > **Publish**.
-- MAGIC
-- MAGIC 5. View the **Published** dashboard again and confirm that the changes are now visible.
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #1976d2;
-- MAGIC   background: #e3f2fd;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     Note
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC If you make changes to a dashboard after it has been published, you must republish the dashboard for those changes to take effect.
-- MAGIC
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## C. Enable Genie and Use Genie

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C1. View the AI/BI Dashboard Genie Space
-- MAGIC
-- MAGIC 1. View your AI/BI Dashboard in **Published** mode.
-- MAGIC
-- MAGIC 2. At the bottom of the dashboard, locate the **Ask Genie** button and select it.
-- MAGIC
-- MAGIC 3. From here, users can ask questions about the data using natural language. If you are curious, try asking a question. Here are some samples:
-- MAGIC    - _Which province has higher sales, and in which product categories?_
-- MAGIC    - _Which province has the lowest total sales flow?_
-- MAGIC
-- MAGIC **NOTE:** Notice that when you create a dashboard, Databricks automatically creates a **Genie space** for you. This allows business users to perform self-serve analytics using natural language.
-- MAGIC
-- MAGIC    - [Enable a Genie space from your dashboard](https://docs.databricks.com/aws/en/dashboards/#enable-a-genie-space-from-your-dashboard)
-- MAGIC    - [What is an AI/BI Genie space](https://docs.databricks.com/aws/en/genie/)
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## D. Schedule Dashboard Updates
-- MAGIC
-- MAGIC Once the AI/BI Dashboard is complete, you need to schedule it to refresh as your data is updated. You can refresh the dashboard manually, but scheduling automatic updates is recommended.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D1. Insert New Sales Records

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 1. Run the cell below to insert **25** new sales records into the **line_items_poutine_sales** table.
-- MAGIC
-- MAGIC    This will add new sales data for the dates from **2026-01-06 through 2026-01-10**.
-- MAGIC

-- COMMAND ----------

INSERT INTO line_items_poutine_sales (
  transaction_id,
  line_id,
  store_id,
  product_id,
  transaction_ts
)
VALUES
('TX-001622', 1622, 1, 201, '2026-01-06 09:05:00'),
('TX-001623', 1623, 2, 204, '2026-01-06 10:18:00'),
('TX-001624', 1624, 3, 211, '2026-01-06 11:42:00'),
('TX-001625', 1625, 4, 214, '2026-01-06 13:10:00'),
('TX-001626', 1626, 5, 304, '2026-01-06 16:35:00'),

('TX-001627', 1627, 6, 205, '2026-01-07 09:20:00'),
('TX-001628', 1628, 7, 202, '2026-01-07 10:50:00'),
('TX-001629', 1629, 8, 212, '2026-01-07 12:15:00'),
('TX-001630', 1630, 9, 403, '2026-01-07 14:40:00'),
('TX-001631', 1631, 10, 210, '2026-01-07 18:05:00'),

('TX-001632', 1632, 1, 206, '2026-01-08 09:10:00'),
('TX-001633', 1633, 2, 203, '2026-01-08 10:35:00'),
('TX-001634', 1634, 3, 208, '2026-01-08 12:05:00'),
('TX-001635', 1635, 4, 502, '2026-01-08 14:25:00'),
('TX-001636', 1636, 5, 213, '2026-01-08 17:55:00'),

('TX-001637', 1637, 6, 209, '2026-01-09 09:35:00'),
('TX-001638', 1638, 7, 207, '2026-01-09 11:00:00'),
('TX-001639', 1639, 8, 301, '2026-01-09 12:30:00'),
('TX-001640', 1640, 9, 214, '2026-01-09 15:10:00'),
('TX-001641', 1641, 10, 211, '2026-01-09 18:20:00'),

('TX-001642', 1642, 1, 602, '2026-01-10 09:15:00'),
('TX-001643', 1643, 2, 404, '2026-01-10 10:55:00'),
('TX-001644', 1644, 3, 205, '2026-01-10 12:40:00'),
('TX-001645', 1645, 4, 212, '2026-01-10 15:05:00'),
('TX-001646', 1646, 5, 204, '2026-01-10 18:30:00');

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D2. Manual Dashboard Refresh

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 1. Before running the cell, consider whether the AI/BI Dashboard automatically refreshes after the data is updated.
-- MAGIC
-- MAGIC    Navigate back to your dashboard in **View Published** and check the **Area** plot. Notice the last sale is still on **2026-1-5**.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 2. Notice that the new records are not automatically reflected in the dashboard. One option is to manually refresh the dashboard. 
-- MAGIC
-- MAGIC    - To do this select the **Refresh** icon at the top of the dashboard.
-- MAGIC
-- MAGIC    - Observe that the dashboard updates to include the new sales records.
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_refresh_01_manual.png" width="1100">
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D3. AI/BI Dashboard Schedules and Subscriptions
-- MAGIC
-- MAGIC Schedules automatically refresh your dashboard cache and can send dashboard snapshots (PDFs) to email subscribers and notification destinations (Slack, Microsoft Teams).
-- MAGIC
-- MAGIC ##### Permissions:
-- MAGIC - Users need at least **CAN EDIT** permissions to create schedules
-- MAGIC - Anyone with dashboard access can subscribe to existing schedules
-- MAGIC
-- MAGIC ##### Why Use Schedules?
-- MAGIC - Scheduling dashboard refreshes ensures cached data is ready before your team needs it.
-- MAGIC
-- MAGIC - **Example:** If your team views a dashboard every day at 8:00 AM, schedule it to refresh at 7:50 AM. With shared data permissions enabled, everyone will see the dashboard load instantly with fresh data already cached.
-- MAGIC
-- MAGIC [Manage scheduled dashboard updates and subscriptions](https://docs.databricks.com/aws/en/dashboards/schedule-subscribe)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### D3.1. Schedule the Dashboard Refresh and Subscribers
-- MAGIC
-- MAGIC 1. In **View Published** select **Schedule** at the top of the dashboard.
-- MAGIC
-- MAGIC 2. In the **Settings** tab, you can configure the dashboard to refresh automatically on a schedule.  
-- MAGIC    - Notice you can set frequency, time, and timezone.
-- MAGIC    
-- MAGIC    - **NOTE:** If you schedule the dashboard in your own workspace, remember to stop or remove the schedule after the lab. This is a training dashboard, and you likely do not want it to refresh continuously.
-- MAGIC
-- MAGIC 3. Select the **Subscribers** tab. From here, you can add users or notification destinations.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### D3.2. (BONUS OPTIONAL) Schedule the Dashboard Refresh with Lakeflow Jobs
-- MAGIC
-- MAGIC You can also schedule dashboard refreshes using **Lakeflow Jobs**, which lets you orchestrate an end-to-end workflow that can include:
-- MAGIC
-- MAGIC - Data ingestion
-- MAGIC - ETL processing
-- MAGIC - Dashboard refresh as part of a single pipeline
-- MAGIC - Additional orchestration options beyond basic dashboard scheduling
-- MAGIC
-- MAGIC Lakeflow Jobs also provides flexible trigger types, including:
-- MAGIC
-- MAGIC - Time-based schedules (**Scheduled** or **Continuous**)
-- MAGIC - Event-based triggers (**File arrival** or **Table updates**)
-- MAGIC
-- MAGIC In this section, you will briefly explore how Lakeflow Jobs can be used to coordinate dashboard updates as part of a broader workflow.
-- MAGIC
-- MAGIC 1. In the main navigation bar, right-click **Jobs & Pipelines** and select **Open Link in New Tab**.
-- MAGIC
-- MAGIC 2. Select **Create** > **Job**.
-- MAGIC
-- MAGIC 3. Rename the job to: `firstname_lastinitials_poutine_dashboard`
-- MAGIC
-- MAGIC 4. For this training we will keep it simple and create a single task that refreshes the dashboard.  
-- MAGIC    - **NOTE:** In production, you would typically add upstream tasks (ingestion and ETL) to orchestrate the full workflow.
-- MAGIC
-- MAGIC 5. Select **+ Add another task type**.
-- MAGIC
-- MAGIC 6. Select **Dashboard**.
-- MAGIC
-- MAGIC 7. Configure the task settings using the example below:
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | Task Name | `poutine_refresh` |
-- MAGIC | Type | **Dashboard** |
-- MAGIC | Dashboard | `Your Dashboard Name` |
-- MAGIC | SQL Warehouse | Your **Serverless SQL Warehouse** |
-- MAGIC
-- MAGIC 8. Select **Save task**.
-- MAGIC
-- MAGIC 9. In the job details pane on the right:
-- MAGIC
-- MAGIC    a. Select **Add trigger**.  
-- MAGIC       - Here you will see several options: [Automating jobs with schedules and triggers](https://docs.databricks.com/aws/en/jobs/triggers)
-- MAGIC
-- MAGIC    b. Select **Table updates**.  
-- MAGIC       - **NOTE:** This trigger refreshes the dashboard whenever the source table is updated.
-- MAGIC
-- MAGIC    c. Under **Tables**, select your source table (not the metric view, the source sales table): `YOUR_LABUSER_CATALOG.poutine_aibi.line_items_poutine_sales`
-- MAGIC
-- MAGIC    d. Click **Save**.
-- MAGIC
-- MAGIC    e. Leave the **Lakeflow Jobs** page open.
-- MAGIC
-- MAGIC <img src="./Includes/images/lakeflow_jobs_setup_checkpoint.png" width="1100">
-- MAGIC

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC
-- MAGIC 10. In Lakeflow Jobs:
-- MAGIC   - Select the **Runs** tab
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">PLEASE WAIT - READ THE FOLLOWING!</strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC Wait until you see the following icon next to your table (refresh the browser tab if necessary ~1-2 minutes)
-- MAGIC <br></br>
-- MAGIC <img src="./Includes/images/lakeflow_jobs_update_icon.png" width="500">
-- MAGIC <br></br>
-- MAGIC Then run the code below to insert records from <strong>2026-01-11 to 2026-01-15</strong> into the source table <strong>line_items_poutine_sales</strong>
-- MAGIC   </div>
-- MAGIC </div>
-- MAGIC

-- COMMAND ----------

INSERT INTO line_items_poutine_sales (
  transaction_id,
  line_id,
  store_id,
  product_id,
  transaction_ts
)
VALUES
('TX-001648', 1622, 1, 201, '2026-01-11 09:05:00'),
('TX-001649', 1623, 2, 204, '2026-01-12 10:18:00'),
('TX-001650', 1624, 3, 211, '2026-01-13 11:42:00'),
('TX-001651', 1625, 4, 214, '2026-01-14 13:10:00'),
('TX-001652', 1626, 5, 304, '2026-01-15 16:35:00')
;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 11. In the **Lakeflow Jobs** page, in the **Runs** tab.
-- MAGIC
-- MAGIC     You should see that the job was automatically triggered after the table was updated.
-- MAGIC     - **NOTES:** 
-- MAGIC         - This may take **about 1-2 minutes** to start automatically (refresh browser if necessary). 
-- MAGIC         - While waiting, explore the [Trigger jobs when source tables are updated](https://docs.databricks.com/aws/en/jobs/trigger-table-update) documentation for additional information.
-- MAGIC
-- MAGIC
-- MAGIC ##### Job Run Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/lakeflow_jobs_table_update.png" width="1000">

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 12. Once the job is complete, navigate back to your **Published** dashboard. You may need to refresh the browser tab if the dashboard is already open.
-- MAGIC
-- MAGIC     Confirm that the dashboard was refreshed as a result of the **Lakeflow Job**.
-- MAGIC
-- MAGIC <br></br>
-- MAGIC
-- MAGIC ##### AI/BI Dashboard Update Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/lakeflow_jobs_dashboard_update.png" width="1100">
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## E. Delete the Lakeflow Job
-- MAGIC
-- MAGIC Since this is a training environment, you do not want to leave the job running. 
-- MAGIC
-- MAGIC Navigate to your Lakeflow Job and delete it to clean up the resources created during this lab.
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## F. Proceed to the Next Bonus Notebook
-- MAGIC
-- MAGIC If time permits, or if you would like to explore AI/BI dashboards further, proceed to the next bonus notebook **4 BONUS Lab** to build Page 2, **Detailed Breakdown**.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## G. Summary and Key Takeaways
-- MAGIC - **Dashboard Publishing**: Use "Share data permission" to allow viewers access without direct data permissions, or "Individual data permission" for role-based access control
-- MAGIC - **Certification Management**: Apply certified status tags to indicate data quality and lifecycle status for governance and trust
-- MAGIC - **Business User Access**: Databricks One provides a simplified interface for non-technical users to discover and interact with dashboards
-- MAGIC - **Content Updates**: Dashboard changes require republishing to take effect in the published version
-- MAGIC - **Automated Refresh**: Schedule regular updates using built-in scheduling or integrate with Lakeflow Jobs for complex workflows
-- MAGIC - **Event-Driven Updates**: Table update triggers in Lakeflow Jobs enable real-time dashboard refreshes when source data changes
-- MAGIC - **Genie Integration**: Natural language querying capabilities are automatically enabled, allowing business users to explore data conversationally

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
-- MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
-- MAGIC <script>
-- MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
-- MAGIC </script>