# Building AI/BI Dashboards on Delicious Data

<!-- Replace the template below with information for your lab(s) -->
| Field           | Details       | Description                                                                 |
|-----------------|---------------|-----------------------------------------------------------------------------|
| Duration        | 90 minutes   | Estimated duration to complete the lab(s). |
| Level           | 200 | Target difficulty level for participants (100 = beginner, 200 = intermediate, 300 = advanced). |
| Lab Status      | Active | See descriptions in main repo README. |
| Course Location | N/A           | Indicates where the lab is hosted. <br> - **N/A** - Lab is only available in this repo. <br> - **Course name** - Lab has been moved into a full Databricks Academy course. |
| Developer       | Peter Styliadis | Primary developer(s) of the lab, separated by commas.  |
| Reviewer        | Maggie Li, Gourav Prajapati | Subject matter expert reviewer(s), separated by commas.|
| Product Version         | Metric Views v1.1         | Specify a product version if applicable If not, use **N/A**. | 
---

## Description  
This hands-on workshop guides participants through building end-to-end AI/BI dashboards in Databricks using metric views, Lakeflow jobs, and interactive visualizations. Participants will work with a Canadian poutine sales dataset to create a complete business intelligence solution that demonstrates modern data analytics workflows.

The workshop covers the full lifecycle of dashboard development, from creating semantic layers with metric views to publishing production-ready dashboards with automated refresh capabilities. Participants will learn to build interactive visualizations, implement filtering mechanisms, and use AI-powered analytics tools like Genie for natural language querying.


## Learning Objectives
- Create and configure metric views as semantic layers that centralize business metrics, joins, and aggregation logic using YAML configuration
- Build comprehensive AI/BI dashboards with multiple visualization types including counter widgets, combo charts, maps, and pivot tables using semantic metadata
- Implement dashboard management workflows including publishing, certification, automated refresh scheduling, and Lakeflow Jobs orchestration
- Configure interactive dashboard features such as global and page-level filters, natural language querying with Genie, and advanced analytics like Pareto analysis

## Requirements & Prerequisites  
<!-- Example list below – update or replace with the specific requirements for your lab -->
Before starting this lab, ensure you have:  
- **Databricks Workspace familiarity**: Basic navigation of Databricks workspace, notebooks, and catalog explorer
- **SQL knowledge**: Intermediate SQL skills including joins, aggregations, and window functions
- **Data modeling concepts**: Understanding of star schema, fact/dimension tables, and basic data warehouse principles
- **Business intelligence basics**: Familiarity with dashboard concepts, KPIs, and data visualization principles
- While the workshop provides guided instructions, participants need foundational knowledge of SQL, Databricks, and BI concepts to fully benefit from the advanced features covered.


## Contents  
<!-- Replace the example below with the actual files included in your lab -->
This repository includes: 
- **0 - Required Setup** notebook 
- **1 Lab - Create the Metric View for the AI-BI Dashboard** notebook 
- **2 Lab - Sales Overview Page** notebook  
- **3 Lab - Dashboard Management and Automation** notebook  
- **4 Lab - BONUS Detailed Breakdown Page** notebook
- Images and supporting materials


## Getting Started  
<!-- Replace the example below with the actual files included in your lab -->
1. Open the main lab notebook **0 - Required Setup**.  
2. Follow the instructions step by step. 
