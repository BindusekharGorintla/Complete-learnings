-- Databricks notebook source
-- MAGIC %md
-- MAGIC ![DB Academy](./Includes/images/db-academy.png)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Lab - Create the Metric View for the AI/BI Dashboard
-- MAGIC ## Overview
-- MAGIC
-- MAGIC This hands-on lab guides you through creating a comprehensive [metric view](https://docs.databricks.com/aws/en/metric-views/) for AI/BI dashboards using Databricks Unity Catalog. You'll work with a [Canadian poutine](https://en.wikipedia.org/wiki/Poutine) sales dataset to build a semantic layer that standardizes business metrics and enables consistent analytics across your organization.
-- MAGIC
-- MAGIC In this lab, you'll explore three interconnected tables forming a [star schema](https://www.databricks.com/blog/five-simple-steps-for-implementing-a-star-schema-in-databricks-with-delta-lake), create joins between [fact and dimension tables](https://www.databricks.com/blog/implementing-dimensional-data-warehouse-databricks-sql-part-1), and define business metrics with rich semantic metadata. The metric view you create will serve as the foundation for an AI/BI dashboard, demonstrating how to centralize business logic and ensure all downstream consumers work with trusted, consistent definitions.
-- MAGIC
-- MAGIC This lab emphasizes practical application of Unity Catalog's metric view capabilities, showing how semantic layers simplify data consumption for analysts, business users, and AI-powered tools while maintaining data governance and consistency.
-- MAGIC ## Learning Objectives
-- MAGIC
-- MAGIC By the end of this notebook, you will be able to:
-- MAGIC
-- MAGIC - Examine star schema relationships between fact and dimension tables to understand data modeling for analytics
-- MAGIC
-- MAGIC - Build semantic layers that centralize business metrics, joins, and aggregation logic using YAML configuration
-- MAGIC
-- MAGIC - Define metric view semantic metadata like display names, formats, synonyms, and comments to enhance usability
-- MAGIC
-- MAGIC - Use a metric view as the foundation for building AI/BI dashboards

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## REQUIRED - SELECT A COMPUTE ENVIRONMENT
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select a SQL Warehouse</strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC Before starting this notebook, select the required compute environment.
-- MAGIC - **SQL Warehouse** (X-Small is sufficient)
-- MAGIC
-- MAGIC To select a SQL Warehouse:
-- MAGIC
-- MAGIC 1. Select the compute tile in the top-right corner of the notebook.
-- MAGIC 2. If your SQL Warehouse is already listed, select it.
-- MAGIC 3. If it is not visible, select **More** > **SQL Warehouse**, then choose your SQL Warehouse from the list.
-- MAGIC
-- MAGIC **NOTE:**  This notebook was **developed and tested using a SQL Warehouse**. Other compute options may work but are not guaranteed to behave the same or support all features demonstrated.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## A. REQUIRED - Classroom Setup

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC #### PREREQUISITE - ENVIRONMENT SETUP
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     0 - Required Setup Notebook
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC   Before running this notebook, make sure you have already executed the previous notebook, <strong>0 - Required Setup</strong>, to properly setup your catalog, schema, and files for this notebook.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 1. Next, run the cell below to set your default catalog, schema and create the necessary tables in your **labuser.poutine_aibi** schema. 

-- COMMAND ----------

-- MAGIC %run ./Includes/Classroom-Setup-1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 2. In the notebook sidebar, select the **Catalog** icon and navigate to your **labuser_yourusername** catalog and **poutine_aibi** schema (refresh the catalog list if needed) and then confirm the following:
-- MAGIC
-- MAGIC    - A catalog named **labuser_yourusername** exists  
-- MAGIC       - In Vocareum, this may appear as **labuser12345...**
-- MAGIC
-- MAGIC    - The catalog contains a schema named **poutine_aibi**
-- MAGIC
-- MAGIC    - The **poutine_aibi** schema contains the following tables:
-- MAGIC       - **line_items_poutine_sales**
-- MAGIC       - **products_poutine**
-- MAGIC       - **stores_canada**
-- MAGIC

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## B. Explore the Tables
-- MAGIC
-- MAGIC Before we begin, let's take a moment to explore the workshop tables. Understanding the structure and relationships of the data will make it easier to follow the examples and build metrics later in the workshop.
-- MAGIC
-- MAGIC The diagram below shows how the fact table connects to two dimension tables and highlights the join relationships used throughout the workshop. This logical model will later be used when creating the metric view.
-- MAGIC
-- MAGIC <br></br>
-- MAGIC
-- MAGIC #### Logical Data Model (Star Schema)
-- MAGIC
-- MAGIC
-- MAGIC <div class="mermaid">
-- MAGIC erDiagram
-- MAGIC     line_items_poutine_sales {
-- MAGIC         string transaction_id
-- MAGIC         int line_id
-- MAGIC         int product_id
-- MAGIC         int store_id
-- MAGIC         timestamp transaction_ts
-- MAGIC     }
-- MAGIC     products_poutine {
-- MAGIC         int product_id
-- MAGIC         string product_name
-- MAGIC         string category
-- MAGIC         string subcategory
-- MAGIC         decimal unit_price
-- MAGIC         decimal unit_cost
-- MAGIC     }
-- MAGIC     stores_canada {
-- MAGIC         int store_id
-- MAGIC         string location
-- MAGIC         float latitude
-- MAGIC         float longitude
-- MAGIC     }
-- MAGIC     line_items_poutine_sales }o--|| products_poutine : "line_items_poutine_sales.product_id = products_poutine.product_id"
-- MAGIC     line_items_poutine_sales }o--|| stores_canada : "line_items_poutine_sales.store_id = stores_canada.store_id"
-- MAGIC </div>
-- MAGIC
-- MAGIC <script type="module">
-- MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs";
-- MAGIC mermaid.initialize({ startOnLoad: true, theme: "default" });
-- MAGIC </script>
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B1. Explore the Sales Table - `line_items_poutine_sales` (fact table)
-- MAGIC
-- MAGIC 1. Run the cell below to explore the data and notice the following:
-- MAGIC
-- MAGIC     - This table contains **poutine sales transaction line items** across stores in Canada. 
-- MAGIC     - Each row represents a single product sold within a transaction. Each **transaction_id** can appear multiple times, one row per product sold.
-- MAGIC     - **product_id** and **store_id** are used to join to the product and store tables (shown later)

-- COMMAND ----------

SELECT *
FROM line_items_poutine_sales
ORDER BY transaction_id
LIMIT 15;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B2. Explore the Products Table - `products_poutine` (dimension table)
-- MAGIC
-- MAGIC 1. Run the cell below to explore the data and notice the following:
-- MAGIC
-- MAGIC     - Each **product_id** uniquely identifies a menu item
-- MAGIC     - Products are grouped by **category** and **subcategory**
-- MAGIC     - This table joins to **line_items_poutine_sales** on **product_id**

-- COMMAND ----------

SELECT *
FROM products_poutine
LIMIT 10;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B3. Explore Store Locations Table - `stores_canada` (dimension table)
-- MAGIC
-- MAGIC 1. Run the cell below to explore the data and notice the following:
-- MAGIC
-- MAGIC     - This table provides **store and location information** for poutine sales across Canada.
-- MAGIC     - Each **store_id** represents a single physical store location
-- MAGIC     - Location fields can be used for geographic and regional analysis
-- MAGIC     - This table joins to **line_items_poutine_sales** on **store_id**
-- MAGIC

-- COMMAND ----------

SELECT *
FROM stores_canada
LIMIT 10;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B4. Join the Data
-- MAGIC 1. In this exploration, we will perform a `LEFT JOIN` across the sales, product, and store tables and view the combined output.
-- MAGIC
-- MAGIC     Notice that the result 
-- MAGIC     - Contains **1,621 rows**, matching the number of sales line items, and includes all relevant sales, product, and location information in a single dataset. 
-- MAGIC     - This joined view represents the logical model that will later be captured and reused in the metric view.

-- COMMAND ----------

SELECT
  s.transaction_id,
  s.line_id,
  s.transaction_ts,
  p.unit_price,
  p.unit_cost,
  p.product_id,
  p.category,
  p.subcategory,
  p.product_name,
  st.store_id,
  st.location,
  st.latitude,
  st.longitude
FROM line_items_poutine_sales s
LEFT JOIN products_poutine p
  ON s.product_id = p.product_id
LEFT JOIN stores_canada st
  ON s.store_id = st.store_id
ORDER BY transaction_id;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## C. Define the Metric View
-- MAGIC
-- MAGIC In this step, we will create a **metric view** on top of the poutine sales data model, which consists of the following tables:
-- MAGIC   - **line_items_poutine_sales**
-- MAGIC   - **products_poutine**
-- MAGIC   - **stores_canada**
-- MAGIC
-- MAGIC Metric views provide a **trusted semantic layer** that:
-- MAGIC - Centralizes business metrics, joins, and aggregation logic
-- MAGIC - Ensures consistent calculations and definitions across dashboards, notebooks, and **AI/BI** experiences for **all downstream users**
-- MAGIC - Simplifies querying by allowing analysts and BI tools to work with metrics without needing to understand the underlying table relationships
-- MAGIC
-- MAGIC **NOTE:** A deep dive into metric views is outside the scope of this workshop. We will walk you through how to create one as part of the exercise.

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC <div class="mermaid">
-- MAGIC ---
-- MAGIC title: "Figure: Metric View Architecture and Consumption Model"
-- MAGIC ---
-- MAGIC flowchart LR
-- MAGIC   subgraph SourceTables["Source Tables"]
-- MAGIC     direction TB
-- MAGIC     t1_label["line_items_poutine_sales"]
-- MAGIC     t1[("<img src='./Includes/images/icons/table.png'/>")]
-- MAGIC     t2_label["products_poutine"]
-- MAGIC     t2[("<img src='./Includes/images/icons/table.png'/>")]
-- MAGIC     t3_label["stores_canada"]
-- MAGIC     t3[("<img src='./Includes/images/icons/table.png'/>")]
-- MAGIC   end
-- MAGIC   mv("Metric View <br/>Semantic Layer <img src='./Includes/images/icons/metric_view.png'/>")
-- MAGIC   consumers_note["Users query<br/>a standardized semantic layer<br/>for consistent metrics and definitions"]
-- MAGIC   subgraph Consumers["Consumers"]
-- MAGIC     direction LR
-- MAGIC     c1["<img src='./Includes/images/icons/people.png'/>"]
-- MAGIC     c2["<img src='./Includes/images/icons/people.png'/>"]
-- MAGIC     c3["<img src='./Includes/images/icons/people.png'/>"]
-- MAGIC     c4["<img src='./Includes/images/icons/people.png'/>"]
-- MAGIC   end
-- MAGIC   t1_label --> t1
-- MAGIC   t2_label --> t2
-- MAGIC   t3_label --> t3
-- MAGIC   t1 --> mv
-- MAGIC   t2 --> mv
-- MAGIC   t3 --> mv
-- MAGIC   mv --> consumers_note
-- MAGIC   consumers_note --> c1
-- MAGIC   consumers_note --> c2
-- MAGIC   consumers_note --> c3
-- MAGIC   consumers_note --> c4
-- MAGIC   style SourceTables fill:#e3f2fd,stroke:#1B5162,stroke-width:2px
-- MAGIC   style Consumers fill:#EEF2F7,stroke:#64748B,stroke-width:1.25px
-- MAGIC   style mv fill:#FFFFFF,stroke:#FF6F3D,stroke-width:2px
-- MAGIC   style consumers_note fill:#FFFFFF,stroke:#FF6F3D,stroke-width:1px
-- MAGIC   classDef consumerNode fill:#FFFFFF,stroke:#FF6F3D,stroke-width:1.25px,rx:6,ry:6;
-- MAGIC   class c1,c2,c3,c4 consumerNode;
-- MAGIC </div>
-- MAGIC
-- MAGIC <script type="module">
-- MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs";
-- MAGIC mermaid.initialize({ startOnLoad: true, theme: "default" });
-- MAGIC </script>

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #1976d2;
-- MAGIC   background: #e3f2fd;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     Information
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC Metric views are the recommended approach for powering dashboards and promoting consistent business logic. They continue to evolve, and while they support many common analytics patterns, some complex or highly customized calculations may still require SQL. In those cases, SQL can be used alongside metric views to bridge any gaps.
-- MAGIC   </div>
-- MAGIC </div>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C1. Create the Metric View
-- MAGIC
-- MAGIC In this step, you will [create a metric view](https://docs.databricks.com/aws/en/metric-views/create/) named **poutine_sales_metrics**.
-- MAGIC
-- MAGIC 1. In the notebook sidebar, find your **labuser** catalog and right-click to select **Open in Catalog Explorer**.
-- MAGIC
-- MAGIC 2. Locate and select the table **YOUR_LABUSER_CATALOG > poutine_aibi > line_items_poutine_sales** table.
-- MAGIC
-- MAGIC 3. At the top right select **Create** -> **Metric View**.
-- MAGIC
-- MAGIC 4. When prompted:
-- MAGIC    - **Name:** `poutine_sales_metrics`
-- MAGIC    - **Catalog:** **YOUR_LABUSER_CATALOG**
-- MAGIC    - **Schema:** **poutine_aibi**
-- MAGIC    - Select **Create**
-- MAGIC
-- MAGIC 5. Confirm and update the YAML configuration as follows:
-- MAGIC    - Confirm the **version** is set to `1.1`. Change it if necessary.
-- MAGIC    - If populated, remove all existing entries under **dimensions** and **measures** so you can start from a clean slate.
-- MAGIC    - Your YAML should now look like this:
-- MAGIC
-- MAGIC       ```yaml
-- MAGIC       version: 1.1
-- MAGIC
-- MAGIC       source: YOUR_LABUSER_CATALOG.poutine_aibi.line_items_poutine_sales
-- MAGIC       ```
-- MAGIC
-- MAGIC 6.  Expand the **Metric View YAML** cell below and copy the provided metric view syntax and paste it directly under the `source` mapping.

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC #### Metric View YAML Solution
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #1976d2;
-- MAGIC   background: #e3f2fd;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC
-- MAGIC ##### Metric View YAML
-- MAGIC <details>
-- MAGIC   <summary>EXPAND FOR YAML</summary>
-- MAGIC
-- MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
-- MAGIC
-- MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
-- MAGIC <code>
-- MAGIC <!-------------------ADD SOLUTION CODE BELOW------------------->
-- MAGIC joins:
-- MAGIC   - name: stores_canada
-- MAGIC     source: YOUR_LABUSER_CATALOG.poutine_aibi.stores_canada
-- MAGIC     "on": source.store_id = stores_canada.store_id
-- MAGIC   - name: products_poutine
-- MAGIC     source: YOUR_LABUSER_CATALOG.poutine_aibi.products_poutine
-- MAGIC     "on": source.product_id = products_poutine.product_id
-- MAGIC
-- MAGIC dimensions:
-- MAGIC   - name: transaction_date
-- MAGIC     expr: date(source.transaction_ts)
-- MAGIC     comment: "The date when the transaction occurred, truncated to day"
-- MAGIC     display_name: Transaction Date
-- MAGIC     format:
-- MAGIC       type: date
-- MAGIC       date_format: year_month_day
-- MAGIC       leading_zeros: false
-- MAGIC     synonyms:
-- MAGIC       - date of transaction
-- MAGIC       - transaction day
-- MAGIC       - sales date
-- MAGIC   - name: store_location
-- MAGIC     expr: stores_canada.location
-- MAGIC     comment: Geographical location of the store where the sale occurred
-- MAGIC     display_name: Store Location
-- MAGIC   - name: product_subcategory
-- MAGIC     expr: products_poutine.subcategory
-- MAGIC     comment: Subcategory of the poutine product sold
-- MAGIC     display_name: Product Subcategory
-- MAGIC   - name: product_category
-- MAGIC     expr: products_poutine.category
-- MAGIC     comment: Category of the poutine product sold
-- MAGIC     display_name: Product Category
-- MAGIC   - name: transaction_hour
-- MAGIC     expr: extract(hour from source.transaction_ts)
-- MAGIC     comment: Hour of the day when the transaction occurred (0-23)
-- MAGIC   - name: store_latitude
-- MAGIC     expr: stores_canada.latitude
-- MAGIC     comment: Latitude coordinate of the store location
-- MAGIC     display_name: Store Latitude
-- MAGIC     format:
-- MAGIC       type: number
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 6
-- MAGIC       abbreviation: none
-- MAGIC     synonyms:
-- MAGIC       - latitude
-- MAGIC       - store geo latitude
-- MAGIC       - store lat
-- MAGIC   - name: store_longitude
-- MAGIC     expr: stores_canada.longitude
-- MAGIC     comment: Longitude coordinate of the store location
-- MAGIC     display_name: Store Longitude
-- MAGIC     format:
-- MAGIC       type: number
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 6
-- MAGIC       abbreviation: none
-- MAGIC     synonyms:
-- MAGIC       - longitude
-- MAGIC       - store geo longitude
-- MAGIC       - store long
-- MAGIC   - name: product_name
-- MAGIC     expr: products_poutine.product_name
-- MAGIC     comment: Name of the poutine product sold
-- MAGIC     display_name: Product Name
-- MAGIC     synonyms:
-- MAGIC       - poutine name
-- MAGIC       - product
-- MAGIC       - item name
-- MAGIC   - name: transaction_id
-- MAGIC     expr: source.transaction_id
-- MAGIC     display_name: Transaction Id
-- MAGIC
-- MAGIC measures:
-- MAGIC   - name: transaction_count
-- MAGIC     expr: count(distinct source.transaction_id)
-- MAGIC     comment: Number of unique transactions
-- MAGIC     display_name: Transaction Count
-- MAGIC     synonyms:
-- MAGIC       - transactions
-- MAGIC       - sales count
-- MAGIC   - name: units_sold
-- MAGIC     expr: count(line_id)
-- MAGIC     comment: Total number of units sold (line items)
-- MAGIC     display_name: Units Sold
-- MAGIC     synonyms:
-- MAGIC       - quantity sold
-- MAGIC       - items sold
-- MAGIC   - name: total_sales
-- MAGIC     expr: sum(products_poutine.unit_price)
-- MAGIC     comment: Total sales amount (sum of unit prices)
-- MAGIC     display_name: Total Sales
-- MAGIC     format:
-- MAGIC       type: currency
-- MAGIC       currency_code: CAD
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC       abbreviation: compact
-- MAGIC     synonyms:
-- MAGIC       - sales
-- MAGIC       - revenue
-- MAGIC   - name: cost_of_goods_sold
-- MAGIC     expr: sum(products_poutine.unit_cost)
-- MAGIC     comment: Total cost of goods sold (sum of unit costs)
-- MAGIC     display_name: Cost of Goods Sold
-- MAGIC     format:
-- MAGIC       type: currency
-- MAGIC       currency_code: CAD
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC       abbreviation: compact
-- MAGIC     synonyms:
-- MAGIC       - COGS
-- MAGIC       - cost
-- MAGIC   - name: gross_profit
-- MAGIC     expr: MEASURE(total_sales) - MEASURE(cost_of_goods_sold)
-- MAGIC     comment: Gross profit (total sales minus cost of goods sold)
-- MAGIC     display_name: Gross Profit
-- MAGIC     format:
-- MAGIC       type: currency
-- MAGIC       currency_code: CAD
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC       abbreviation: compact
-- MAGIC     synonyms:
-- MAGIC       - profit
-- MAGIC       - gross margin
-- MAGIC   - name: t7_transaction_count
-- MAGIC     expr: MEASURE(transaction_count)
-- MAGIC     window:
-- MAGIC       - order: transaction_date
-- MAGIC         semiadditive: last
-- MAGIC         range: trailing 7 day
-- MAGIC     comment: Number of unique transactions in the trailing 7 days
-- MAGIC     display_name: Trailing 7 Day Transaction Count
-- MAGIC   - name: t7_units_sold
-- MAGIC     expr: MEASURE(units_sold)
-- MAGIC     window:
-- MAGIC       - order: transaction_date
-- MAGIC         semiadditive: last
-- MAGIC         range: trailing 7 day
-- MAGIC     comment: Total number of units sold in the trailing 7 days
-- MAGIC     display_name: Trailing 7 Day Units Sold
-- MAGIC   - name: t7_total_sales
-- MAGIC     expr: MEASURE(total_sales)
-- MAGIC     window:
-- MAGIC       - order: transaction_date
-- MAGIC         semiadditive: last
-- MAGIC         range: trailing 7 day
-- MAGIC     comment: Total sales amount in the trailing 7 days
-- MAGIC     display_name: Trailing 7 Day Total Sales
-- MAGIC     format:
-- MAGIC       type: currency
-- MAGIC       currency_code: CAD
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC       abbreviation: compact
-- MAGIC   - name: t7_cost_of_goods_sold
-- MAGIC     expr: MEASURE(cost_of_goods_sold)
-- MAGIC     window:
-- MAGIC       - order: transaction_date
-- MAGIC         semiadditive: last
-- MAGIC         range: trailing 7 day
-- MAGIC     comment: Total cost of goods sold in the trailing 7 days
-- MAGIC     display_name: Trailing 7 Day Cost of Goods Sold
-- MAGIC   - name: t7_gross_profit
-- MAGIC     expr: MEASURE(gross_profit)
-- MAGIC     window:
-- MAGIC       - order: transaction_date
-- MAGIC         semiadditive: last
-- MAGIC         range: trailing 7 day
-- MAGIC     comment: Gross profit in the trailing 7 days
-- MAGIC     display_name: Trailing 7 Day Gross Profit
-- MAGIC   - name: average_basket_size
-- MAGIC     expr: "MEASURE(units_sold) * 1.0 / NULLIF(MEASURE(transaction_count), 0)"
-- MAGIC     comment: Average number of items per transaction
-- MAGIC     display_name: Average Basket Size
-- MAGIC     format:
-- MAGIC       type: number
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC     synonyms:
-- MAGIC       - avg basket size
-- MAGIC       - average items per transaction
-- MAGIC   - name: average_unit_price
-- MAGIC     expr: AVG(products_poutine.unit_price)
-- MAGIC     comment: Average unit price across all line items
-- MAGIC     display_name: Average Unit Price
-- MAGIC     format:
-- MAGIC       type: currency
-- MAGIC       currency_code: CAD
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC     synonyms:
-- MAGIC       - avg unit price
-- MAGIC       - mean unit price
-- MAGIC   - name: average_transaction_amount
-- MAGIC     expr: "MEASURE(total_sales) * 1.0 / NULLIF(MEASURE(transaction_count), 0)"
-- MAGIC     comment: Average total sales per transaction
-- MAGIC     display_name: Average Transaction Amount
-- MAGIC     format:
-- MAGIC       type: currency
-- MAGIC       currency_code: CAD
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC     synonyms:
-- MAGIC       - avg transaction amount
-- MAGIC       - mean transaction value
-- MAGIC   - name: average_unit_cost
-- MAGIC     expr: AVG(products_poutine.unit_cost)
-- MAGIC     comment: Average unit cost across all line items
-- MAGIC     display_name: Average Unit Cost
-- MAGIC     format:
-- MAGIC       type: currency
-- MAGIC       currency_code: CAD
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC     synonyms:
-- MAGIC       - avg unit cost
-- MAGIC       - mean unit cost
-- MAGIC   - name: gross_margin
-- MAGIC     expr: (MEASURE(gross_profit)) / MEASURE(total_sales)
-- MAGIC     comment: Gross profit as a percentage of total sales
-- MAGIC     display_name: Gross Margin
-- MAGIC     format:
-- MAGIC       type: percentage
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC     synonyms:
-- MAGIC       - gross margin percent
-- MAGIC       - gross profit margin
-- MAGIC   - name: basket_items
-- MAGIC     expr: "COUNT(DISTINCT source.product_id) * 1.0 / NULLIF(COUNT(DISTINCT source.transaction_id),\
-- MAGIC       \ 0)"
-- MAGIC     comment: Average number of unique products per transaction
-- MAGIC     display_name: Basket Items
-- MAGIC     format:
-- MAGIC       type: number
-- MAGIC       decimal_places:
-- MAGIC         type: exact
-- MAGIC         places: 2
-- MAGIC     synonyms:
-- MAGIC       - avg basket items
-- MAGIC       - average unique products per transaction
-- MAGIC <!-------------------END SOLUTION CODE------------------->
-- MAGIC </code></pre>
-- MAGIC </div>
-- MAGIC
-- MAGIC
-- MAGIC <script>
-- MAGIC function copyBlock() {
-- MAGIC   const el = document.getElementById("copy-block");
-- MAGIC   if (!el) return;
-- MAGIC
-- MAGIC   const text = el.innerText;
-- MAGIC
-- MAGIC   // Preferred modern API
-- MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
-- MAGIC     navigator.clipboard.writeText(text)
-- MAGIC       .then(() => alert("Copied to clipboard"))
-- MAGIC       .catch(err => {
-- MAGIC         console.error("Clipboard write failed:", err);
-- MAGIC         fallbackCopy(text);
-- MAGIC       });
-- MAGIC   } else {
-- MAGIC     fallbackCopy(text);
-- MAGIC   }
-- MAGIC }
-- MAGIC
-- MAGIC function fallbackCopy(text) {
-- MAGIC   const textarea = document.createElement("textarea");
-- MAGIC   textarea.value = text;
-- MAGIC   textarea.style.position = "fixed";
-- MAGIC   textarea.style.left = "-9999px";
-- MAGIC   document.body.appendChild(textarea);
-- MAGIC   textarea.select();
-- MAGIC   try {
-- MAGIC     document.execCommand("copy");
-- MAGIC     alert("Copied to clipboard");
-- MAGIC   } catch (err) {
-- MAGIC     console.error("Fallback copy failed:", err);
-- MAGIC     alert("Could not copy to clipboard. Please copy manually.");
-- MAGIC   } finally {
-- MAGIC     document.body.removeChild(textarea);
-- MAGIC   }
-- MAGIC }
-- MAGIC </script>
-- MAGIC </details>
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     Update Catalog Name in Metric View YAML
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC 7. In the metric view YAML syntax, scroll to the top and replace the catalog placeholder <strong>YOUR_LABUSER_CATALOG</strong> in both locations within the `joins` mapping. 
-- MAGIC   
-- MAGIC - This will be near the top below `source`.
-- MAGIC   </div>
-- MAGIC </div>
-- MAGIC
-- MAGIC
-- MAGIC 8. Select **Save** and confirm the metric view was saved successfully. 
-- MAGIC
-- MAGIC 9. At the top of the editor, confirm you are in **YAML** mode for the metric view.  
-- MAGIC    - You can switch to **UI Preview** to view the metric view UI, but this is outside the scope of this introductory training.
-- MAGIC
-- MAGIC 10. Select **Close**.
-- MAGIC

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #ff9800;
-- MAGIC   background: #fff3e0;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#e65100; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     Troubleshooting Metric View
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC If you select **Save** and see the following error: 
-- MAGIC
-- MAGIC `[TABLE_OR_VIEW_NOT_FOUND] The table or view YOUR_LABUSER_CATALOG.poutine_aibi.stores_canada cannot be found. Verify the spelling and correctness of the schema and catalog.`
-- MAGIC
-- MAGIC This indicates that the catalog name in your `join` mapping was not updated. Review the join definition and ensure all table references use your correct catalog name.
-- MAGIC   </div>
-- MAGIC </div>
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C2. Explore the Metric View in Catalog Explorer (Checkpoint - Partial Image)
-- MAGIC
-- MAGIC 1. View the metric view in **Catalog Explorer** and review the details for **poutine_sales_metrics**. 
-- MAGIC
-- MAGIC     Your configuration should look similar to the example below.
-- MAGIC
-- MAGIC <br></br>
-- MAGIC ![Metric View UI Checkpoint](./Includes/images/metric_view_checkpoint.png)
-- MAGIC
-- MAGIC <br></br>
-- MAGIC 2. In **Catalog Explorer**, notice the following:
-- MAGIC - The `source` and `joins` mappings are displayed on the right-hand side
-- MAGIC - `measures` and `dimensions` are shown as separate sections in the UI
-- MAGIC - **Display names** and underlying **column names** for your `measures` and `dimensions` appear in the **Name** column
-- MAGIC - Any `comments` defined in the metric view are visible at the column level
-- MAGIC
-- MAGIC <br></br>
-- MAGIC 3. Locate the **Gross Profit** `measure` and select the info icon on the far right. Notice the following:
-- MAGIC - The semantic metadata defined for the measure
-- MAGIC - The configured `format`, `synonyms`, and `comment`
-- MAGIC - These mappings are standardized for all users and are reused by visualizations and AI/BI and LLM-powered tools
-- MAGIC
-- MAGIC <img
-- MAGIC   src="./Includes/images/gross_profit_info.png"
-- MAGIC   alt="Gross Profit"
-- MAGIC   width=250
-- MAGIC />
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### C3. Query the Metric View
-- MAGIC
-- MAGIC Now that the metric view is defined and standardized, **users** can query it directly.
-- MAGIC
-- MAGIC Querying a metric view allows users across the organization to work with **consistent, trusted metrics** without needing to understand the underlying table structure or join logic. 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 1. In the notebook sidebar select the **Catalog** icon and expand your metric view **YOUR_LABUSER_CATALOG > poutine_aibi > poutine_sales_metrics** (Refresh if necessary). 
-- MAGIC
-- MAGIC 2. Notice that `measures` and `dimensions` are clearly grouped, making it easy to discover and understand the available metrics and attributes.
-- MAGIC
-- MAGIC <img
-- MAGIC   src="./Includes/images/poutine_sales_metrics.png"
-- MAGIC   alt="metrics sidebar"
-- MAGIC   width=250
-- MAGIC />

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 3. A metric view lets you query trusted business metrics without manually joining tables or rewriting aggregation logic.
-- MAGIC
-- MAGIC     In the query below, notice the following:
-- MAGIC     - We select the `transaction_date` dimension and two measures using the 
-- MAGIC     [MEASURE](https://docs.databricks.com/aws/en/sql/language-manual/functions/measure) function.
-- MAGIC     - `MEASURE(transaction_count)` calculates the number of distinct transactions for each day.
-- MAGIC     - `MEASURE(t7_transaction_count)` returns the trailing 7 day transaction count, based on the window definition in the metric view.
-- MAGIC     - `GROUP BY transaction_date` tells Databricks to aggregate the measures at the daily level (the `dimension`).
-- MAGIC
-- MAGIC     Why this is useful:
-- MAGIC     - The metric view centralizes the `source`, `joins`, measure definitions, and semantic metadata in one place.
-- MAGIC     - Users do not need to understand the underlying tables, join keys, or window logic to get consistent results.
-- MAGIC     - This prevents teams from creating multiple one-off views or duplicate calculations that drift over time.

-- COMMAND ----------

SELECT 
  transaction_date, 
  MEASURE(transaction_count) AS daily_transaction_count,
  MEASURE(t7_transaction_count) AS trailing_7_day_transaction_count
FROM poutine_sales_metrics
GROUP BY transaction_date
ORDER BY transaction_date;

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #1976d2;
-- MAGIC   background: #e3f2fd;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     Note
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC This enables all consumers to answer ad-hoc business questions on demand, using the same trusted metrics across SQL, dashboards, and natural language tools. This avoids data consumers having to write this logic themselves.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## D. Create the AI/BI Dashboard Using the Metric View as the Source
-- MAGIC
-- MAGIC Now that the metric view is in place, we will use it to build an AI/BI dashboard.
-- MAGIC
-- MAGIC - The metric view acts as the semantic foundation for AI/BI, providing trusted metrics, standardized definitions, and rich semantic metadata. 
-- MAGIC - By building the dashboard on top of the metric view, we ensure that visualizations and AI-assisted insights are consistent, governed, and reusable across the organization.
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D1. Create the AI/BI Dashboard
-- MAGIC
-- MAGIC 1. In the main navigation bar, right-click **Dashboards** and select **Open Link in New Tab**.  
-- MAGIC
-- MAGIC 2. At the top, select **Create dashboard**.  
-- MAGIC
-- MAGIC 3. Rename the dashboard to **firstname_lastinitials - Canadian Poutine Sales**.  
-- MAGIC
-- MAGIC 4. Select the tab **Untitled page** and rename it to **Sales Overview**.  
-- MAGIC
-- MAGIC 5. Select the **+** icon to create a new page and name it **Detailed Breakdown**.
-- MAGIC
-- MAGIC 6. Leave the dashboard window open.
-- MAGIC
-- MAGIC ![Checkpoint Dashboard Setup](./Includes/images/checkpoint_dashboard_setup.png)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D2. Add the Metric View to the Dashboard
-- MAGIC
-- MAGIC 1. Select the **Data** tab to add data sources for your dashboard.
-- MAGIC
-- MAGIC 2. Add the **metric view** you created from above. Complete the following:
-- MAGIC     - Select **Data** > **Add data source**
-- MAGIC     - Select your **poutine_sales_metrics** metric view
-- MAGIC     - Select **Confirm**. 
-- MAGIC
-- MAGIC 3. View the data in the UI. Notice that:
-- MAGIC     - It displays the column names and the comments.
-- MAGIC     - The display names are not shown here (as of 1/23/2025), but we will see it in the dashboard when we use the measures and dimensions.
-- MAGIC
-- MAGIC ![Checkpoint Dashboard Setup](./Includes/images/checkpoint_metric_view_data.png)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D3. Add a Custom Calculation
-- MAGIC
-- MAGIC Assume the metric view **does not include the Canadian province** and you do not have permission to modify the metric view, but you still need this value for your dashboard.
-- MAGIC
-- MAGIC We can **create a custom calculated column** directly in the dashboard.
-- MAGIC
-- MAGIC 1. Select **+ Add custom calculation**.
-- MAGIC
-- MAGIC 2. Configure the calculation:
-- MAGIC    - **Name**: `store_provinces`
-- MAGIC    - **Comment**: `Abbreviated Canadian province`
-- MAGIC    - **Expression**: `trim(split_part(store_location, ',', 2))`
-- MAGIC
-- MAGIC 3. Now, click the **Create** button at the bottom.
-- MAGIC
-- MAGIC 4. Confirm the **store_provinces** custom calculation was created at the bottom of the table within the `Fields` section.
-- MAGIC
-- MAGIC **NOTES:**
-- MAGIC - [What are custom calculations?](https://docs.databricks.com/aws/en/dashboards/custom-calculations)
-- MAGIC - [Custom calculation function reference](https://docs.databricks.com/aws/en/dashboards/custom-calculations/function-reference)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## E. Proceed to the Next Notebook
-- MAGIC
-- MAGIC After creating the metric view and creating the AI/BI dashboard with the metric view as the source, proceed to the next notebook **2 Lab - Sales Overview Page** to create Page 1 of the dashboard.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## F. Summary and Key Takeaways
-- MAGIC
-- MAGIC In this notebook, you were introduced to the basic building blocks of an AI/BI dashboard.
-- MAGIC
-- MAGIC You explored a simple star schema to understand how sales data relates to products and stores, then used a metric view as a lightweight semantic layer to expose consistent business metrics. The goal was not to dive deeply into metric view design, but to show how they can simplify analytics and power dashboards.
-- MAGIC
-- MAGIC By the end of this notebook, you:
-- MAGIC - Reviewed the core tables used for analytics
-- MAGIC - Created a metric view to centralize a small set of business metrics
-- MAGIC - Used that metric view as the data source for an AI/BI dashboard
-- MAGIC
-- MAGIC The key takeaway is that metric views provide a clean, reusable foundation for dashboards and AI/BI experiences, allowing teams to focus on analysis and visualization instead of joins and calculations.

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
-- MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
-- MAGIC <script>
-- MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
-- MAGIC </script>