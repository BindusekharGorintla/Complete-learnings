-- Databricks notebook source
-- MAGIC %md
-- MAGIC ![DB Academy](./Includes/images/db-academy.png)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Lab - Detailed Breakdown Page
-- MAGIC
-- MAGIC ## Overview
-- MAGIC
-- MAGIC In this notebook, you will enhance your Databricks AI-BI dashboard by building a comprehensive detailed breakdown page. This hands-on exercise focuses on creating advanced dashboard features including global and page-level filters, counter widgets, and sophisticated visualizations like Pareto charts. You will learn to implement interactive filtering mechanisms that provide users with dynamic control over data views across different dashboard pages.
-- MAGIC
-- MAGIC The notebook emphasizes practical dashboard design patterns commonly used in business intelligence applications, including the creation of performance metrics displays and analytical visualizations that help identify key business drivers. Through building a Pareto analysis, you will gain experience in creating data-driven insights that support strategic decision-making processes.
-- MAGIC
-- MAGIC ## Learning Objectives
-- MAGIC By the end of this lab, you will be able to:
-- MAGIC - Configure global and page-level filters to create interactive dashboard experiences
-- MAGIC - Build and customize counter widgets to display key performance metrics
-- MAGIC - Create advanced visualizations including line charts and grouped bar charts using the AI assistant
-- MAGIC - Implement Pareto analysis to identify high-impact business drivers
-- MAGIC
-- MAGIC #### Final Deliverable
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_02_detailed_breakdown_page.png" width="1000">

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC ## REQUIRED - SELECT A COMPUTE ENVIRONMENT
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select a SQL Warehouse</strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC Before starting this notebook, select the required compute environment listed below.
-- MAGIC
-- MAGIC - **SQL Warehouse** (X-Small is sufficient)
-- MAGIC
-- MAGIC **NOTE:**  This notebook was **developed and tested using a SQL Warehouse**. Other compute options may work but are not guaranteed to behave the same or support all features demonstrated.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## A. REQUIRED - Classroom Setup

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC #### PREREQUISITE - ENVIRONMENT SETUP
-- MAGIC
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #f44336;
-- MAGIC   background: #ffebee;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     Complete All Prior Notebooks (0 - Required Setup, 1 Lab, 2 Lab, 3 Lab)
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC Before running this notebook, make sure you have completed all of the previous notebooks.
-- MAGIC   </div>
-- MAGIC </div>

-- COMMAND ----------

-- MAGIC %run ./Includes/Classroom-Setup-4

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## B. Add Global Filters to the Dashboard
-- MAGIC
-- MAGIC Global interactive filters apply across all pages in a dashboard for visualizations that share one or more datasets. Viewers can adjust these values dynamically, and changes affect the entire dashboard.
-- MAGIC
-- MAGIC For more information, see [Filter interactivity and scope](https://docs.databricks.com/aws/en/dashboards/filters#filter-interactivity-and-scope).
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B1. Add 2 Global Filters
-- MAGIC
-- MAGIC Complete the following steps to add global filters to your dashboard.
-- MAGIC
-- MAGIC 1. Select **Edit Draft**.
-- MAGIC
-- MAGIC 2. Select the **Filter** ![Filter Icon](./Includes/images/filter_icon.png) tab near the **Data** tab.
-- MAGIC
-- MAGIC 3. Select **Add a global filter +**.
-- MAGIC
-- MAGIC 4. Create the following two global filters.
-- MAGIC
-- MAGIC ##### Filter 1 - Store Provinces
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Select **Title** |
-- MAGIC | **Filter** | **Single value** |
-- MAGIC | **Fields** | **store_provinces** |
-- MAGIC | **Settings** | **Allow All** |
-- MAGIC
-- MAGIC - Add the title `Store Provinces Filter`
-- MAGIC
-- MAGIC
-- MAGIC ##### Filter 2 - Date Range
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Select **Title** |
-- MAGIC | **Filter** | **Date range picker** |
-- MAGIC | **Fields** | **transaction_date** |
-- MAGIC
-- MAGIC - Add the title `Date Range Filter`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_global_filters.png" alt='Checkpoint' width="1000">  

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### B2. Test the Global Filters
-- MAGIC
-- MAGIC 1. Select the **Sales Overview** page and review the filters. When finished, clear all filter values and return them to their default settings.
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## C. Add a Text Box Page Description
-- MAGIC
-- MAGIC 1. Select the **Detailed Breakdown** tab.
-- MAGIC
-- MAGIC 2. Select **Add a text box** and drag it to the top of the canvas.
-- MAGIC
-- MAGIC 3. Resize the text box to a height of **2H** blocks and across the canvas.
-- MAGIC
-- MAGIC 4. Enter the following markdown into the text box:
-- MAGIC
-- MAGIC ```text
-- MAGIC # Sales Detailed Breakdown
-- MAGIC This page provides a detailed view of poutine sales performance across Canada.
-- MAGIC ```

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_pg2_text.png" alt='Checkpoint' width="1000">  

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## D. Add Page Filters to the `Detailed Breakdown` Page
-- MAGIC
-- MAGIC Page filters apply to all visualizations on the same page that share one or more datasets. Viewers can adjust these values to change the view for that specific page only.
-- MAGIC
-- MAGIC For more information, see [Filter interactivity and scope](https://docs.databricks.com/aws/en/dashboards/filters#filter-interactivity-and-scope).

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D1. Add a Page Filter
-- MAGIC
-- MAGIC Complete the following steps to add four page filters to the **Detailed Breakdown** page.
-- MAGIC
-- MAGIC 1. Select the **Detailed Breakdown** page.
-- MAGIC
-- MAGIC 2. In the bottom toolbar, select the **Filter** icon.
-- MAGIC
-- MAGIC 3. Add a **1H x 4W** filter block to the far left, below the text box.
-- MAGIC
-- MAGIC 4. In the widget configuration panel, set the following options.
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Select **Title** |
-- MAGIC | **Filter** | **Multiple values** |
-- MAGIC | **Fields** | **store_location** |
-- MAGIC | **Default Value** | **All** |
-- MAGIC
-- MAGIC 5. Set the widget title to `Stores`.
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### D2. Add 3 More Page Filters
-- MAGIC
-- MAGIC Add the following three page filters below the **Stores** filter.
-- MAGIC
-- MAGIC 1. **product_category**
-- MAGIC    - Filter by **Multiple values**
-- MAGIC    - Set the widget title to `Category`
-- MAGIC
-- MAGIC 2. **product_subcategory**
-- MAGIC    - Filter by **Multiple values**
-- MAGIC    - Set the widget title to `Subcategory`
-- MAGIC
-- MAGIC 3. **product_name**
-- MAGIC    - Filter by **Multiple values**
-- MAGIC    - Set the widget title to `Product Name`
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_pg2_filters.png" alt='Checkpoint' width="1000"> 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## E. Add 4 Counter Widgets
-- MAGIC
-- MAGIC Using what you have learned so far, add four **2H x 2W** counter widgets on the right side of the page, below the header.
-- MAGIC
-- MAGIC 1. Create one counter widget for each of the following metrics and use the specified titles.
-- MAGIC
-- MAGIC - **total_sales** titled `Total Sales`
-- MAGIC - **gross_profit** titled `Gross Profit`
-- MAGIC - **gross_margin** titled `Gross Margin`
-- MAGIC - **units_sold** titled `Units Sold`
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_pg2_counter_widgets.png" alt='Checkpoint' width="1000"> 
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## F. Add a Trailing 7 Day Total Sales Over Time
-- MAGIC
-- MAGIC In this section, you will use the assistant to create an [**Area** widget](https://docs.databricks.com/aws/en/dashboards/visualizations/types#line-visualization) that displays **Trailing 7 Day Total Sales by Week**.
-- MAGIC
-- MAGIC 1. In the toolbar, select the **Visualization** icon.
-- MAGIC
-- MAGIC 2. Drag a new widget onto the dashboard.
-- MAGIC
-- MAGIC 3. Resize the widget to **9H** blocks and the remaining width to the right of hte filters and below the counters.
-- MAGIC
-- MAGIC 4. Move the widget in the space below the counter widgets.
-- MAGIC
-- MAGIC 5. Ask the assistant to create the following visualization: `Trailing 7 Day Total Sales by Week Line Chart`
-- MAGIC
-- MAGIC 6. Check if the visualization looks similar to the checkpoint example below. If needed, adjust the widget settings manually. 
-- MAGIC Notice that:
-- MAGIC    - The `display_names` use the names defined in the metric view
-- MAGIC    - **Trailing 7 Day Total Sales** and **Transaction Date** are automatically formatted using the `format` and `display_name` defined in the metric view
-- MAGIC
-- MAGIC 7. In the widget options:
-- MAGIC     - Add **Labels**.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_pg2_line.png" alt='Checkpoint' width="1000"> 
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## G. Add a Bar Chart of Total Sales and Gross Profit by Store Location
-- MAGIC
-- MAGIC In this section, you will use the assistant to create an [**Bar** widget](https://docs.databricks.com/aws/en/dashboards/visualizations/types#bar-chart) that displays **Total Sales and Gross Profit by Store Location**.
-- MAGIC
-- MAGIC 1. In the toolbar, select the **Visualization** icon.
-- MAGIC
-- MAGIC 2. Drag a new widget onto the dashboard.
-- MAGIC
-- MAGIC 3. Resize the widget in the space left of the line chart.
-- MAGIC
-- MAGIC 5. Ask the assistant to create the following visualization: `Total Sales and Gross Profit by Store Location Bar Chart`.
-- MAGIC
-- MAGIC 6. The assistant will most likely create a **stacked vertical bar chart**. Check if the visualization looks similar to the checkpoint example below. If needed, adjust the widget settings manually.
-- MAGIC
-- MAGIC 7. In the widget options:
-- MAGIC    - Ensure the bar chart is horizontal, use the arrows between the **X axis** and **Y axis** if needed.
-- MAGIC    - Select the **X axis** options button (three dots) and complete the following:
-- MAGIC      - Update the axis title to `Total ($)`
-- MAGIC      - In the **Layout** section, select **Group**.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_group_bar_vertical.png" alt='Checkpoint' width="1000"> 
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## H. Simplified Pareto Chart
-- MAGIC
-- MAGIC ### Business Questions:
-- MAGIC - Which **poutine** products drive the majority of total sales?
-- MAGIC - Which low-contributing items may be candidates for promotion changes or discontinuation?
-- MAGIC
-- MAGIC A Pareto chart helps you understand **which items have the biggest impact on overall results**. It is based on the idea that **a small number of products** often generate **most of the total sales**.
-- MAGIC
-- MAGIC **NOTE:** This dataset is synthetic and used for training purposes only. The results illustrate the Pareto concept but do not represent real sales patterns.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### H1. Run the Pareto Preparation Query
-- MAGIC
-- MAGIC 1. Run the query below to calculate total sales by product and determine each item's cumulative contribution to overall revenue.
-- MAGIC
-- MAGIC     This query:
-- MAGIC     - Aggregates total sales at the **product_name** level for all `poutine` products. 
-- MAGIC     - **Sorts** products from **highest to lowest total sales**  
-- MAGIC     - Calculates a **running cumulative percentage of total sales**  
-- MAGIC     - Classifies each product as **inside or outside** the top 80 percent (Pareto threshold)
-- MAGIC
-- MAGIC     After running the query, confirm the following:
-- MAGIC     - Products are ordered by **descending total sales**
-- MAGIC     - The **cumulative_pct** column increases from 0 to 1
-- MAGIC     - Only a subset of products fall into **Inside Pareto (Top 80%)** - Highest selling items
-- MAGIC     - Lower selling items appear in **Outside Pareto (Remaining 20%)** - Lowest selling items
-- MAGIC
-- MAGIC     These results will be used to build the Pareto visualization in the dashboard.
-- MAGIC

-- COMMAND ----------

WITH agg AS (
  SELECT
    product_name,
    MEASURE(total_sales) AS total_sales
  FROM poutine_sales_metrics
  WHERE product_category = 'Poutine'
  GROUP BY product_name
),
ranked AS (
  SELECT
    product_name,
    total_sales,
    SUM(total_sales) OVER () AS grand_total,
    SUM(total_sales) OVER (
      ORDER BY total_sales DESC
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS running_total
  FROM agg
)
SELECT
  product_name,
  ROUND(total_sales, 2) AS total_sales,
  ROUND(running_total / grand_total, 3) AS cumulative_pct,
  CASE
    WHEN running_total / grand_total <= 0.8 THEN 'Inside Pareto (Top 80%)'
    ELSE 'Outside Pareto (Remaining 20%)'
  END AS pareto_bucket
FROM ranked
ORDER BY total_sales DESC;


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### H2. Create the Pareto Visualization
-- MAGIC

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC <div style="
-- MAGIC   border-left: 4px solid #ff9800;
-- MAGIC   background: #fff3e0;
-- MAGIC   padding: 14px 18px;
-- MAGIC   border-radius: 4px;
-- MAGIC   margin: 16px 0;
-- MAGIC ">
-- MAGIC   <strong style="display:block; color:#e65100; margin-bottom:6px; font-size: 1.1em;">
-- MAGIC     Combo Plot Limitation
-- MAGIC   </strong>
-- MAGIC   <div style="color:#333;">
-- MAGIC
-- MAGIC - Due to current limitations in a **Combo plot**, combining total sales (as a bar) and cumulative percentage (as a line) and sorting by descending sales will not work. Which is a typical pareto chart.
-- MAGIC
-- MAGIC - To work around this, the chart we will create will **display cumulative sales percentage as a bar in ascending order (which will be descending total sales)** and uses an **80% reference line to highlight where most revenue is captured**.
-- MAGIC   </div>
-- MAGIC </div>
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 1. Complete the following steps to add the Pareto query to the dashboard:
-- MAGIC
-- MAGIC    a. In your dashboard, select the **Data** tab.
-- MAGIC
-- MAGIC    b. Select **Create from SQL**.
-- MAGIC
-- MAGIC    c. Set your **default catalog and schema**. 
-- MAGIC       - Catalog: **labuser_xxx**
-- MAGIC       - Schema: **poutine_aibi**.
-- MAGIC
-- MAGIC    d. Paste the Pareto query from the previous section into the editor.
-- MAGIC
-- MAGIC    e. Select **Run** to create the query.
-- MAGIC
-- MAGIC    f. Confirm the query executes successfully.
-- MAGIC
-- MAGIC    g. Name the query `poutine_sales_performance_analysis`.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC 2. Create the simplified Pareto visualization by completing the following:
-- MAGIC
-- MAGIC    a. Select the **Detailed Breakdown** page.
-- MAGIC
-- MAGIC    b. In the toolbar, select the **Visualization** icon.
-- MAGIC
-- MAGIC    c. Drag a new widget onto the dashboard.
-- MAGIC
-- MAGIC    d. Resize the widget to **9H** blocks and the width of the canvas.
-- MAGIC
-- MAGIC    e. Position the widget below the horizontal bar chart and the line plot.
-- MAGIC
-- MAGIC 3. In the **Widget** configuration panel, set the following options.
-- MAGIC
-- MAGIC | Field | Value |
-- MAGIC |------|------|
-- MAGIC | **Widget** | Confirm **Title** and **Description** are enabled |
-- MAGIC | **Dataset** | **poutine_sales_performance_analysis** |
-- MAGIC | **Visualization** | **Bar** |
-- MAGIC | **X axis** | **product_name** |
-- MAGIC | **Y axis** | **SUM(cumulative_pct)** |
-- MAGIC | **Y axis options** | Select **More options** <br> - Set the display name to `Cumulative Sales Pct` <br> - Select **Format > Custom > %** |
-- MAGIC | **X axis options** | Select **More options** <br> - Sort **Ascending** <br> - Set the display name to `Product Name` |
-- MAGIC | **Color** | **pareto_bucket** <br> Set **Outside Pareto (Remaining 20%)** to the hex color `#FCA5A5` |
-- MAGIC | **Color More Options** | <br> - Set the display name to `Sales Contribution Group` <br> - **Legend position** to `Top` |
-- MAGIC | **Tooltip** | **SUM(total_sales)** |
-- MAGIC | **Labels** | - Turn **On** <br> - **Field** > **total_sales**  (Format this as `$`) <br> |
-- MAGIC | **Annotation** | Add **Horizontal** annotation at **0.80** <br> Set the label to `80% of Total Sales` |
-- MAGIC
-- MAGIC 4. Set the widget title to: `Which Poutine Products Drive Most Sales`
-- MAGIC
-- MAGIC 5. Set the widget description to: `This chart shows the cumulative share of total poutine sales as products are ordered by their contribution. As you move across the chart, sales build toward 100%, with the 80% reference line highlighting where most revenue is captured by our poutine products.`
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Checkpoint
-- MAGIC
-- MAGIC <img src="./Includes/images/dashboard_checkpoint_pg2_pareto_red.png" alt='Checkpoint' width="1200"> 
-- MAGIC
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Reading the Visualization
-- MAGIC <img src="./Includes/images/pareto_explained_viz.png" alt='Checkpoint' width="1200"> 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## I. Summary and Key Takeaways
-- MAGIC
-- MAGIC - Set up global and page-level filters for interactive dashboards  
-- MAGIC - Built key visuals, counters, 7-day sales, and comparison charts  
-- MAGIC - Created a Pareto chart to highlight top products using the 80/20 rule  
-- MAGIC - Wrote custom SQL for more advanced analysis  
-- MAGIC - Designed a clean, readable dashboard and refined it with AI help  

-- COMMAND ----------

-- MAGIC %md-sandbox
-- MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
-- MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
-- MAGIC <script>
-- MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
-- MAGIC </script>