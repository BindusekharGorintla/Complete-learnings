# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Demo - Short-term Agent Memory with Lakebase Autoscaling
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This demonstration explores building conversational AI agents that maintain memory across interactions using Databricks Lakebase and LangGraph. Traditional agents are stateless — they forget previous interactions between API calls. This creates poor user experiences where agents cannot maintain context or build upon earlier conversation points.
# MAGIC
# MAGIC We'll implement short-term memory using LangGraph's checkpointing system backed by a Lakebase Autoscaling Postgres instance, enabling agents to remember conversation history within a single session. You'll learn to create stateful agents that can reference earlier messages, maintain context throughout conversations, and provide consistent, contextual responses.
# MAGIC
# MAGIC **Official Documentation:**
# MAGIC - [AI Agent Memory](https://docs.databricks.com/aws/en/generative-ai/agent-framework/stateful-agents?language=Predict_stream)
# MAGIC - [Create and manage a database instance](https://docs.databricks.com/aws/en/oltp/instances/create/)
# MAGIC - This demo uses `databricks_langchain` to connect Lakebase via the class [`CheckpointSaver`](https://github.com/databricks/databricks-ai-bridge/blob/main/integrations/langchain/src/databricks_langchain/checkpoint.py), which is a subclass/adapter of [`PostgresSaver`](https://reference.langchain.com/python/langgraph/checkpoints/?_gl=1*1n1i679*_gcl_au*MTMyMTI4Njc5MS4xNzY5Njk4NjY2*_ga*MTYwNjE1MTI0LjE3Njk2OTg2NjY.*_ga_47WX3HKKY2*czE3Njk2OTg2NjYkbzEkZzEkdDE3Njk2OTg4NTMkajYwJGwwJGgw#langgraph.checkpoint.postgres.PostgresSaver).
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this demonstration, you will be able to:
# MAGIC
# MAGIC 1. **Understand agent statefulness challenges** and why traditional agents lose context between interactions
# MAGIC 2. **Implement short-term memory** using LangGraph checkpointers with a Lakebase Autoscaling Postgres backend
# MAGIC 3. **Differentiate memory types** including short-term vs long-term memory and system prompts vs recalled context
# MAGIC 4. **Build conversation flows** that maintain context using thread IDs and checkpoint management
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Prerequisites</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">This demonstration assumes familiarity with Lakebase concepts as well as some basic concepts in this space like reading an MLflow trace and inferencing an AI Agent from Unity Catalog. Key concepts will be reviewed throughout the notebook as needed.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## REQUIRED - SELECT A COMPUTE ENVIRONMENT
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Select Compute</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Before starting this notebook, select the required compute environment listed below.</p>
# MAGIC <ul style="margin: 12px 0 0 16px; color: #333;">
# MAGIC <li><strong>Serverless Compute, Version 5</strong> — <a href="https://docs.databricks.com/aws/en/compute/serverless/dependencies#-select-an-environment-version" style="color: #1976d2; text-decoration: underline;">How to select an environment version</a></li>
# MAGIC </ul>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;"><strong>NOTE:</strong> This notebook was <strong>developed and tested using Serverless V5</strong>. Other compute options may work but are not guaranteed to behave the same or support all features demonstrated.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. Classroom Setup

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A1. Setup Your Environment
# MAGIC
# MAGIC Run the cell below to install the necessary packages.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Packages Summary</strong>
# MAGIC <ul style="margin: 12px 0 0 16px; color: #333;">
# MAGIC <li><code>backoff</code> — Adds automatic retry logic to handle transient API and network failures.</li>
# MAGIC <li><code>databricks-openai</code> — Provides Databricks native access to foundation models and AI endpoints using OpenAI compatible APIs.</li>
# MAGIC <li><code>uv</code> — A fast Python package installer and environment manager used to speed up dependency installs.</li>
# MAGIC <li><code>databricks-agents</code> — Provides utilities and templates for building, configuring, and running AI agents on Databricks.</li>
# MAGIC <li><code>mlflow-skinny[databricks]</code> — Enables lightweight MLflow tracking and experiment logging in Databricks without the full MLflow install.</li>
# MAGIC <li><code>databricks_langchain</code> — Integrates LangChain with Databricks services, models, and Unity Catalog.</li>
# MAGIC <li><code>databricks-langchain</code> — Databricks maintained LangChain integration for building and running LLM powered workflows on Databricks.</li>
# MAGIC <li><code>langchain-community</code> — Provides community maintained integrations and connectors for LangChain.</li>
# MAGIC <li><code>langchain</code> — The core framework for building LLM driven chains, tools, and agents.</li>
# MAGIC <li><code>unitycatalog-langchain[databricks]</code> — Connects LangChain to Unity Catalog for governed access to data, functions, and tools.</li>
# MAGIC <li><code>unitycatalog-ai[databricks]</code> — Adds Unity Catalog native support for registering, governing, and serving AI assets and tools.</li>
# MAGIC <li><code>databricks-sdk</code> — Provides programmatic access to Databricks REST APIs for managing workspaces and resources.</li>
# MAGIC <li><code>databricks-langchain[memory]</code> — Adds Lakebase backed chat memory and state management for LangChain agents running on Databricks.</li>
# MAGIC </ul>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

!pip install -U -qqqq backoff databricks-openai uv databricks-agents mlflow-skinny[databricks] databricks_langchain
!pip install -U databricks-langchain langchain-community langchain 
!pip install unitycatalog-langchain[databricks]
!pip install unitycatalog-ai[databricks]
!pip install -U databricks-sdk
!pip install databricks-langchain[memory]
!pip install reportlab
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A2. Create Lakebase Autoscaling Instance
# MAGIC
# MAGIC Next, set up your Lakebase Autoscaling instance. This workshop uses **Lakebase Autoscaling** as the Postgres backend for checkpoint storage.
# MAGIC
# MAGIC For a detailed feature comparison between provisioned and autoscaling instances, see the Lakebase documentation: <a href="https://docs.databricks.com/aws/en/oltp/#feature-comparison" style="color: #1976d2; text-decoration: underline;">Feature comparison</a>.
# MAGIC
# MAGIC Follow the steps below to create a new Autoscaling project.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Open the Lakebase App (Autoscaling)</strong>
# MAGIC <ol style="margin: 12px 0 0 16px; color: #333;">
# MAGIC <li>Sign in to your Databricks workspace.</li>
# MAGIC <li>In the left side menu, click <strong>Compute</strong>.</li>
# MAGIC <li>From the menu, choose <strong>Lakebase</strong> at the top of the screen. This opens the Lakebase UI.</li>
# MAGIC <li>In the Lakebase UI, if you see multiple options (for example <strong>Autoscaling</strong> vs <strong>Provisioned</strong>), select <strong>Autoscaling</strong> to switch to the Autoscaling projects view.</li>
# MAGIC </ol>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;"><strong>Note:</strong> On workspaces that have completed the March '26 rollout, new Lakebase instances are created as Autoscaling projects by default.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Create a New Autoscaling Project</strong>
# MAGIC <ol style="margin: 12px 0 0 16px; color: #333;">
# MAGIC <li>In the <strong>Autoscaling</strong> view (Projects list), click <strong>New project</strong>.</li>
# MAGIC <li>In the <strong>Create project</strong> dialog, fill in the following:
# MAGIC   <ul style="margin: 8px 0 0 16px;">
# MAGIC     <li><strong>Project name:</strong> Enter the name <code>agent-memory-username</code>, e.g. <code>agent-memory-spark-mcspark</code>, where the username is <code>sparky.myspark@databricks.com</code>. Run the next cell and copy and paste the result for your Lakebase instance name.</li>
# MAGIC     <li><strong>Postgres version:</strong> Choose the Postgres version as 17 (currently 16 or 17 will be displayed, depending on cloud).</li>
# MAGIC   </ul>
# MAGIC </li>
# MAGIC <li>Click <strong>Create</strong> to provision the Autoscaling instance.</li>
# MAGIC </ol>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Databricks will provision a Lakebase Autoscaling project with a single production branch (root branch), a default <code>databricks_postgres</code> database, and a primary compute with autoscaling enabled. Provisioning typically completes within seconds; the compute may show a short "starting/activating" state.</p>
# MAGIC
# MAGIC **Note🚨** In Vocareum enviroment, use the Lakebase name from the cell output below.
# MAGIC
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

user_email = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
local_part = user_email.lower().split("@")[0]
cleaned = local_part.replace(".", "-").replace("_", "-")
print(f"Lakebase instance name to use: agent-memory-{cleaned}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. Understanding Agent Statefulness Challenges

# COMMAND ----------

# MAGIC %md
# MAGIC ### B1. The Core Problem: Agents are Stateless
# MAGIC
# MAGIC The fundamental challenge with AI agents is that they are inherently **stateless**. **Each API call to an agent is independent** — the agent has no memory of previous interactions. In production environments, agents run on distributed model serving where different replicas may handle different requests within the same conversation.
# MAGIC
# MAGIC Without implementing persistence mechanisms, agents cannot:
# MAGIC - Maintain context across conversation turns
# MAGIC - Learn from past interactions within a session
# MAGIC - Provide coherent follow-up responses
# MAGIC - Reference earlier conversation points
# MAGIC
# MAGIC This creates fragmented user experiences where users must constantly re-establish context.

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. LangGraph Memory Architecture

# COMMAND ----------

# MAGIC %md
# MAGIC ### C1. LangGraph's Dual Memory System
# MAGIC
# MAGIC <img src="./Includes/images/langGraphs_dual_memory.png" alt="Dual Memory" width='1000' />
# MAGIC
# MAGIC LangGraph provides two separate, purpose-built systems for agent memory:
# MAGIC
# MAGIC 1. **Checkpointers** for short-term memory (thread-scoped)
# MAGIC 2. **Store** for long-term memory (cross-session)
# MAGIC
# MAGIC This demonstration focuses on **checkpointers** for short-term memory management.

# COMMAND ----------

# MAGIC %md
# MAGIC ### C2. Checkpointers: Short-Term Memory Management
# MAGIC
# MAGIC **Checkpointers** manage thread-scoped conversation state — everything happening within a single conversation session. This includes:
# MAGIC
# MAGIC - All messages exchanged between user and agent
# MAGIC - Tool calls and their results
# MAGIC - Agent decisions at each step
# MAGIC - Complete graph execution state
# MAGIC
# MAGIC LangGraph **automatically** saves checkpoints after each node execution, isolated per `thread_id`. This enables:
# MAGIC
# MAGIC - **Time travel**: Replay or fork conversations from any checkpoint
# MAGIC - **Conversation resumption**: Continue exactly where you left off
# MAGIC - **Thread isolation**: Each conversation maintains independent state

# COMMAND ----------

# MAGIC %md
# MAGIC ### C3. Store: Long-Term Memory (High Level Overview)
# MAGIC
# MAGIC A LangGraph **Store** provides cross-thread persistent memory that survives beyond individual conversations. Unlike checkpointers:
# MAGIC
# MAGIC - Organized by **custom namespaces** (e.g., user_id, org_id) rather than thread_id
# MAGIC - **Explicitly managed** by the agent through tools (not automatic)
# MAGIC - Stores **curated knowledge** (facts, preferences) rather than full conversation history
# MAGIC - Supports **semantic search** with vector embeddings to retrieve relevant memories
# MAGIC
# MAGIC The Store allows agents to remember user preferences, learned facts, and important context across all conversations, enabling personalized experiences over time.

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Memory Types and Implementation Patterns

# COMMAND ----------

# MAGIC %md
# MAGIC ### D1. Short-Term vs Long-Term Memory Comparison
# MAGIC
# MAGIC This demonstration focuses on short-term memory and time travel capabilities with LangGraph checkpoints. Each checkpoint resume creates a new fork in conversation history, preserving the original while enabling further experimentation.
# MAGIC
# MAGIC | **Short-Term Memory** | **Long-Term Memory** |
# MAGIC |----------------------|---------------------|
# MAGIC | Capture context in a single conversation session using thread IDs and checkpointing | Automatically extract and store key insights across multiple sessions |
# MAGIC | Maintain context for follow-up questions within a session | Personalize interactions based on past preferences |
# MAGIC | Debug and test conversation flows using time travel | Build a knowledge base about users that improves responses over time |
# MAGIC | **Example 1:** Agent calls a SQL tool and holds the query result in context while deciding the next step in the same run | **Example 1:** Agent stores a summary of last week's pipeline failure so future runs can reference what went wrong |
# MAGIC | **Example 2:** User says "filter to Q3 only" — agent remembers this preference for the rest of the conversation | **Example 2:** Agent recalls that a specific user always wants outputs written to Delta tables, not returned as Pandas DataFrames |
# MAGIC | **Example 3:** Agent tracks which steps it has already completed mid-task to avoid repeating them within the same session | **Example 3:** Agent retrieves relevant runbook docs from a vector index to answer a question about an unfamiliar environment |

# COMMAND ----------

# MAGIC %md
# MAGIC ### D2. Technical Architecture Differences
# MAGIC
# MAGIC **Short-Term Memory (Thread-Scoped):**
# MAGIC - **Scope**: Maintains context within a single conversation session/thread
# MAGIC - **Storage**: Uses LangGraph checkpointer with Lakebase Autoscaling as the Postgres backend
# MAGIC - **Thread ID**: Each conversation gets a unique `thread_id` that persists conversation state
# MAGIC - **Use Case**: Remembers what was said earlier in the same conversation
# MAGIC - **Implementation**: Uses `langgraph-checkpoint-postgres` library to save graph state at each step
# MAGIC - **Example**: User says "I'm going to SF" and later asks "Where did I say I'm going?" — agent remembers within that thread
# MAGIC
# MAGIC **Long-Term Memory (Cross-Session):**
# MAGIC - **Scope**: Stores information across multiple different conversations and sessions
# MAGIC - **Storage**: Uses custom namespaces in Lakebase (via `langgraph.store.postgres.PostgresStore`)
# MAGIC - **Use Case**: Remembers user preferences, facts, and experiences across all conversations
# MAGIC - **Implementation**: Extracts and stores key information that should persist beyond individual threads
# MAGIC - **Example**: Remembering a user's name, preferences, or past purchases across all future conversations

# COMMAND ----------

# MAGIC %md
# MAGIC ### D3. System Prompt vs. Memory: Key Distinctions
# MAGIC
# MAGIC **System Prompt (Instructions)** — Static instructions defining HOW the agent should behave:
# MAGIC - Set at design/deployment time by developers
# MAGIC - Defines agent's personality, role, rules, and constraints
# MAGIC - Typically the same for all users (or user groups)
# MAGIC - Does not change based on individual user interactions
# MAGIC - Lives in the prompt template/agent configuration
# MAGIC
# MAGIC **Memory (Recalled Context)** — Dynamic information ABOUT the user or conversation:
# MAGIC - Created during interactions with users
# MAGIC - Contains facts learned FROM conversations
# MAGIC - Personalized per user/thread
# MAGIC - Changes over time based on interactions
# MAGIC - Retrieved from storage and injected into context
# MAGIC
# MAGIC **Summary:**
# MAGIC - System Prompt tells the agent HOW to act (consistent behavior)
# MAGIC - Short-Term Memory tells the agent WHAT was just discussed (conversation flow)
# MAGIC - Long-Term Memory tells the agent WHO they're talking to (personalization)

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. Agent Implementation and Configuration

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### E1. Confirm Lakebase is Now Available
# MAGIC
# MAGIC Before proceeding, verify that your Lakebase Autoscaling instance is ready.
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Confirm Lakebase is Now Available</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">At this point, your <strong>Lakebase Autoscaling</strong> instance should be ready.</p>
# MAGIC <ol style="margin: 12px 0 0 16px; color: #333;">
# MAGIC <li>Navigate to <strong>Compute</strong> in the left sidebar.</li>
# MAGIC <li>Select <strong>Lakebase</strong>, then click on <strong>Autoscaling</strong>. This takes you to all available Autoscaling Database Projects.</li>
# MAGIC <li>Locate your project. If the status is not <strong>Available</strong>, wait until provisioning completes before continuing.</li>
# MAGIC </ol>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### E2. Run Classroom Setup
# MAGIC
# MAGIC Run the cells below to set up your environment and agent.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">What the Setup Script Does</strong>
# MAGIC <ul style="margin: 12px 0 0 16px; color: #333;">
# MAGIC <li>Creates a user-scoped catalog, schema, volume, and MLflow experiment for isolated demo work.</li>
# MAGIC <li>Ingests and prepares sample data used by the agent for grounding.</li>
# MAGIC <li>Registers the agent and tools in Unity Catalog and connects chat memory to Lakebase.</li>
# MAGIC </ul>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;"><strong>NOTE:</strong> Knowing how to create an agent and define agent tools is a prerequisite for this demo and is outside the scope of this workshop.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Outside the Scope of This Demo</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">This demo focuses on building short-term memory for an agent using Lakebase in Databricks. While your workspace includes precreated <strong>Functions</strong>, <strong>Models</strong>, and other assets, a deeper dive into these model types and concepts is outside the scope of this workshop. Additionally, this course does not teach <strong>Lakebase Fundamentals</strong>.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC 1. Run the classroom setup script.
# MAGIC
# MAGIC > Review the output table at the end for information about your environment.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-1

# COMMAND ----------

# MAGIC %md
# MAGIC 2. View your precreated Unity Catalog objects for this demo:
# MAGIC
# MAGIC    a. In the Workspace sidebar, select the **Catalog** icon.
# MAGIC
# MAGIC    b. In Unity Catalog, expand your **labuser_** catalog.
# MAGIC
# MAGIC    c. Expand the **lb_ai_training** schema.
# MAGIC
# MAGIC    d. Expand **Tables**. You should see a table named `sf_airbnb_listings`.
# MAGIC
# MAGIC    e. Expand **Functions**. You should see two functions created for your agent:
# MAGIC       - `budget_constraints`
# MAGIC       - `cnt_by_room_type`
# MAGIC
# MAGIC    f. Expand **Models**. You should see a model named `short_term_lakebase`.

# COMMAND ----------

# MAGIC %md
# MAGIC ### E3. Loading the Agent from Unity Catalog
# MAGIC
# MAGIC Load a pre-trained agent from Unity Catalog using `mlflow.pyfunc.load_model()`.
# MAGIC
# MAGIC The following cells configure MLflow autologging and set up the tracking environment. The experiment location was established during the setup process and follows the pattern `/Users/<username>/lakebase_experiment`.

# COMMAND ----------

import mlflow

# Set up MLflow tracking to Databricks
mlflow.set_tracking_uri("databricks")
mlflow.set_experiment(experiment_location)

# COMMAND ----------

# MAGIC %md
# MAGIC ### E4. Model Registry Configuration
# MAGIC
# MAGIC Configure the Unity Catalog registry and load the agent model using the `champion` alias for production-ready deployment.
# MAGIC
# MAGIC #### Where is the agent's code?
# MAGIC The code that defines your agent came from the code in the `artifacts` folder. In particular, you will find `short_term_lakebase_agent.py` along with a configs folder that defines various environments for your agent that is already registered to Unity Catalog. However, as shown in the cell below, we are inferencing our agent from Unity Catalog, where the agent was registered. All traces will appear in UC as well for this notebook. 
# MAGIC
# MAGIC #### Inspect your Agent
# MAGIC For convenience, navigate to `./artifacts/short_term_lakebase_agent.py` to inspect that agent's code. This demonstration is not intended to provide a deep dive into agent-as-code, but we summarize components of this code below. 
# MAGIC
# MAGIC ```
# MAGIC run_agent(query, thread_id)
# MAGIC     │
# MAGIC     ├─ config = {"configurable": {"thread_id": ...}}
# MAGIC     │
# MAGIC     └─ workflow.compile(checkpointer=checkpointer)
# MAGIC             │
# MAGIC             ├─ CheckpointSaver
# MAGIC             │   └─ at every node, saves the full graph state to Lakebase
# MAGIC             │       keyed by thread_id
# MAGIC             │       └─ Lakebase tables: checkpoint, checkpoint_blobs,
# MAGIC             │                           checkpoint_migrations, checkpoint_writes
# MAGIC             │
# MAGIC             ├─ agent node → calls model_with_tools
# MAGIC             │     └─ model decides: call a tool, or answer directly
# MAGIC             │
# MAGIC             └─ tools node → executes tool calls
# MAGIC                   ├─ budget_constraints    (UC search tool)
# MAGIC                   └─ cnt_by_room_type      (UC search tool)
# MAGIC ```
# MAGIC
# MAGIC The `thread_id` is the key that ties everything together:
# MAGIC
# MAGIC - **Same `thread_id`** — the checkpointer loads the saved state and the agent picks up exactly where it left off
# MAGIC - **New `thread_id`** — no saved state exists, the agent starts completely blank
# MAGIC
# MAGIC The checkpointer saves automatically. You never call it directly — `workflow.compile(checkpointer=checkpointer)` is the only place you mention it, and from that point forward LangGraph handles all reads and writes at every node transition. We will see components of this code executed down below. But first, let's load the agent as `agent`. 

# COMMAND ----------

# Set the registry to Unity Catalog
mlflow.set_registry_uri("databricks-uc")

# Load the model using the UC path and alias
alias = "champion"

UC_MODEL_NAME = f"{catalog_name}.{schema_name}.{agent_name}"

print(UC_MODEL_NAME)

# Load from Unity Catalog by alias (recommended for production)
agent = mlflow.pyfunc.load_model(f"models:/{UC_MODEL_NAME}@{alias}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### E5. Lakebase Instance Configuration

# COMMAND ----------

# MAGIC %md
# MAGIC #### E5.1 Explore the Precreated Agent Configuration Files
# MAGIC
# MAGIC The demo setup has created two YAML configuration files for your agent in the `./artifacts/config` folder. Open each file and review the configurations before using them in the demo.
# MAGIC
# MAGIC - `./artifacts/configs/short_term_lakebase_agent_config.yaml`
# MAGIC   - Contains the system prompt, mappings for `LLM_ENDPOINT_NAME`, `CATALOG_NAME`, `SCHEMA_NAME`, `LAKEBASE_AUTOSCALING_PROJECT`, `LAKEBASE_AUTOSCALING_BRANCH`, and the agent tools `budget_constraints` and `cnt_by_room_type`.
# MAGIC
# MAGIC **NOTE:** Modularizing these configurations makes them easier to manage and maintain. If you decide to update your agent, you should update these values and re-register your agent to UC. This process falls outside the scope of this demo. 

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### E5.2 Load Lakebase Configuration from YAML
# MAGIC
# MAGIC Run the cell below to load the Lakebase Autoscaling instance configuration from the agent's YAML configuration file. This establishes the project name and branch used for checkpoint storage.
# MAGIC
# MAGIC
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Why <code>mlflow.models.ModelConfig?</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;"><code>mlflow.models.ModelConfig()</code> is standard practice because it 
# MAGIC
# MAGIC <li>Parameterizes your model/agent</li>
# MAGIC <li>Travels with the model into UC and Model Serving</li>
# MAGIC <li>Keeps dev/prod code paths identical, with only the configuration swapped underneath.</li></p>

# COMMAND ----------

# Read the information from the YAML files 
agent_config_file = "./artifacts/configs/short_term_lakebase_agent_config.yaml"

# Load the agent configuration from the YAML file into an MLflow ModelConfig object
model_config=mlflow.models.ModelConfig(development_config=agent_config_file)
lakebase_autoscaling_project=model_config.get("LAKEBASE_AUTOSCALING_PROJECT")
lakebase_autoscaling_branch=model_config.get("LAKEBASE_AUTOSCALING_BRANCH")

# Print out the information
print(f"Lakebase project name: {lakebase_autoscaling_project}")
print(f"Lakebase branch name: {lakebase_autoscaling_branch}")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### E6. Checkpoint Table Setup
# MAGIC
# MAGIC Initialize the checkpoint tables in Lakebase. This is a one-time setup operation that creates the necessary database schema for storing conversation state.
# MAGIC
# MAGIC - [Databricks Langchain Integrations Python API](https://api-docs.databricks.com/python/databricks-ai-bridge/latest/databricks_langchain.html)
# MAGIC - [databricks_langchain.CheckpointSaver](https://api-docs.databricks.com/python/databricks-ai-bridge/latest/databricks_langchain.html#databricks_langchain.CheckpointSaver)
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Database Connection</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">The output will show connection pool initialization with details like hostname and connection parameters, indicating successful database setup.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

from databricks_langchain import CheckpointSaver

with CheckpointSaver(
                project=lakebase_autoscaling_project, 
                branch=lakebase_autoscaling_branch
                ) as saver:
    saver.setup()
    print("✅ Checkpoint tables are ready.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## F. Building Stateful Conversations

# COMMAND ----------

# MAGIC %md
# MAGIC ### F1. Agent Response Helper Functions
# MAGIC
# MAGIC Create helper functions to interact with the agent.
# MAGIC
# MAGIC - The `agent_response` function creates new conversation threads.
# MAGIC - The `shallow_memory_agent_response` function includes a **thread_id** to maintain conversation state across turns.
# MAGIC - The `render_output` function displays the agent's final response by taking the markdown string out of the dictinary object and passing it to a markdown renderer from `IPython.display`.
# MAGIC
# MAGIC All traces will present themselves in this notebook. However, you can also view your registered agent in Unity Catalog, where the trace is logged there as well. 

# COMMAND ----------

from IPython.display import Markdown, display

# Send a single user query to the agent and start a new conversation thread
def agent_response(query: str):
    payload = {
        "input": [
            {
                "role": "user",
                "content": query
            }
        ]
    }
    return agent.predict(payload)


# Send a user query to the agent while reusing a thread_id to preserve conversation context
def shallow_memory_agent_response(query: str, thread_id: str):
    payload = {
        "input": [
            {
                "role": "user",
                "content": query
            }
        ],
        "custom_inputs": {
            "thread_id": thread_id
        }
    }
    return agent.predict(payload)


def render_output(result):

  # Extract the markdown text from your result
  md_text = result["output"][0]["content"][0]["text"]

  display(Markdown(md_text))

# COMMAND ----------

# MAGIC %md
# MAGIC ### F2. Conversation Flow Design
# MAGIC
# MAGIC Design a sequence of queries that test the agent's ability to maintain context and reference previous conversation elements.
# MAGIC
# MAGIC This conversation simulates a realistic Airbnb search scenario with follow-up questions. Read each query in the cell below before running it.

# COMMAND ----------

query_1 = "I'm looking for an Airbnb in San Francisco in the Mission neighborhood. My budget is around $200 per night and I prefer those properties with a private room. Those are my only requirements. Can you give me 2 listings?"

query_2 = "Which one is cheapest?"

query_3 = "Does it have the type of bedroom I asked for?"

query_4 = "Okay, tell me about that property instead then."

# COMMAND ----------

# MAGIC %md
# MAGIC ### F3. Initial Query and Thread ID Capture
# MAGIC
# MAGIC Execute the first query without specifying a `thread_id`, which **creates a new conversation thread at runtime**.
# MAGIC
# MAGIC We then capture the generated `thread_id` from the response for use in all subsequent interactions to maintain conversation continuity.

# COMMAND ----------

# Message 1, don't include thread_id (creates new thread)
result1 = agent_response(query_1)

print(f'\nQuery 1: {query_1}\n')
print(result1)

# COMMAND ----------

# MAGIC %md
# MAGIC ### F4. Thread ID Extraction
# MAGIC
# MAGIC Extract the `thread_id` from the response. This identifier links all subsequent messages in the conversation and enables the agent to access previous conversation context from checkpoint storage.

# COMMAND ----------

thread_id = result1['custom_outputs']['thread_id']
print(thread_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ### F5. Testing Contextual Understanding
# MAGIC
# MAGIC Test whether the agent understands the original query's constraints by asking a follow-up question that requires referencing the previous message.
# MAGIC
# MAGIC The agent should identify which listing is cheaper based on the initial search results.

# COMMAND ----------

result2 = shallow_memory_agent_response(query_2, thread_id)

render_output(result2)

# COMMAND ----------

# MAGIC %md
# MAGIC ### F6. Validating Memory Persistence
# MAGIC
# MAGIC Continue testing memory persistence by asking about specific requirements mentioned in the original query.
# MAGIC
# MAGIC The agent should remember the **"private room"** requirement from `query_1` without it being restated:
# MAGIC
# MAGIC ```
# MAGIC query_1 = "I'm looking for an Airbnb in San Francisco in the Mission neighborhood. My budget is around $200 per night
# MAGIC and I prefer those properties with a private room. Those are my only requirements. Can you give me 2 listings?"
# MAGIC ```

# COMMAND ----------

result3 = shallow_memory_agent_response(query_3,thread_id)

render_output(result3)

# COMMAND ----------

# MAGIC %md
# MAGIC ### F7. Location Context Verification
# MAGIC
# MAGIC Test the agent's ability to provide location details about the selected property, demonstrating that it maintains context about both the neighborhood preference (Mission) and the specific listing being discussed.

# COMMAND ----------

result4 = shallow_memory_agent_response(query_4,thread_id)

render_output(result4)

# COMMAND ----------

# MAGIC %md
# MAGIC ### F8. Demonstrating Stateless Behavior
# MAGIC
# MAGIC Compare stateful vs stateless behavior by running the same query without the `thread_id`.
# MAGIC
# MAGIC This demonstrates how the agent loses context when thread continuity is broken. Notice how the response differs from the stateful version above.

# COMMAND ----------

result5 = agent_response(query_4)
render_output(result5)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## G. Agent Evaluation and Quality Assessment

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### G1. Understanding Evaluation Context
# MAGIC
# MAGIC Now that we've demonstrated state persistence, we'll evaluate whether the agent actually incorporates information from earlier conversation turns. This evaluation process uses MLflow to systematically assess conversation quality and memory utilization via the `Guidelines()` judge. 
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC     <span style="font-size: 24px; line-height: 1;"></span>
# MAGIC     <div>
# MAGIC       <strong style="color: #0d47a1; font-size: 1.1em;">
# MAGIC         MLflow Built-In Judges
# MAGIC       </strong>
# MAGIC       <p style="margin: 8px 0 0; color: #333;">
# MAGIC         You can read more about MLflow built-in judges
# MAGIC         <a
# MAGIC           href="https://docs.databricks.com/aws/en/mlflow3/genai/eval-monitor/concepts/scorers"
# MAGIC           style="color: #1976d2; text-decoration: underline;"
# MAGIC           target="_blank"
# MAGIC           rel="noopener noreferrer"
# MAGIC         >
# MAGIC           here
# MAGIC         </a>.
# MAGIC       </p>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### G2. Experiment Retrieval and Metadata
# MAGIC
# MAGIC Retrieve the latest experiment using the experiment location established during setup. This provides access to conversation traces and execution metadata for evaluation purposes.

# COMMAND ----------

# Get the latest experiment
print(f'Your experiment location: {experiment_location}')
exp = mlflow.get_experiment_by_name(experiment_location)

# COMMAND ----------

# MAGIC %md
# MAGIC Next, we will search our runs and find the correct experiment ID. We'll need this to bring in our trace information. 

# COMMAND ----------

runs = mlflow.search_runs(
    experiment_ids=[exp.experiment_id],
    order_by=["attributes.start_time DESC"],  # or "start_time DESC"
    max_results=1
)
latest_exp_id = runs.iloc[0].experiment_id
print(f"Experiment ID: {latest_exp_id}")
display(runs)

# COMMAND ----------

# MAGIC %md
# MAGIC ### G3. Trace Data Collection
# MAGIC
# MAGIC Collect conversation traces from the latest experiment using [`mlflow.search_traces()`](https://mlflow.org/docs/latest/genai/tracing/search-traces/). These traces contain the complete interaction history including user inputs, agent responses, and system metadata needed for evaluation.

# COMMAND ----------

# return_type defaults to pandas; max_results=1 ensures just the first trace
trace_df = mlflow.search_traces(
    locations=[latest_exp_id],
    order_by=["attributes.timestamp_ms DESC"]
    )

# COMMAND ----------

# MAGIC %md
# MAGIC display the set of traces from this particular experiment. You can click on each trace and view the trace. Note: we have not performed any evaluation yet - so these traces remain judge-free for now. Once we perform judging, we can navigate back to this cell and inspect the traces to see the judgements. 

# COMMAND ----------

display(trace_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### G4. Evaluation Framework Setup
# MAGIC
# MAGIC Configure the evaluation framework using MLflow's built-in Guidelines scorer. This creates a pass/fail evaluation criterion to assess whether the agent appropriately acknowledges and incorporates previous conversation context. The Guidelines judge applies uniform guidelines across all rows in your evaluation or traces in production monitoring. It automatically extracts request/response data from your trace and evaluates it against your guidelines. The list of possible parameters you can pass are summarized in the following table: 
# MAGIC
# MAGIC Here it is formatted as a clean Markdown table:
# MAGIC
# MAGIC | Parameter    | Type               | Required | Description                                         |
# MAGIC | ------------ | ------------------ | -------- | --------------------------------------------------- |
# MAGIC | `name`       | `str`              | Yes      | Name for the judge, displayed in evaluation results |
# MAGIC | `guidelines` | `str \| list[str]` | Yes      | Guidelines to apply uniformly to all rows           |
# MAGIC | `model`      | `str`              | No       | Custom judge model                                  |

# COMMAND ----------

# MAGIC %md
# MAGIC Import the necessary libraries

# COMMAND ----------

import mlflow
from mlflow.genai import evaluate
from mlflow.genai.scorers import Guidelines

# COMMAND ----------

# MAGIC %md
# MAGIC Create your guideline. An example is provided but you can update to whatever you would like to judge for your traces. The guidelines will be read in from the yaml file stored in `./artifacts/configs`

# COMMAND ----------

agent_eval_config = "./artifacts/configs/agent_eval_config.yaml"

# Load the agent evaluation configuration from the YAML file into an MLflow ModelConfig object
eval_config = mlflow.models.ModelConfig(development_config=agent_eval_config)

# Read the recall evaluation model endpoint from the evaluation configuration
recall_eval_endpoint = eval_config.get("RECALL_EVAL_ENDPOINT")

# Read the recall grading instructions used for evaluation prompts
recall_guidelines = eval_config.get("RECALL_INSTRUCTIONS")

guidelines = Guidelines(
    name="acknowledge_previous_response",
    guidelines=recall_guidelines,
    model=recall_eval_endpoint 
)

# COMMAND ----------

# MAGIC %md
# MAGIC Run evaluation. This attaches judge feedback to our traces from earlier. 

# COMMAND ----------

results = evaluate(
    data=trace_df,          # existing traces (pandas DataFrame)
    scorers=[guidelines],   # any built-in judges/scorers
)

# 3) Inspect judge feedback on the produced evaluation traces
eval_traces = mlflow.search_traces(run_id=results.run_id, return_type="list")
eval_traces

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC Inspect the results. Click on **View evaluation results in MLflow** from the output above and click on **Traces* to the left. There you will see a screen that looks like the following with the 4 queries we sent in earlier along with a column that says **acknowledge_previous_response**. 
# MAGIC ![mlflow-ui1.png](./Includes/images/mlflow-ui1.png "mlflow-ui1.png")
# MAGIC
# MAGIC Clicking on any of the traces you see present and you will see something similar to the following. Notice we have expanded the feedback for **acknowledge_previous_response**. 
# MAGIC
# MAGIC ![mlflow-ui2.png](./Includes/images/mlflow-ui2.png "mlflow-ui2.png")
# MAGIC
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Different Grading</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Note that because our inputs for the LLM judge are outputs from an LLM, we cannot control the grading even in a controlled environment like this notebook 100% of the time. So, your graded responses might appear different than what you see in the notebook.
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## H. Explore and Verify the Lakebase Tables
# MAGIC
# MAGIC Complete the following steps to view the checkpoint tables that were created in your Lakebase Autoscaling instance.
# MAGIC
# MAGIC 1. Navigate back to your **Lakebase** instance by clicking on **Compute > Lakebase > Autoscaling**.
# MAGIC
# MAGIC 2. On the **Autoscaling Database Projects** landing page, select your Lakebase instance (`agent-memory-username`).
# MAGIC
# MAGIC 3. On the **Project dashboard**, click on **Tables** in the menu to the left.
# MAGIC
# MAGIC 4. You should see a series of **checkpoint_** tables created by your agent.
# MAGIC
# MAGIC #### Checkpoint Tables
# MAGIC ![Lakebase Tables](./Includes/images/lakebase_tables.png)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conclusion
# MAGIC
# MAGIC This demonstration illustrated several critical concepts for building production-ready conversational AI:
# MAGIC
# MAGIC 1. **Thread-based State Management** — Using thread IDs to maintain conversation continuity across multiple turns
# MAGIC 2. **Checkpoint Persistence** — Leveraging a Lakebase Autoscaling Postgres instance for reliable state storage
# MAGIC 3. **Memory Architecture** — Understanding the distinction between short-term (thread-scoped) and long-term (cross-session) memory systems
# MAGIC 4. **Stateful vs Stateless Behavior** — Observing how removing a `thread_id` breaks conversation context
# MAGIC 5. **Evaluation Frameworks**: Systematic assessment of agent memory and conversation quality
# MAGIC
# MAGIC ### Next Steps
# MAGIC
# MAGIC In the next notebook, you will extend these patterns to explore long-term memory using LangGraph's Store and cross-session personalization with Lakebase.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>