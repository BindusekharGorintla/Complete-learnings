# Build Single Threaded Stateful Agents with Lakebase

<!-- Replace the template below with information for your lab(s) -->
| Field           | Details       | Description                                                                 |
|-----------------|---------------|-----------------------------------------------------------------------------|
| Duration        | 60   | Estimated duration to complete the lab(s). |
| Level           | 300 | Target difficulty level for participants (100 = beginner, 200 = intermediate, 300 = advanced). |
| Lab Status      | Active | See descriptions in main repo README. |
| Course Location | N/A           | Indicates where the lab is hosted. <br> - **N/A** - Lab is only available in this repo. <br> - **Course name** - Lab has been moved into a full Databricks Academy course. |
| Developer       | Matthew McCoy | Primary developer(s) of the lab, separated by commas.  |
| Reviewer        | Som Natarajan , Peter Styliadis| Subject matter expert reviewer(s), separated by commas.|
| Product Version         | NA          | Specify a product version if applicable If not, use **N/A**. | 
---

## Description  
Provide a short description of the lab, explaining the purpose, audience, and what the learner will achieve.

## Learning Objectives
- Objective 1  
- Objective 2  
- Objective 3  

## Requirements & Prerequisites  
<!-- Example list below – update or replace with the specific requirements for your lab -->
Before starting this lab, ensure you have:  
- A **Databricks** workspace  
- A SQL warehouse  
- Write access to a catalog you own in Unity Catalog  
- Basic knowledge of SQL  



## Contents  
<!-- Replace the example below with the actual files included in your lab -->
This repository includes: 
- **1 Lab - Build Single Threaded Stateful Agents with Lakebase** notebook 
- **YAML artifacts** 
- Images and supporting materials


## Getting Started  
<!-- Replace the example below with the actual files included in your lab -->
1. Open the main lab notebook **1 Lab - Build Single Threaded Stateful Agents with Lakebase**.  
2. Follow the instructions step by step.   
