import logging
import os
import uuid
from typing import Annotated, Any, Generator, List, Dict, Optional, Sequence, TypedDict

import mlflow
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
    CheckpointSaver,
)
from databricks.sdk import WorkspaceClient
from langchain_core.messages import AIMessage, AIMessageChunk, AnyMessage
from langchain_core.runnables import RunnableConfig, RunnableLambda
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt.tool_node import ToolNode
from mlflow.pyfunc import ResponsesAgent
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
    ResponsesAgentStreamEvent,
    output_to_responses_items_stream,
)

logger = logging.getLogger(__name__)
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))

try:
    model_config = mlflow.models.ModelConfig()
except:
    config_file = "configs/agent_config.yaml"
    model_config = mlflow.models.ModelConfig(development_config=config_file)

SYSTEM_PROMPT = model_config.get("SYSTEM_PROMPT")
LLM_ENDPOINT_NAME = model_config.get("LLM_ENDPOINT_NAME")
CATALOG_NAME = model_config.get("CATALOG_NAME")
SCHEMA_NAME = model_config.get("SCHEMA_NAME")
TOOL1 = model_config.get("TOOL1")
TOOL2 = model_config.get("TOOL2")

############################################
# Lakebase configuration
############################################
# Option 1 (provisioned): set LAKEBASE_INSTANCE_NAME
# Option 2 (autoscaling): set LAKEBASE_AUTOSCALING_PROJECT + LAKEBASE_AUTOSCALING_BRANCH
LAKEBASE_INSTANCE_NAME = None
LAKEBASE_AUTOSCALING_PROJECT = model_config.get("LAKEBASE_AUTOSCALING_PROJECT") or None
LAKEBASE_AUTOSCALING_BRANCH = model_config.get("LAKEBASE_AUTOSCALING_BRANCH") or None

_has_autoscaling = LAKEBASE_AUTOSCALING_PROJECT and LAKEBASE_AUTOSCALING_BRANCH
if not LAKEBASE_INSTANCE_NAME and not _has_autoscaling:
    raise ValueError(
        "Lakebase configuration is required but not set. "
        "Please set one of the following:\n"
        "  Option 1 (provisioned): LAKEBASE_INSTANCE_NAME in agent_config.yaml\n"
        "  Option 2 (autoscaling): LAKEBASE_AUTOSCALING_PROJECT and "
        "LAKEBASE_AUTOSCALING_BRANCH environment variables\n"
    )

###############################################################################
## Define tools
###############################################################################
tools = []

UC_TOOL_NAMES: list[str] = [
    f"{CATALOG_NAME}.{SCHEMA_NAME}.{TOOL1}",
    f"{CATALOG_NAME}.{SCHEMA_NAME}.{TOOL2}",
]
if UC_TOOL_NAMES:
    uc_toolkit = UCFunctionToolkit(function_names=UC_TOOL_NAMES)
    tools.extend(uc_toolkit.tools)

VECTOR_SEARCH_TOOLS = []
tools.extend(VECTOR_SEARCH_TOOLS)

#####################
## Define agent logic
#####################


class AgentState(TypedDict):
    messages: Annotated[Sequence[AnyMessage], add_messages]
    custom_inputs: Optional[dict[str, Any]]
    custom_outputs: Optional[dict[str, Any]]


def _get_checkpointer_kwargs() -> dict[str, Any]:
    """Build keyword args for CheckpointSaver based on available Lakebase config.

    Returns kwargs for the provisioned (instance_name) path or the autoscaling
    (project + branch) path — whichever is configured.
    """
    if LAKEBASE_INSTANCE_NAME:
        return {"instance_name": LAKEBASE_INSTANCE_NAME}
    return {
        "project": LAKEBASE_AUTOSCALING_PROJECT,
        "branch": LAKEBASE_AUTOSCALING_BRANCH,
    }


class LangGraphResponsesAgent(ResponsesAgent):
    """Stateful agent using ResponsesAgent with pooled Lakebase checkpointing.

    Supports both provisioned Lakebase instances (LAKEBASE_INSTANCE_NAME) and
    autoscaling Lakebase (LAKEBASE_AUTOSCALING_PROJECT + LAKEBASE_AUTOSCALING_BRANCH).
    """

    def __init__(self):
        self.workspace_client = WorkspaceClient()
        self.model = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME)
        self.system_prompt = SYSTEM_PROMPT
        self.model_with_tools = self.model.bind_tools(tools) if tools else self.model
        self._checkpointer_kwargs = _get_checkpointer_kwargs()

    def _create_graph(self, checkpointer: Any):
        def should_continue(state: AgentState):
            messages = state["messages"]
            last_message = messages[-1]
            if isinstance(last_message, AIMessage) and last_message.tool_calls:
                return "continue"
            return "end"

        preprocessor = (
            RunnableLambda(
                lambda state: [{"role": "system", "content": self.system_prompt}]
                + state["messages"]
            )
            if self.system_prompt
            else RunnableLambda(lambda state: state["messages"])
        )
        model_runnable = preprocessor | self.model_with_tools

        def call_model(state: AgentState, config: RunnableConfig):
            response = model_runnable.invoke(state, config)
            return {"messages": [response]}

        workflow = StateGraph(AgentState)
        workflow.add_node("agent", RunnableLambda(call_model))

        if tools:
            workflow.add_node("tools", ToolNode(tools))
            workflow.add_conditional_edges(
                "agent", should_continue, {"continue": "tools", "end": END}
            )
            workflow.add_edge("tools", "agent")
        else:
            workflow.add_edge("agent", END)

        workflow.set_entry_point("agent")
        return workflow.compile(checkpointer=checkpointer)

    def _get_or_create_thread_id(self, request: ResponsesAgentRequest) -> str:
        """Get thread_id from request or create a new one.

        Priority:
        1. Use thread_id from custom_inputs if present
        2. Use conversation_id from chat context if available
        3. Generate a new UUID
        """
        ci = dict(request.custom_inputs or {})

        if "thread_id" in ci:
            return ci["thread_id"]

        if request.context and getattr(request.context, "conversation_id", None):
            return request.context.conversation_id

        return str(uuid.uuid4())

    def get_checkpoint_history(
        self, thread_id: str, limit: int = 10
    ) -> List[Dict[str, Any]]:
        """Retrieve checkpoint history for a thread."""
        config = {"configurable": {"thread_id": thread_id}}

        with CheckpointSaver(**self._checkpointer_kwargs) as checkpointer:
            graph = self._create_graph(checkpointer)

            history = []
            for state in graph.get_state_history(config):
                if len(history) >= limit:
                    break
                history.append(
                    {
                        "checkpoint_id": state.config["configurable"]["checkpoint_id"],
                        "thread_id": thread_id,
                        "timestamp": state.created_at,
                        "next_nodes": state.next,
                        "message_count": len(state.values.get("messages", [])),
                        "last_message": self._get_last_message_summary(
                            state.values.get("messages", [])
                        ),
                    }
                )

            return history

    def _get_last_message_summary(self, messages: List[Any]) -> Optional[str]:
        """Get a snippet of the last message for checkpoint identification."""
        return getattr(messages[-1], "content", "")[:100] if messages else None

    def update_checkpoint_state(
        self,
        thread_id: str,
        checkpoint_id: str,
        new_messages: Optional[List[Dict]] = None,
    ) -> Dict[str, Any]:
        """Update state at a specific checkpoint (used for modifying conversation history)."""
        config = {
            "configurable": {"thread_id": thread_id, "checkpoint_id": checkpoint_id}
        }

        with CheckpointSaver(**self._checkpointer_kwargs) as checkpointer:
            graph = self._create_graph(checkpointer)

            values = {}
            if new_messages:
                cc_msgs = self.prep_msgs_for_cc_llm(new_messages)
                values["messages"] = cc_msgs

            new_config = graph.update_state(config, values=values)

            return {
                "thread_id": thread_id,
                "checkpoint_id": new_config["configurable"]["checkpoint_id"],
                "parent_checkpoint_id": checkpoint_id,
            }

    def predict(self, request: ResponsesAgentRequest) -> ResponsesAgentResponse:
        """Non-streaming prediction."""
        ci = dict(request.custom_inputs or {})
        if "thread_id" not in ci:
            ci["thread_id"] = str(uuid.uuid4())
        request.custom_inputs = ci

        outputs = [
            event.item
            for event in self.predict_stream(request)
            if event.type == "response.output_item.done"
        ]

        custom_outputs = {"thread_id": ci["thread_id"]}
        if "checkpoint_id" in ci:
            custom_outputs["parent_checkpoint_id"] = ci["checkpoint_id"]

        try:
            history = self.get_checkpoint_history(ci["thread_id"], limit=1)
            if history:
                custom_outputs["checkpoint_id"] = history[0]["checkpoint_id"]
        except Exception as e:
            logger.warning(f"Could not retrieve new checkpoint_id: {e}")

        return ResponsesAgentResponse(output=outputs, custom_outputs=custom_outputs)

    def predict_stream(
        self,
        request: ResponsesAgentRequest,
    ) -> Generator[ResponsesAgentStreamEvent, None, None]:
        """Streaming prediction with Lakebase checkpoint branching support.

        Accepts in custom_inputs:
        - thread_id: Conversation thread identifier for session
        - checkpoint_id (optional): Checkpoint to resume from (for branching)
        """
        custom_inputs = request.custom_inputs or {}
        thread_id = custom_inputs.get("thread_id", str(uuid.uuid4()))
        checkpoint_id = custom_inputs.get("checkpoint_id")

        langchain_msgs = self.prep_msgs_for_cc_llm(
            [i.model_dump() for i in request.input]
        )

        checkpoint_config = {"configurable": {"thread_id": thread_id}}
        if checkpoint_id:
            checkpoint_config["configurable"]["checkpoint_id"] = checkpoint_id
            logger.info(
                f"Branching from checkpoint: {checkpoint_id} in thread: {thread_id}"
            )

        with CheckpointSaver(**self._checkpointer_kwargs) as checkpointer:
            graph = self._create_graph(checkpointer)

            for event in graph.stream(
                {"messages": langchain_msgs},
                checkpoint_config,
                stream_mode=["updates", "messages"],
            ):
                if event[0] == "updates":
                    for node_data in event[1].values():
                        if len(node_data.get("messages", [])) > 0:
                            yield from output_to_responses_items_stream(
                                node_data["messages"]
                            )
                elif event[0] == "messages":
                    try:
                        chunk = event[1][0]
                        if isinstance(chunk, AIMessageChunk) and chunk.content:
                            yield ResponsesAgentStreamEvent(
                                **self.create_text_delta(
                                    delta=chunk.content, item_id=chunk.id
                                ),
                            )
                    except Exception as exc:
                        logger.error("Error streaming chunk: %s", exc)


# ----- Export model -----
try:
    mlflow.langchain.autolog()
except:
    pass
AGENT = LangGraphResponsesAgent()
mlflow.models.set_model(AGENT)