from pyspark.sql import SparkSession
from pyspark.sql.functions import concat, lit, col, regexp_replace, trim

from pyspark.sql.types import StructType, StructField, StringType, ArrayType

spark = SparkSession.builder.getOrCreate()


def process_csv_data(
    databricks_share_name: str,
    table_name: str
) -> None:
    """Load and process CSV data into a Delta table."""

    df = (
        spark.read.format("csv")
        .option("header", "true")
        .option("inferSchema", "true")
        .option("multiLine", "true")
        .option("escape", '"')
        .load(f"/Volumes/{databricks_share_name}/v01/sf-listings/sf-airbnb.csv")
        .select("id", "name", "neighbourhood", "neighbourhood_cleansed", "summary", "price", "room_type")
        # Make price numeric: remove $ and , then cast to double (empty strings become nulls when cast)
        .withColumn("price", regexp_replace(trim(col("price")), "[$,]", "").cast("double"))
        .withColumn(
            "listing_source_information",
            concat(
                lit("ID of the property: "), col("id"),
                lit("\nName of the property: "), col("name"),
                lit("\nSummary of the property: "), col("summary"),
            ),
        )
        .limit(50)
    )

    df.write.mode("overwrite").saveAsTable(table_name)