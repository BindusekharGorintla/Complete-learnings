# Databricks notebook source
# MAGIC %pip install -U -qqqq pyyaml reportlab backoff databricks-openai databricks-agents mlflow-skinny[databricks] databricks-sdk
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import sys, os

ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()

# COMMAND ----------


includes_dir = "./Includes"
course_dir = os.path.dirname(includes_dir)
sys.path.insert(0, course_dir)


config_path = f"{includes_dir}/config/config_1.yaml" # Notebook number needs ot match config file name

# COMMAND ----------

from Includes import setup_demo_environment

env = setup_demo_environment(
    config_path=config_path,
)
catalog_name = env["catalog_name"]
schema_name = env["schema_name"]
agent_configs = env["agent_configs"]
agent_name = list(agent_configs.keys())[0]
experiment_location = agent_configs["short_term_lakebase"]["experiment_path"]