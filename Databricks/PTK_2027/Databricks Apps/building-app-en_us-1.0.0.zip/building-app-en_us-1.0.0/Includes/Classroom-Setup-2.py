# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

my_catalog = build_user_catalog(catalog_forced=None)  ## <-- Force the usage of a catalog if you can't create one.
spark.sql(f'USE CATALOG {my_catalog}')
my_schema = 'apps'
spark.sql(f'CREATE SCHEMA IF NOT EXISTS {my_schema}')
_ = spark.sql(f'USE SCHEMA {my_schema}')
my_volume = 'files'
spark.sql(f'CREATE VOLUME IF NOT EXISTS {my_volume}')
my_volume_path = f'/Volumes/{my_catalog}/{my_schema}/{my_volume}'
my_endpoint_name = f'rag-{my_catalog}-{my_schema}-{my_volume}'
my_job_name = f'index-{my_catalog}-{my_schema}-{my_volume}'


# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.apps import App
from databricks.sdk.errors import AlreadyExists
import os
import re

def to_app_name(username: str) -> str:
    name = username.lower()
    name = re.sub(r'[^a-z0-9]+', '-', name)  # replace invalid chars with dash
    name = re.sub(r'-+', '-', name)          # collapse multiple dashes
    name = name.strip('-')                   # trim leading/trailing dash
    return name

w = WorkspaceClient()

# ensure usernam (with domain dropped) is safe for app name and capped to 30 chars
my_app_name = to_app_name(w.current_user.me().user_name.split("@")[0])[0:30]
my_app_source = f'{os.getcwd()}/rag_app'

try:
    w.apps.create(
        app = App(
            name=my_app_name
        )
    )
    print(f"✅ Created App '{my_app_name}'.")

except AlreadyExists:
    print(f"✅ App check. App '{my_app_name}' already exists.")
    pass

# COMMAND ----------

dbutils.notebook.run(
    "Includes/Build RAG Pipeline",
    120,
    {
        "volume_path": my_volume_path,
        "serving_endpoint_name": my_endpoint_name,
        "index_job_name": my_job_name
    }
)

# COMMAND ----------

display_config_values(
    [
        ('Update Index Job', my_job_name),
        ('Input Volume', f'{my_catalog}.{my_schema}.{my_volume}'),
        ('Model Serving Endpoint', my_endpoint_name),
        ('App Name', my_app_name),
        ('App Source', my_app_source),
    ]
)