# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC <div style="display:flex; align-items:center; padding:10px 18px; background:#F8F9FA; border-bottom:1px solid #E0E0E0; gap:10px;">
# MAGIC   <img src="https://cdn.simpleicons.org/databricks/FF3621" width="22" height="22"/>
# MAGIC   <div style="font-size:14px; color:#666; white-space:nowrap;">
# MAGIC     <span style="font-weight:600; color:#333;">Academy</span>
# MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
# MAGIC     <span style="font-weight:600; color:#eb1900;">Build RAG Pipeline</span>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Build RAG Pipeline
# MAGIC
# MAGIC This notebook constructs the elements needed to support a RAG pipeline that processes input documents and serves, as output, a model that allows clients to ask questions about the material in the documents. The overall goal: enable an LLM to reliably answer questions on data that it wasn't trained on, without incurring the cost of tuning or retraining the model itself. 
# MAGIC
# MAGIC For the purposes of this accompanying lab, its not necessary to have a deep understanding of ML, AI or RAG. So we present a high level view of how it works. The pipeline consists of the following major components:
# MAGIC - a pre-existing **volume** (the input parameter to this notebook) containing documents to be processed
# MAGIC - a generated **table** containing text that has been **parsed** (extracted from the documents and included tables, figures, etc) and **chunked** (divided into manageable portions), as well as associated metadata
# MAGIC - a generated **vector search index**, which contains mathematical semantic mappings of the text chunks. The semantic nature of the mappings makes it easier to search for relevant text by meaning and not exact keywords. The operation of the index is supported by specialized compute resource known as a **vector search endpoint**.
# MAGIC - a generated **model** which incorporates the following subcomponents:
# MAGIC    - an **LLM** or generating text and answering prompts
# MAGIC    - a **retriever** which interacts with the vector search endpoint to identify text chunks that are relevant to the prompt given to the LLM
# MAGIC
# MAGIC   This model is made available to clients through a **model serving endpoint**. From there, it can be accessed through APIs or a direct URL.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 8px; margin: 16px 0;">
# MAGIC   <div style="display: flex; align-items: center; gap: 12px;">
# MAGIC     <span style="font-size: 24px;">ℹ️</span>
# MAGIC     <div>
# MAGIC       <ul>
# MAGIC         <li>All supporting data and AI objects (table, index, model) are created in the same schema as the volume referenced by the input volume path.</li>
# MAGIC         <li>This notebook only builds the pipeline, but does not pre-populate the index. Refer to the accompanying <i>Update Index</i> notebook to build/update the index so it reflect the contents of any files in the volume.
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC flowchart LR
# MAGIC subgraph VOL["Unity Catalog Volume"]
# MAGIC f1@{ shape: docs, label: "Files<br/>(PDFs, images, etc)"}
# MAGIC end
# MAGIC chunked@{ shape: div-rect, label: "Parsed and<br/>chunked text"}
# MAGIC subgraph vsearch["Vector Search Endpoint"]
# MAGIC index["Vector search<br>index"]
# MAGIC end
# MAGIC VOL --> chunked --> index
# MAGIC subgraph server["Serving Endpoint"]
# MAGIC model["Registered Model"]
# MAGIC end
# MAGIC index --> model
# MAGIC classDef plane fill:transparent,stroke:#DCE0E2,color:#1B3139,stroke-width:2px,stroke-dasharray:6 4
# MAGIC classDef solidBox fill:#F9F7F4,stroke:#303F47,color:#1B3139,stroke-width:1.5px
# MAGIC classDef data fill:#FFAB00,stroke:#1B3139,color:#0B2026,stroke-width:2px
# MAGIC classDef runtime fill:#2272B4,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
# MAGIC classDef client fill:#FF3621,stroke:#303F47,color:#FFFFFF,stroke-width:2px
# MAGIC class DP,SP plane
# MAGIC class VOL,vsearch,server solidBox
# MAGIC class f1,chunked,index data
# MAGIC class system_prompt,retriever,llm,model runtime
# MAGIC class app,users client
# MAGIC </div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 

# COMMAND ----------

# DBTITLE 1,declare parameters
dbutils.widgets.text(
    name='volume_path',
    defaultValue='',
    label='Volume'
)

dbutils.widgets.text(
    name='serving_endpoint_name',
    defaultValue='',
    label='Serving Endpoint Name'
)

dbutils.widgets.text(
    name='index_job_name',
    defaultValue='',
    label='Index Job Name'
)

# COMMAND ----------

# DBTITLE 1,validate configuration
from pathlib import Path

def validate_volume_path(volume_path: str):
    if not volume_path:
        raise ValueError("Volume path is not set.")

    p = Path(volume_path)

    if not p.is_absolute() or len(p.parts) < 5 or p.parts[1] != "Volumes":
        raise ValueError(f"{volume_path} is not a valid volume path")

    if not p.exists() or not p.is_dir():
        raise FileNotFoundError(
            f"Volume path does not exist or is not a folder: {volume_path}."
        )

    # return (catalog, schema, volume)
    return p.parts[2:5]

VOLUME_PATH = dbutils.widgets.get("volume_path")

CATALOG,SCHEMA,VOLUME = validate_volume_path(VOLUME_PATH)

serving_endpoint_name = dbutils.widgets.get("serving_endpoint_name")
index_job_name = dbutils.widgets.get("index_job_name")

# COMMAND ----------

# DBTITLE 1,set up variables
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

chunked_table = f"{CATALOG}.{SCHEMA}.docs_chunked"
idx = f"{CATALOG}.{SCHEMA}.docs_index"
model_name = f"{CATALOG}.{SCHEMA}.chatbot_model"
images_path = f"{VOLUME_PATH}/parsed_images"

if not serving_endpoint_name:
    serving_endpoint_name = model_name.replace(".", "_")

if not index_job_name:
    index_job_name = idx.replace(".", "_")

print(f"""
Configuration tracks:
  Catalog: {CATALOG}
  Schema: {SCHEMA}
  Volume: {VOLUME}
  Artifacts path: {VOLUME_PATH}
  Chunks table: {chunked_table}
  Index: {idx}
  Model: {model_name}
  Serving endpoint: {serving_endpoint_name}
""")

# COMMAND ----------

# DBTITLE 1,initialize chunked table
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {chunked_table} (
  path STRING,
  chunk STRING,
  id BIGINT)
USING delta
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true'
)
""")
print(f"✅ Chunked table {chunked_table} initialized")

# COMMAND ----------

# DBTITLE 1,create index
from databricks.sdk.errors import BadRequest, ResourceAlreadyExists
from databricks.sdk.service.vectorsearch import DeltaSyncVectorIndexSpecRequest, EmbeddingSourceColumn, PipelineType, VectorIndexType

# enumerate search endpoints
search_endpoints = [i.name for i in w.vector_search_endpoints.list_endpoints()]

# vector search endpoints allow up to 50 indexes; so we loop through them all until able
# to create index on one of them
for search_endpoint in search_endpoints:
    try:
        index_info = w.vector_search_indexes.create_index(
            name=idx,
            endpoint_name=search_endpoint,
            primary_key="id",
            index_type=VectorIndexType.DELTA_SYNC,
            delta_sync_index_spec=DeltaSyncVectorIndexSpecRequest(
                embedding_source_columns=[
                    EmbeddingSourceColumn(
                        name="chunk",
                        embedding_model_endpoint_name="databricks-gte-large-en"
                    )
                ],
                pipeline_type=PipelineType.TRIGGERED,
                source_table=chunked_table
            )
        )

        print(f"✅ Vector search index {idx} created on {search_endpoint}")
        break

    except BadRequest:
        # too many indexes on this endpoint; try next one
        pass
    
    except ResourceAlreadyExists:
        # already exists; do not attempt to replace or update
        break
else:
    # exhausted list of vector search endpoints
    raise Exception("No vector search endpoints available to create index")

# COMMAND ----------

# DBTITLE 1,create and serve model
from importlib_metadata import version
from mlflow.models import infer_signature
import mlflow
from mlflow import MlflowClient
from databricks.sdk.errors import ResourceDoesNotExist
from databricks.sdk.service.serving import EndpointCoreConfigInput, ServedEntityInput

mlflow.set_registry_uri("databricks-uc")

def model_exists(model_name: str) -> bool:
    try:
        MlflowClient().get_registered_model(model_name)
        return True
    except mlflow.exceptions.RestException:
        return False

def endpoint_exists(name):
    try:
        w.serving_endpoints.get(name)
        return True
    except ResourceDoesNotExist:
        return False

# create serving endpoint if it does not exist
if not endpoint_exists(serving_endpoint_name):

    # create model if it does not exist
    if not model_exists(model_name):

        model_config = {
            "vector_search_endpoint": search_endpoint,
            "vector_search_index": idx,
            "llm_endpoint": "databricks-claude-opus-4-5",
            "k": 4
        }

        input_example = {"input": "What kinds of questions can you answer?"}
        signature = infer_signature(
            input_example,
            {"answer": "I can answer questions related to the uploaded documents."}
        )

        with mlflow.start_run(run_name="chatbot_run") as run:

            model_info = mlflow.langchain.log_model(
                lc_model="rag_chain_model/chain.py",
                artifact_path="chain",
                registered_model_name=model_name,
                model_config=model_config,
                pip_requirements=[
                    f"mlflow[databricks]=={version('mlflow')}",
                    f"langchain=={version('langchain')}",
                    f"databricks-vectorsearch=={version('databricks-vectorsearch')}",
                    f"databricks-langchain=={version('databricks-langchain')}"
                ],
                input_example=input_example,
                signature=signature
            )

            print(f"✅ Created model {model_name}")

    w.serving_endpoints.create(
        name=serving_endpoint_name,
        config=EndpointCoreConfigInput(
            name=serving_endpoint_name,
            served_entities=[
                ServedEntityInput(
                    entity_name=model_name,
                    entity_version="1",
                    scale_to_zero_enabled=False,
                    workload_size="Small"
                )
            ]
        )
    )

    print(f"✅ Serving model {model_name} on {serving_endpoint_name}")


# COMMAND ----------

from importlib_metadata import version
from mlflow.models import infer_signature
import mlflow
from mlflow import MlflowClient
from databricks.sdk.errors import ResourceDoesNotExist
from databricks.sdk.service.serving import EndpointCoreConfigInput, ServedEntityInput

mlflow.set_registry_uri("databricks-uc")
search_endpoint = 'test_rag'
model_config = {
    "vector_search_endpoint": search_endpoint,
    "vector_search_index": idx,
    "llm_endpoint": "databricks-claude-opus-4-5",
    "k": 4
}

input_example = {"input": "What kinds of questions can you answer?"}
signature = infer_signature(
    input_example,
    {"answer": "I can answer questions related to the uploaded documents."}
)

with mlflow.start_run(run_name="chatbot_run") as run:

    model_info = mlflow.langchain.log_model(
        lc_model="rag_chain_model/chain.py",
        artifact_path="chain",
        registered_model_name=model_name,
        model_config=model_config,
        pip_requirements=[
            f"mlflow[databricks]=={version('mlflow')}",
            f"langchain=={version('langchain')}",
            f"databricks-vectorsearch=={version('databricks-vectorsearch')}",
            f"databricks-langchain=={version('databricks-langchain')}"
        ],
        input_example=input_example,
        signature=signature
    )

# COMMAND ----------

# DBTITLE 1,create update index job
import os
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import NotebookTask, Task

for job in w.jobs.list():
    if job.settings.name == index_job_name:
        print(f"✅ Job {index_job_name} already exists")
        break
else:
    w.jobs.create(
        name=index_job_name,
        tasks=[
            Task(
                task_key='index',
                notebook_task=NotebookTask(
                    notebook_path=f'{os.getcwd()}/Update Index',
                    base_parameters={
                        'volume_path': VOLUME_PATH
                    }
                )
            )
        ],
        description=f'Run this job to index documents in {VOLUME_PATH}'
    )
    print(f"✅ Created job {index_job_name}"
)