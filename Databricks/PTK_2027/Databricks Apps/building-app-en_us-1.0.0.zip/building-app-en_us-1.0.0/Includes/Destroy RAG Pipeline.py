# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC <div style="display:flex; align-items:center; padding:10px 18px; background:#F8F9FA; border-bottom:1px solid #E0E0E0; gap:10px;">
# MAGIC   <img src="https://cdn.simpleicons.org/databricks/FF3621" width="22" height="22"/>
# MAGIC   <div style="font-size:14px; color:#666; white-space:nowrap;">
# MAGIC     <span style="font-weight:600; color:#333;">Academy</span>
# MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
# MAGIC     <span style="font-weight:600; color:#eb1900;">Destroy RAG Pipeline</span>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Destroy RAG Pipeline
# MAGIC
# MAGIC This notebook removes resource related to the RAG pipeline construction:
# MAGIC - chunks table
# MAGIC - index
# MAGIC - model
# MAGIC - model serving endpoint
# MAGIC
# MAGIC Any pre-existing elements (the volume, the vector search endpoints) are left untouched.

# COMMAND ----------

# DBTITLE 1,declare parameters
dbutils.widgets.text(
    name='volume_path',
    defaultValue='',
    label='Volume'
)

dbutils.widgets.text(
    name='serving_endpoint_name',
    defaultValue='',
    label='Serving Endpoint Name'
)

dbutils.widgets.text(
    name='index_job_name',
    defaultValue='',
    label='Index Job Name'
)

# COMMAND ----------

# DBTITLE 1,validate configuration
from pathlib import Path

def validate_volume_path(volume_path: str):
    if not volume_path:
        raise ValueError("Volume path is not set.")

    p = Path(volume_path)

    if not p.is_absolute() or len(p.parts) < 5 or p.parts[1] != "Volumes":
        raise ValueError(f"{volume_path} is not a valid volume path")

    if not p.exists() or not p.is_dir():
        raise FileNotFoundError(
            f"Volume path does not exist or is not a folder: {volume_path}."
        )

    # return (catalog, schema, volume)
    return p.parts[2:5]

VOLUME_PATH = dbutils.widgets.get("volume_path")

CATALOG,SCHEMA,VOLUME = validate_volume_path(VOLUME_PATH)

serving_endpoint_name = dbutils.widgets.get("serving_endpoint_name")
index_job_name = dbutils.widgets.get("index_job_name")

# COMMAND ----------

# DBTITLE 1,set up variables
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

chunked_table = f"{CATALOG}.{SCHEMA}.docs_chunked"
idx = f"{CATALOG}.{SCHEMA}.docs_index"
model_name = f"{CATALOG}.{SCHEMA}.chatbot_model"
images_path = f"{VOLUME_PATH}/parsed_images"

if not serving_endpoint_name:
    serving_endpoint_name = model_name.replace(".", "_")

if not index_job_name:
    index_job_name = idx.replace(".", "_")

print(f"""
Configuration tracks:
  Catalog: {CATALOG}
  Schema: {SCHEMA}
  Volume: {VOLUME}
  Artifacts path: {VOLUME_PATH}
  Chunks table: {chunked_table}
  Index: {idx}
  Model: {model_name}
  Serving endpoint: {serving_endpoint_name}
""")

# COMMAND ----------

# DBTITLE 1,delete model serving endpoint
from databricks.sdk.errors import ResourceDoesNotExist

try:
    w.serving_endpoints.delete(name=serving_endpoint_name)
except ResourceDoesNotExist:
    pass

# COMMAND ----------

# DBTITLE 1,delete model
from mlflow import MlflowClient
from mlflow.exceptions import RestException
client = MlflowClient()

try:
    client.delete_registered_model(name=model_name)
except RestException:
    pass

# COMMAND ----------

# DBTITLE 1,delete index
from databricks.sdk.errors import ResourceDoesNotExist

try:
    w.vector_search_indexes.delete_index(index_name=idx)
except ResourceDoesNotExist:
    pass

# COMMAND ----------

# DBTITLE 1,drop chunked table
_ = spark.sql(f"DROP TABLE IF EXISTS {chunked_table}")

# COMMAND ----------

# DBTITLE 1,delete parsed images
import shutil
shutil.rmtree(images_path, ignore_errors=True)

# COMMAND ----------

# DBTITLE 1,delete index job
for job in w.jobs.list():
    if job.settings.name == index_job_name:
        w.jobs.delete(job_id=job.job_id)