# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC <div style="display:flex; align-items:center; padding:10px 18px; background:#F8F9FA; border-bottom:1px solid #E0E0E0; gap:10px;">
# MAGIC   <img src="https://cdn.simpleicons.org/databricks/FF3621" width="22" height="22"/>
# MAGIC   <div style="font-size:14px; color:#666; white-space:nowrap;">
# MAGIC     <span style="font-weight:600; color:#333;">Academy</span>
# MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
# MAGIC     <span style="font-weight:600; color:#eb1900;">Update Index</span>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# DBTITLE 1,declare parameters
# Create and display a text widget
dbutils.widgets.text(
    name='volume_path',
    defaultValue='',
    label='Volume'
)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Update Index
# MAGIC
# MAGIC This notebook updates the index of a RAG pipeline (that was built using the accompanying <i>Build RAG Pipeline</i> notebook). 
# MAGIC
# MAGIC Essentially, it:
# MAGIC - Parses all supported documents in the volume (the input parameter to this notebook)
# MAGIC - Chunks results and stores them in a Delta table
# MAGIC - triggers the Lakeflow Spark Declarative Pipeline reponsible for recomputing the **embeddings** (that is, the mathematical representations of the text chunks)
# MAGIC
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC flowchart LR
# MAGIC subgraph VOL["Unity Catalog Volume"]
# MAGIC f1@{ shape: docs, label: "Files<br/>(PDFs, images, etc)"}
# MAGIC end
# MAGIC chunked@{ shape: div-rect, label: "Parsed and<br/>chunked text"}
# MAGIC subgraph vsearch["Vector Search Endpoint"]
# MAGIC index["Vector search<br>index"]
# MAGIC end
# MAGIC VOL -->|"parse and chunk"| chunked -->|"SDP"| index
# MAGIC classDef plane fill:transparent,stroke:#DCE0E2,color:#1B3139,stroke-width:2px,stroke-dasharray:6 4
# MAGIC classDef solidBox fill:#F9F7F4,stroke:#303F47,color:#1B3139,stroke-width:1.5px
# MAGIC classDef data fill:#FFAB00,stroke:#1B3139,color:#0B2026,stroke-width:2px
# MAGIC classDef runtime fill:#2272B4,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
# MAGIC classDef client fill:#FF3621,stroke:#303F47,color:#FFFFFF,stroke-width:2px
# MAGIC class DP,SP plane
# MAGIC class VOL,vsearch,server solidBox
# MAGIC class f1,chunked,index data
# MAGIC class system_prompt,retriever,llm,model runtime
# MAGIC class app,users client
# MAGIC </div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 

# COMMAND ----------

# DBTITLE 1,validate configuration
from pathlib import Path

def validate_volume_path(volume_path: str):
    if not volume_path:
        raise ValueError("Volume path is not set.")

    p = Path(volume_path)

    if not p.is_absolute() or len(p.parts) < 5 or p.parts[1] != "Volumes":
        raise ValueError(f"{volume_path} is not a valid volume path")

    if not p.exists() or not p.is_dir():
        raise FileNotFoundError(
            f"Volume path does not exist or is not a folder: {volume_path}."
        )

    # return (catalog, schenma, volume)
    return p.parts[2:5]

VOLUME_PATH = dbutils.widgets.get("volume_path")

CATALOG,SCHEMA,VOLUME = validate_volume_path(VOLUME_PATH)

print(f"""
Configuration tracks:
  Artifacts path: {VOLUME_PATH}
  Catalog: {CATALOG}
  Schema: {SCHEMA}
  Volume: {VOLUME}
""")

# COMMAND ----------

# DBTITLE 1,set up variables
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

chunked_table = f"{CATALOG}.{SCHEMA}.docs_chunked"
idx = f"{CATALOG}.{SCHEMA}.docs_index"
images_path = f"{VOLUME_PATH}/parsed_images"

# COMMAND ----------

# DBTITLE 1,delete images_path
import shutil
shutil.rmtree(images_path, ignore_errors=True)

# COMMAND ----------

# DBTITLE 1,parse files in volume
from pyspark.sql.functions import expr

# Read all files from the documents volume
docs_df = spark.read.format("binaryFile").load(VOLUME_PATH)

# Parse each document using ai_parse_document (use expr for SQL function)
parsed_df = docs_df.withColumn("parsed_content", 
                               expr(f"""ai_parse_document(content, map(
                                    "version", "2.0",
                                    "imageOutputPath", "{images_path}"
                                   ))""")
                              )
# Drop binary content
parsed_df = parsed_df.drop("content")

# COMMAND ----------

# DBTITLE 1,flatten parsed text into plain text
from pyspark.sql import functions as F

import json
from typing import Any, Optional

def _page_id_from_bbox(bbox: Any) -> Optional[int]:
    """
    bbox can be a list[dict], a dict, or None. Return bbox.page_id if present.
    Kept intentionally simple.
    """
    if not bbox:
        return None
    if isinstance(bbox, list) and bbox:
        first = bbox[0] or {}
        return first.get("page_id")
    if isinstance(bbox, dict):
        return bbox.get("page_id")
    return None

def extract_contents_from_json(json_str: str) -> str:
    """
    - Concatenate element 'content' (fallback to 'description' if missing).
    - Insert '== page ==' when page_id changes.
    - Insert an extra newline after elements whose type != 'text'.
    - Return an error string on failure (for easy debugging in DataFrame).
    """
    try:
        doc = json.loads(json_str) if isinstance(json_str, str) else json_str
        if not isinstance(doc, dict):
            return ""

        # Support both {"document":{"elements":[...]}} and {"elements":[...]}
        document = doc.get("document", doc)
        elements = document.get("elements", []) if isinstance(document, dict) else []
        if not isinstance(elements, list):
            return ""

        out_lines = []
        current_page = None

        for el in elements:
            if not isinstance(el, dict):
                continue

            # Page divider on change
            pid = _page_id_from_bbox(el.get("bbox"))
            if pid is not None and current_page is not None and pid != current_page:
                out_lines.append("")
                out_lines.append("== page ==")
                out_lines.append("")
            if pid is not None:
                current_page = pid

            # Content (fallback to description)
            c = el.get("content")
            if not (isinstance(c, str) and c.strip()):
                c = el.get("description")
            if isinstance(c, str) and c.strip():
                out_lines.append(c)

                # Extra newline after non-text elements
                t = (el.get("type") or "").lower()
                if t != "text":
                    out_lines.append("")  # produces a blank line after joining

        return "\n".join(out_lines)

    except Exception as e:
        return f"Error: {str(e)}"

# A small factory to create a PySpark UDF that uses the function above.
def extract_contents_udf():
    from pyspark.sql.types import StringType
    from pyspark.sql.functions import udf
    @udf(StringType())
    def _udf(json_str):
        try:
            return extract_contents_from_json(json_str)
        except Exception as e:
            return f"Error: {str(e)}"
    return _udf

# Convert VARIANT/struct/map to a JSON string first (avoids VariantVal issues)
safe_json_col = F.coalesce(
    F.to_json(F.col("parsed_content")),
    F.col("parsed_content").cast("string")
)

# Apply the UDF
plain_text_df = parsed_df.withColumn(
    "plain_text",
    extract_contents_udf()(safe_json_col)
)

# COMMAND ----------

# DBTITLE 1,chunk text
from langchain_text_splitters import RecursiveCharacterTextSplitter
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql import functions as F
import pandas as pd

# Set chunking parameters: chunk_size controls the max length of each chunk, and chunk_overlap allows for overlapping text between chunks to improve retrieval quality.
CHUNK_SIZE = 2000
CHUNK_OVERLAP = 200

# Build the text splitter with preferred separators.
# This splitter will break the text at page markers or other natural boundaries, preserving document structure where possible.
splitter = RecursiveCharacterTextSplitter(
    chunk_size=CHUNK_SIZE,
    chunk_overlap=CHUNK_OVERLAP,
    separators=["\n== page ==\n", "== page ==", "\n\n", "\n", " ", ""]
)

# Define the output schema for the chunked DataFrame.
# Each row will contain the document path and a single text chunk.
schema = StructType([
    StructField("path", StringType(), True),
    StructField("chunk", StringType(), True),
])

def split_rows(iterator):
    """
    mapInPandas function: input pdfs with columns [path, plain_text],
    output rows [path, chunk].
    This function splits each document's text into chunks and yields them for DataFrame construction.
    """
    for pdf in iterator:
        out = []
        for _, row in pdf.iterrows():
            path = row["path"]
            text = row["plain_text"]
            if isinstance(text, str) and text.strip():
                for c in splitter.split_text(text):
                    if c and c.strip():
                        out.append((path, c))
        yield pd.DataFrame(out, columns=["path", "chunk"])

# Apply the splitter to the plain text DataFrame.
# This step transforms each document into multiple chunked rows for efficient downstream retrieval and embedding.
df_chunks = (
    plain_text_df
    .select("path", "plain_text")
    .mapInPandas(split_rows, schema=schema)
).withColumn("id", F.monotonically_increasing_id())

# Display the resulting chunked DataFrame for inspection.
display(df_chunks)

# Save the chunked data with id to the Delta table for retrieval and embedding
df_chunks.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(chunked_table)

# CDF is required to index
spark.sql(f"ALTER TABLE {chunked_table} SET tblproperties (delta.enableChangeDataFeed = true)");

print(f"✅ Chunked results saved to Delta table: {chunked_table}")

# COMMAND ----------

# DBTITLE 1,update index
from databricks.sdk.errors import ResourceConflict

index_info = w.vector_search_indexes.get_index(index_name=idx)
pipeline_id = index_info.delta_sync_index_spec.pipeline_id
try:
    w.pipelines.start_update(pipeline_id=pipeline_id)
    print(f"✅ Triggered refresh for pipeline {pipeline_id} to update embeddings")
except ResourceConflict:
    print(f"✅ Refresh for pipeline {pipeline_id} is already in progress")

# wait for pipeline update to complete
w.pipelines.wait_get_pipeline_idle(pipeline_id=pipeline_id)