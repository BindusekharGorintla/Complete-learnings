# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

my_catalog = build_user_catalog(catalog_forced=None)  ## <-- Force the usage of a catalog if you can't create one.
spark.sql(f'USE CATALOG {my_catalog}')
my_schema = 'apps'
spark.sql(f'CREATE SCHEMA IF NOT EXISTS {my_schema}')
_ = spark.sql(f'USE SCHEMA {my_schema}')
my_volume = 'concurrency'
spark.sql(f'CREATE VOLUME IF NOT EXISTS {my_volume}')
my_file = f'/Volumes/{my_catalog}/{my_schema}/{my_volume}/state.txt'

# COMMAND ----------

display_config_values(
    [
        ('Volume', f'{my_catalog}.{my_schema}.{my_volume}'),
    ]
)

# COMMAND ----------

import io
import time
import uuid
from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import AlreadyExists, NotFound

class VolumeFileLock:
    """
    Simple file-based lock using Databricks Files API.
    Uses an atomic create (overwrite=False) to create lock file.
    """
    def __init__(self,
                 lock_path: str,
                 wsclient: WorkspaceClient=None,
                 poll_interval: float = 1.0,
                 timeout: float = 15.0):

        self.lock_path = lock_path
        self.w = wsclient or WorkspaceClient()
        self.poll_interval = poll_interval
        self.timeout = timeout
        self.token = str(uuid.uuid4())
        self.acquired = False

    def acquire(self):
        deadline = time.time() + self.timeout
        while True:
            try:
                # Attempt to create the lock file without overwriting.
                # If it already exists, this should fail.
                self.w.files.upload(
                    self.lock_path,
                    io.BytesIO(self.token.encode("utf-8")),
                    overwrite=False
                )
                print("INFO: lock acquired")
                self.acquired = True
                return
            except AlreadyExists:
                # Assume lock is held by someone else; back off and retry.
                print("INFO: waiting for lock")
                if time.time() > deadline:
                    raise TimeoutError(
                        f"Could not acquire lock at {self.lock_path} within {self.timeout} seconds"
                    )
                time.sleep(self.poll_interval)

    def release(self):
        if self.acquired:
            try:
                # Optional: verify token before delete in a more robust impl
                self.w.files.delete(self.lock_path)
            except NotFound:
                pass
            finally:
                self.acquired = False

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release()