from langchain_classic.chains import create_retrieval_chain
from langchain_classic.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
from databricks_langchain import ChatDatabricks, DatabricksVectorSearch
import mlflow
from mlflow.models import ModelConfig

def build_chain(model_config: dict):

    retriever = DatabricksVectorSearch(
        endpoint=model_config["vector_search_endpoint"],
        index_name=model_config["vector_search_index"]
    ).as_retriever(search_kwargs={"k": model_config.get("k", 4)})

    llm = ChatDatabricks(endpoint=model_config["llm_endpoint"], temperature=0.1, max_tokens=512)

    prompt = ChatPromptTemplate.from_messages([
        ("system", """You are a knowledge assistant that answers questions strictly based on the provided context. Use only the supplied context to answer the question. Do not rely on outside knowledge. If the answer cannot be found in the context, say that you don't have enough information in the provided documents to answer. Do not guess or fabricate details. Keep responses concise and structured. Use Markdown formatting for headings and bullet points when helpful. Always include references to the source document name and page number if available. If the question is unrelated to the provided documents, politely decline to answer. Provide all responses in English.
         
        Context:
        {context}"""),
        ("user", "{input}")
    ])

    combine = create_stuff_documents_chain(llm, prompt)
    return create_retrieval_chain(retriever, combine)

config = ModelConfig()
chain = build_chain(config.to_dict())
mlflow.models.set_model(chain)