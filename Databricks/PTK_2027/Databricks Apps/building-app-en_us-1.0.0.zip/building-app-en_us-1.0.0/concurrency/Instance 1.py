# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC <div style="display:flex; align-items:center; padding:10px 18px; background:#F8F9FA; border-bottom:1px solid #E0E0E0; gap:10px;">
# MAGIC   <img src="https://cdn.simpleicons.org/databricks/FF3621" width="22" height="22"/>
# MAGIC   <div style="font-size:14px; color:#666; white-space:nowrap;">
# MAGIC     <span style="font-weight:600; color:#333;">Academy</span>
# MAGIC     <span style="margin:0 10px; color:#bbb;">|</span>
# MAGIC     <span style="font-weight:600; color:#eb1900;">Concurrency Demo</span>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Instructions for Use
# MAGIC
# MAGIC ### Preparation
# MAGIC
# MAGIC 1. Open this notebook and any other instances you find in this folder in separate tabs.
# MAGIC 1. For each notebook:
# MAGIC    - Run to completion by clicking **Run all**
# MAGIC    - Enter some text in the **Record to add** at the top of each notebook (it doesn't matter what you enter)
# MAGIC
# MAGIC ### Running the demo
# MAGIC
# MAGIC 1. With preparation complete, run the last cell of each notebook (labelled `unsafe file update`) in close succession (within 10 second of each other).
# MAGIC 1. When done and all notebooks have completed, navigate to the volume specified below in [Catalog Explorer](/explore/data).
# MAGIC 1. View the contents of the `state.txt` file. How does it compare to what you'd expect.
# MAGIC 1. Experiment with different timings, if desired.

# COMMAND ----------

# DBTITLE 1,common setup
# MAGIC %run ../Includes/Classroom-Setup-Concurrency

# COMMAND ----------

# DBTITLE 1,display text input
from databricks.sdk import WorkspaceClient
from databricks.sdk.errors import NotFound
w = WorkspaceClient()

dbutils.widgets.text(
    name='record',
    defaultValue='',
    label='Record to add'
)

# COMMAND ----------

# DBTITLE 1,get input
record = dbutils.widgets.get('record')

# COMMAND ----------

# DBTITLE 1,unsafe file update
import time
import io

if record:
    try:
        resp = w.files.download(my_file)
        with resp.contents as f:
            original_bytes = f.read()
        original_text = original_bytes.decode("utf-8")
    except NotFound:
        original_text = ""

    notebook_name = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get().rsplit('/', 1)[-1]
    new_text = f"{original_text}{notebook_name}: {record}\n"

    print("Processing...")
    time.sleep(10)

    new_bytes = new_text.encode("utf-8")
    w.files.upload(
        my_file,
        io.BytesIO(new_bytes),
        overwrite=True
    )

    print("Update complete")