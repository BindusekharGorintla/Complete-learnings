import os
import uuid
from datetime import datetime
import streamlit as st
import pandas as pd
import time
from databricks.sdk import WorkspaceClient
from dotenv import load_dotenv

load_dotenv()
st.set_page_config(page_title="Enterprise Knowledge Assistant", layout="wide")

# --- Config ---
VOLUME_PATH = os.getenv("DATABRICKS_VOLUME")
if not VOLUME_PATH:
    raise ValueError("Missing env var DATABRICKS_VOLUME (expected /Volumes/<catalog>/<schema>/<volume>)")

parts = VOLUME_PATH.strip("/").split("/")
if len(parts) < 4 or parts[0] != "Volumes":
    raise ValueError(f"DATABRICKS_VOLUME must look like /Volumes/<catalog>/<schema>/<volume>. Got: {VOLUME_PATH}")

CATALOG, SCHEMA, VOLUME = parts[1], parts[2], parts[3]

SERVING_ENDPOINT = os.getenv("DATABRICKS_SERVING_ENDPOINT")
if not SERVING_ENDPOINT:
    raise ValueError("Missing env var DATABRICKS_SERVING_ENDPOINT")

INDEX_JOB_ID = os.getenv("DATABRICKS_JOB")
if not INDEX_JOB_ID:
    raise ValueError("Missing env var DATABRICKS_JOB (the job id for Update Index)")

host = os.getenv("DATABRICKS_HOST", "").rstrip("/")
if not host:
    raise ValueError("Missing env var DATABRICKS_HOST")
if not host.startswith("http"):
    host = "https://" + host

ENDPOINT_URL = f"{host}/serving-endpoints/{SERVING_ENDPOINT}/invocations"
LOCAL_TZ = os.getenv("LOCAL_TZ")  # optional

w = WorkspaceClient()

def get_active_index_run(job_id: str):
    # Returns latest active run (if any)
    runs = [ r for r in w.jobs.list_runs(job_id=job_id, active_only=True, limit=1)]
    return runs[0] if runs else None

def get_run_state(run_id: str) -> str:
    r = w.jobs.get_run(run_id=run_id)
    s = r.status
    # life is pain: these fields vary by SDK version; keep it defensive
    parts = []
    parts.append(s.state.value)
    if s.termination_details:
        parts.append(s.termination_details.code.value)
        parts.append(s.termination_details.message)

    return " / ".join([p for p in parts if p]) or "UNKNOWN"

# ---- Size helpers ----
KB = 1024
MB = 1024 * KB
GB = 1024 * MB
MAX_UPLOAD_SIZE = int(os.getenv("MAX_UPLOAD_SIZE_BYTES", 25 * MB))

def sizeof_fmt(num):
    if num is None:
        return ""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if num < 1024:
            return f"{num:.0f} {unit}" if unit == "B" else f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} PB"

def format_mtime(mtime):
    if mtime is None:
        return ""
    # SDK list_directory_contents uses epoch ms
    dt = datetime.fromtimestamp(float(mtime) / 1000.0)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

# ---- Volume helpers ----
def list_volume_files(root: str):
    items = w.files.list_directory_contents(directory_path=root)
    out = []
    for item in items:
        if getattr(item, "is_directory", False):
            continue
        out.append({
            "path": item.path,
            "name": item.name,
            "size": item.file_size,
            "mtime": item.last_modified
        })
    return out

def upload_file_to_volume(uploaded_file, root: str):
    # Save to root (simple for lab)
    safe_name = uploaded_file.name.replace("/", "_")
    dest_path = f"{root}/{safe_name}"

    # SDK expects bytes/str content
    w.files.upload(dest_path, uploaded_file, overwrite=True)
    return dest_path

def delete_file(path: str):
    w.files.delete(path)

# ---- Model call ----
def invoke_model(text: str):
    return w.api_client.do(
        method="POST",
        url=f"{w.config.host}/serving-endpoints/{SERVING_ENDPOINT}/invocations",
        body={"input": text},
    )

# ---- Simple busy flags ----
if "busy_upload" not in st.session_state:
    st.session_state.busy_upload = False
if "busy_delete" not in st.session_state:
    st.session_state.busy_delete = False
if "busy_chat" not in st.session_state:
    st.session_state.busy_chat = False

st.title("Enterprise Knowledge Assistant")

# 1-2-3 layout
col_artifacts, col_index, col_chat = st.columns([1.25, 0.95, 1.8], gap="large")

# ---------------------------
# 1) ARTIFACTS COLUMN
# ---------------------------
with col_artifacts:
    st.subheader("Artifacts")

    files = list_volume_files(VOLUME_PATH)
    df = pd.DataFrame(files)

    if df.empty:
        st.info("No artifacts found.")
        selected_path = None
        selected_name = None
    else:
        df_view = pd.DataFrame({
            "Name": df["name"],
            "Size": df["size"].apply(sizeof_fmt),
            "Modified": df["mtime"].apply(format_mtime),
        })
        st.dataframe(df_view.sort_values("Modified", ascending=False),
                     use_container_width=True, hide_index=True)

        # select by path so delete works even if later you add subfolders
        name_to_path = dict(zip(df["name"], df["path"]))
        selected_name = st.selectbox("Select an artifact", df["name"].tolist())
        selected_path = name_to_path.get(selected_name)

    st.caption(f"Volume: {VOLUME_PATH}")

    st.divider()
    st.markdown("**Upload**")
    uploaded = st.file_uploader("Upload artifact", type=None, label_visibility="collapsed")

    if uploaded is not None:
        col_u1, col_u2 = st.columns([1, 1])
        with col_u1:
            st.caption(f"{uploaded.name} ({sizeof_fmt(uploaded.size)})")
        with col_u2:
            if st.button("Save upload", use_container_width=True, disabled=st.session_state.busy_upload):
                st.session_state.busy_upload = True
                try:
                    with st.spinner("Uploading to Volume..."):
                        dest = upload_file_to_volume(uploaded, VOLUME_PATH)
                    st.success(f"Uploaded to: {dest.split('/')[-1]}")
                except Exception as e:
                    st.error(f"Upload failed: {e}")
                finally:
                    st.session_state.busy_upload = False
                st.rerun()

    st.divider()
    st.markdown("**Delete**")
    if selected_path:
        if st.button(f"Delete {selected_name}", use_container_width=True, disabled=st.session_state.busy_delete):
            st.session_state.busy_delete = True
            try:
                with st.spinner("Deleting..."):
                    delete_file(selected_path)
                st.success(f"Deleted: {selected_name}")
            except Exception as e:
                st.error(f"Delete failed: {e}")
            finally:
                st.session_state.busy_delete = False
            st.rerun()
    else:
        st.caption("Select an artifact to enable delete.")

# ---------------------------
# 2) INDEX COLUMN
# ---------------------------
with col_index:
    st.subheader("Index")

    # Session state for job tracking
    if "index_run_id" not in st.session_state:
        st.session_state.index_run_id = None
    if "index_idempotency_token" not in st.session_state:
        st.session_state.index_idempotency_token = None
    if "index_triggered_at" not in st.session_state:
        st.session_state.index_triggered_at = None

    # 1) Use job state as the "lock"
    active = get_active_index_run(INDEX_JOB_ID)
    index_running = active is not None

    if index_running:
        st.info(f"Rebuild running (run_id={active.run_id}).")
        st.session_state.index_run_id = active.run_id

    # 2) Trigger rebuild (idempotent to double-click / reruns)
    if st.button("Rebuild index", use_container_width=True, disabled=index_running):
        # create token ONCE per user click
        token = st.session_state.index_idempotency_token
        if not token:
            token = str(uuid.uuid4())
            st.session_state.index_idempotency_token = token
            st.session_state.index_triggered_at = time.time()

        try:
            with st.spinner("Triggering index rebuild job..."):
                run = w.jobs.run_now(
                    job_id=INDEX_JOB_ID,
                    idempotency_token=token,
                    notebook_params={"VOLUME_PATH": VOLUME_PATH},
                )
            st.session_state.index_run_id = run.run_id
            st.success(f"Triggered rebuild (run_id={run.run_id}).")

            # once we have a run_id, we can clear token so next click creates a new run
            st.session_state.index_idempotency_token = None
            st.session_state.index_triggered_at = None

        except Exception as e:
            st.error(f"Failed to trigger job: {e}")

        st.rerun()

    st.divider()
    st.markdown("**Index status**")

    run_id = st.session_state.index_run_id
    if run_id:
        try:
            state = get_run_state(run_id)
            st.write(f"Run: {run_id}")
            st.write(f"Status: {state}")
        except Exception as e:
            st.warning(f"Could not read run status: {e}")

        # optional manual refresh (keeps it simple)
        if st.button("Refresh status", use_container_width=True):
            st.rerun()
    else:
        st.caption("No rebuild run yet.")

# ---------------------------
# 3) CHAT COLUMN
# ---------------------------
with col_chat:
    st.subheader("Chat")

    if "chat" not in st.session_state:
        st.session_state.chat = []

    history = st.container(height=520, border=True)
    with history:
        for msg in st.session_state.chat:
            with st.chat_message(msg["role"]):
                st.markdown(msg["content"])

    def handle_chat_submit():
        prompt = st.session_state.chat_input.strip()
        if not prompt or st.session_state.busy_chat:
            return

        st.session_state.busy_chat = True

        # Store user message
        st.session_state.chat.append({"role": "user", "content": prompt})

        try:
            with st.spinner("Thinking..."):
                resp = invoke_model(prompt)
            answer = resp[0].get("answer") if isinstance(resp, list) and resp else str(resp)
        except Exception as e:
            answer = f"⚠️ Model call failed: {e}"
        finally:
            st.session_state.busy_chat = False

        st.session_state.chat.append({"role": "assistant", "content": str(answer)})

        # Clear input safely
        st.session_state.chat_input = ""

    st.text_input(
        "Ask a question…",
        placeholder="Ask a question…",
        key="chat_input",
        label_visibility="collapsed",
        on_change=handle_chat_submit,
        disabled=st.session_state.busy_chat
    )