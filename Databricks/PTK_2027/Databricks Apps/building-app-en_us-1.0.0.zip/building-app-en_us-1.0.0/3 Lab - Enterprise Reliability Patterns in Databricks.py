# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](./Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab - Enterprise Reliability Patterns in Databricks
# MAGIC
# MAGIC Modern enterprise applications must handle more than simple request/response interactions. They must:
# MAGIC - coordinate long-running work
# MAGIC - manage concurrency
# MAGIC - enforce security boundaries
# MAGIC - track state durably
# MAGIC - remain observable under failure conditions
# MAGIC
# MAGIC In this lab, we examine how these common enterprise concerns translate into Databricks-native architectural patterns. Using a reference RAG-based application as our working example, we explore how to design applications that behave reliably under real-world conditions — while leveraging Workflows, Unity Catalog, Volumes, and Model Serving Endpoints as core building blocks.
# MAGIC
# MAGIC The goal is not just to deploy a Databricks App, but to understand the architectural responsibilities that make it enterprise-ready.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lab, you will be able to:
# MAGIC - Map common web application challenges to Databricks-native solutions
# MAGIC - Explain how a Databricks App should coordinate asynchronous job execution while maintaining durable state and safe retry behavior
# MAGIC - Evaluate the architectural responsibilities of an enterprise-grade Databricks App beyond simple UI implementation

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ## A. Concurrency
# MAGIC
# MAGIC Simply put, concurrency is when multiple things try to happen at the same time. It's not a new problem, and it's not unique to web apps or databases. In fact, concurrency is a good thing, since it enables a system to generate more overall throughput. While a system waits for user input or data from an upstream source, it can perform some other productive work. But it can become dangerous when two tasks try to access the same resource in the same way at the same time.
# MAGIC
# MAGIC When running at scale, web apps will:
# MAGIC - have many instances serving many requests at the same time
# MAGIC - have users clicking the same button at the same time
# MAGIC - have users who accidentally double-click
# MAGIC - be connected to browsers that retry the last request before it completes

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A1. Core Problem
# MAGIC
# MAGIC If your app operate on a common resource using operations that are not:
# MAGIC - atomic
# MAGIC - guarded by a durable state
# MAGIC
# MAGIC That's when problems can arise.
# MAGIC
# MAGIC Consider this simple and common scenario: since web apps are stateless, you maintain state in a file (stored in a volume). Therefore, you'll need to be able to read and update the file.
# MAGIC
# MAGIC Currently, the only way to update files in a Databricks app is to:
# MAGIC 1. Read file into memory using the SDK
# MAGIC 1. Make changes in memory
# MAGIC 1. Write file back out using the SDK
# MAGIC
# MAGIC The issue is, these operations are not **atomic**. Things can happen before the first and last step. Another instance of your app could be doing the same thing at the same time, resulting in lost updates. This is illustrated below:
# MAGIC
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC ---
# MAGIC config:
# MAGIC   theme: neutral
# MAGIC ---
# MAGIC sequenceDiagram
# MAGIC     participant A as App Instance 1
# MAGIC     participant B as App Instance 2
# MAGIC     participant V as File
# MAGIC     Note over V: Contents: F0
# MAGIC     V->>A: Read file into memory
# MAGIC     V->>B: Read file into memory
# MAGIC     Note over A,B: Same copy (F0) in memory
# MAGIC     Note over A: Append R1
# MAGIC     Note over B: Append R2
# MAGIC     A->>V: Write updated file
# MAGIC     Note over V: Contents: F0+R1
# MAGIC     B->>V: Write updated file
# MAGIC     Note over V: Contents: F0+R2
# MAGIC </div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### A1.1 Demonstrating the Issue
# MAGIC
# MAGIC This issue can be demonstrated using an included demo which implements the pattern highlighted above.
# MAGIC
# MAGIC Use the following links (each opens in a new tab) to open the "instances" and follow the instructions in the notebook.
# MAGIC - [Instance 1]($./concurrency/Instance 1)
# MAGIC - [Instance 2]($./concurrency/Instance 2)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A2. Mutual Exclusion as a Solution
# MAGIC
# MAGIC When dealing with non-atomic operations, **mutual exclusion** (mutex) is a pattern that can be employed to protect the critical sections of your code (that is, the sections that operate on shared resources).
# MAGIC
# MAGIC A typical example of a mutex primitive is a **lock**. A lock is a simple binary structure that helps make concurrent execution safe. Here's how it works:
# MAGIC 1. Before you begin accessing the shared resource (in the example from above, that would be reading the file into memory) you attempt to **acquire** the lock.
# MAGIC    - If you acquire the lock, you're free to enter the critical section; that is, reading and updating the file.
# MAGIC    - If you do not acquire the lock, you can either give up and surface and error, or attempt to wait for a bit and try again. Waiting for a little while is acceptable in the context of a web app, if you design your code to not hold the lock for long.
# MAGIC 1. As soon as you're done, release the lock as soon as possible to mitigate contention.
# MAGIC
# MAGIC The figure below illustrates how the scene changes with locking in place:
# MAGIC
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC ---
# MAGIC config:
# MAGIC   theme: neutral
# MAGIC ---
# MAGIC sequenceDiagram
# MAGIC     participant A as App Instance 1
# MAGIC     participant B as App Instance 2
# MAGIC     participant V as File
# MAGIC     Note over V: Contents: F0
# MAGIC     A->>A: Acquire lock
# MAGIC     V->>A: Read file into memory
# MAGIC     B-->B: Try acquire lock
# MAGIC     Note over A: F0 in memory
# MAGIC     Note over A: Append R1
# MAGIC     A->>V: Write updated file
# MAGIC     Note over V: Contents: F0+R1
# MAGIC     A-->B: Release lock
# MAGIC     B-->B: Lock acquired
# MAGIC     V->>B: Read file into memory
# MAGIC     Note over B: F0+R1 in memory
# MAGIC     Note over B: Append R2
# MAGIC     B->>V: Write updated file
# MAGIC     Note over V: Contents: F0+R1+R2
# MAGIC </div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### A2.1 Implementing a Lock
# MAGIC
# MAGIC There are many locking implementations in existence to suit a variety of contexts and operating environments.
# MAGIC
# MAGIC If you want to create your own to avoid external dependencies, you need the following basic ingredients:
# MAGIC - a durable store to "remember" the lock (across instances and requests (for example, a table or a file)
# MAGIC - an atomic "acquire" operation
# MAGIC
# MAGIC In the context of Databricks, both of these can be met with either a table (Delta or Lakebase) or a file in a volume.
# MAGIC
# MAGIC For example, if we choose to use the file-based approach (which in this context makes sense since our code is already working with files) we can:
# MAGIC - Take advantage of the [files upload endpoint](https://databricks-sdk-py.readthedocs.io/en/latest/workspace/files/files.html#databricks.sdk.service.files.FilesExt.upload) (with `overwrite` set to `False`) to "acquire" the lock. This call will either succeed if the file doesn't exist, or fail if it does. The binary, atomic nature of this API makes it well-suited to implement a simple lock.
# MAGIC - Use the [delete endpoint](https://databricks-sdk-py.readthedocs.io/en/latest/workspace/files/files.html#databricks.sdk.service.files.FilesExt.delete) to "release" the lock.
# MAGIC
# MAGIC <pre><code class="language-python">w = WorkspaceClient()
# MAGIC ...
# MAGIC     # "acquire" lock
# MAGIC     w.files.upload(
# MAGIC         lock_path,
# MAGIC         io.BytesIO(token.encode("utf-8")),
# MAGIC         overwrite=False
# MAGIC     )
# MAGIC ...
# MAGIC     # "release" lock
# MAGIC     w.files.delete(lock_path)
# MAGIC </code></pre>
# MAGIC
# MAGIC <link href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism.min.css" rel="stylesheet" />
# MAGIC <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"></script>
# MAGIC <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-python.min.js"></script>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### A2.2 Demonstrating the Solution
# MAGIC
# MAGIC A locking solution using files can be demonstrated using an included demo that implements the pattern highlighted above.
# MAGIC
# MAGIC Use the following links (each opens in a new tab) to open the "instances" and follow the instructions in the notebook.
# MAGIC - [Instance 1]($./concurrency/locking/Instance 1)
# MAGIC - [Instance 2]($./concurrency/locking/Instance 2)

# COMMAND ----------

# MAGIC %md
# MAGIC ### A3. Atomicity as a Solution
# MAGIC
# MAGIC An atomic operation is defined as one with an all-or-nothing outcome:
# MAGIC - Either every part of the operation was applied
# MAGIC - Or none of them was, as if the operation never happened
# MAGIC
# MAGIC There are no "partly done" states, and no partial results can leak to other instances. For example:
# MAGIC - a new row in a facts table that violates referential integrity
# MAGIC - balance debited in one table but not credited in another
# MAGIC
# MAGIC Since SQL queries (Delta or Lakebase) are atomic, the earlier challenge with persisting state could have easily been solved using a table as the backing store, since updates would be a single atomic operation, with no chance of being interrupted partway through.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>