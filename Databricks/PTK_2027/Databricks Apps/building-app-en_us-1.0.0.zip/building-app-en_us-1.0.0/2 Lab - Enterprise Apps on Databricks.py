# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](./Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab - Enterprise Apps on Databricks
# MAGIC
# MAGIC Modern enterprise applications must handle more than simple request/response interactions. They must:
# MAGIC - coordinate long-running work
# MAGIC - manage concurrency
# MAGIC - enforce security boundaries
# MAGIC - track state durably
# MAGIC - remain observable under failure conditions
# MAGIC
# MAGIC In this lab, we examine how these common enterprise concerns translate into Databricks-native architectural patterns. Using a reference RAG-based application as our working example, we explore how to design applications that behave reliably under real-world conditions — while leveraging Workflows, Unity Catalog, Volumes, and Model Serving Endpoints as core building blocks.
# MAGIC
# MAGIC The goal is not just to deploy a Databricks App, but to understand the architectural responsibilities that make it enterprise-ready.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lab, you will be able to:
# MAGIC - Map common web application challenges to Databricks-native solutions
# MAGIC - Explain how a Databricks App should coordinate asynchronous job execution while maintaining durable state and safe retry behavior
# MAGIC - Evaluate the architectural responsibilities of an enterprise-grade Databricks App beyond simple UI implementation

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ## A. Enterprise Application Concerns: A Comparative View
# MAGIC
# MAGIC Every enterprise web application faces the same core challenges. These challenges are not unique to Databricks — they are inherent to distributed systems.
# MAGIC
# MAGIC In traditional application architectures, these concerns are addressed using combinations of background workers, message queues, transactional databases, distributed locks, structured logging frameworks, and identity management systems.
# MAGIC
# MAGIC When building applications on Databricks Apps, we solve the same problems — but we do so using Databricks-native primitives such as Workflows (Jobs), Unity Catalog, Volumes, and Model Serving Endpoints.
# MAGIC
# MAGIC The table below maps common enterprise application concerns to both generic architectural approaches and their Databricks-native equivalents. This mapping will guide the implementation patterns we use throughout the remainder of this lab.
# MAGIC
# MAGIC <table>
# MAGIC   <thead>
# MAGIC     <tr>
# MAGIC       <th>Concern</th>
# MAGIC       <th>Challenge</th>
# MAGIC       <th>Typical approaches</th>
# MAGIC       <th>Databricks approach</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr>
# MAGIC       <td>Statelessness</td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>App instances come and go</li>
# MAGIC           <li>No local persistence</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>External state store (SQL Database/Redis)</li>
# MAGIC           <li>Sessions via signed cookies</li>
# MAGIC           <li>Shared cache</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>Tables (Delta or Lakebase)</li>
# MAGIC           <li>Files (UC Volumes)</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td>Long-running tasks</td>
# MAGIC       <td>Tasks take a long time relative to app expectations</td>
# MAGIC       <td>Queue + workers (Celery/RQ)</td>
# MAGIC       <td>Lakeflow jobs</td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td>Concurrency</td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>Extraneous clicks</li>
# MAGIC           <li>Retries</li>
# MAGIC           <li>multiple users</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>Distributed locks (Redis)</li>
# MAGIC           <li>Database transactions</li>
# MAGIC           <li>Unique constraints</li>
# MAGIC           <li>Idempotency keys</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>Idempotency keys + durable state checks</li>
# MAGIC           <li>Distributed locks (Delta/Lakebase)
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td>Idempotency</td>
# MAGIC       <td>Same request creates multiple side effects</td>
# MAGIC       <td>Idempotency key stored in database with unique constraint</td>
# MAGIC       <td>Persist request_id in Delta or Lakebase</td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td>Failures / partial state</td>
# MAGIC       <td>Partly created resources; stuck in between states</td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>State machine in database with compensation logic</li>
# MAGIC           <li>Retries with backoff</li>
# MAGIC           <li>dead-letter queue</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>Track state in Delta/Lakebase</li>
# MAGIC           <li>Job retries/timeout policies</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td>Security boundaries</td>
# MAGIC       <td>Secrets leak to browser, giving users unintended power</td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>AuthN/AuthZ</li>
# MAGIC           <li>Backend service identity</li>
# MAGIC           <li>Secret manager</li>
# MAGIC           <li>Least privilege</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>App service principle</li>
# MAGIC           <li>On-behalf-of user authentication</li>
# MAGIC           <li>UC and workspace permissions</li>
# MAGIC           <li>Databricks secrets</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td>Observability</td>
# MAGIC       <td>Answering questions like "What happened?" or "Who did this?"</td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>Structured logs</li>
# MAGIC           <li>Correlation IDs</li>
# MAGIC           <li>tracing (OpenTelemetry)</li>
# MAGIC           <li>Log aggregation</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC       <td>
# MAGIC         <ul>
# MAGIC           <li>Correlation ID (request_id) threaded through app + job</li>
# MAGIC           <li>Logs in app console</li>
# MAGIC           <li>Durable event table in Delta/Lakebase</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC <style>
# MAGIC table{
# MAGIC   border-collapse: separate;
# MAGIC   border-spacing: 0;
# MAGIC   width: auto;
# MAGIC   max-width: 100%;
# MAGIC   margin: 16px 0;
# MAGIC   float: none;
# MAGIC   clear: both;
# MAGIC   display: table;
# MAGIC   font-size: 0.95em;
# MAGIC   line-height: 1.35;
# MAGIC   background: #ffffff;
# MAGIC   border-radius: 8px;
# MAGIC   overflow: hidden;
# MAGIC   box-shadow: 0 0 0 1px #303F47;
# MAGIC   margin-left: 2px !important;
# MAGIC   margin-right: 2px !important;
# MAGIC   box-sizing: border-box !important;
# MAGIC }
# MAGIC thead th{
# MAGIC   background: #DADADA;
# MAGIC   color: #1B3139;
# MAGIC   font-weight: 600;
# MAGIC   text-align: left;
# MAGIC   padding: 10px 12px;
# MAGIC }
# MAGIC tbody td{
# MAGIC   padding: 10px 12px;
# MAGIC   border-top: 1px solid #DCE0E2;
# MAGIC }
# MAGIC tbody tr:nth-child(odd){
# MAGIC   background: #FFFFFF !important;
# MAGIC }
# MAGIC tbody tr:nth-child(even){
# MAGIC   background: #F5F3F2 !important;
# MAGIC }
# MAGIC </style>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## B. Preparing the Demo Platform
# MAGIC
# MAGIC In this lab, we work with a Databricks App that provides a front-end interface to a Retrieval-Augmented Generation (RAG) pipeline.
# MAGIC
# MAGIC What is a RAG pipeline? Simply put, it's an architectural pattern that enables an LLM to answer domain-specific questions without having to go to the expense and effort of tuning or retraining the model. With the RAG pipeline, you simply:
# MAGIC - Supply a **corpus** (a document or collection of documents related to a specific topic or domain)
# MAGIC - Update the index (an operation that is encapsulated in a Lakeflow job)
# MAGIC - Query the LLM, which relies on the index to find the information it needs to answer questions about the corpus
# MAGIC
# MAGIC Don't worry; this is all you need to know. You do NOT need to know AI, ML, or how RAG works to do this lab. We'll be working with simple app that will operationalize the RAG pipeline through three basic touchpoints:
# MAGIC - Manage input documents (upload/delete files)
# MAGIC - Invoke an asynchronous job to update the index
# MAGIC - Expose a chat interface to run plain language queries
# MAGIC
# MAGIC The RAG system is there to provide a realistic and useful backend workload — but the architectural patterns we explore apply equally to provisioning workflows, data pipelines, infrastructure orchestration, or any other long-running enterprise task.
# MAGIC
# MAGIC In other words, the AI system is simply the backdrop. The focus is enterprise application design.
# MAGIC
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC flowchart LR
# MAGIC subgraph APP_LAYER["Databricks Apps"]
# MAGIC direction TB
# MAGIC App@{ shape: rounded, label: "Demo App" }
# MAGIC end
# MAGIC subgraph STORAGE["UC Volume"]
# MAGIC direction TB
# MAGIC VOL@{ shape: st-rect, label: "Documents" }
# MAGIC end
# MAGIC subgraph EXECUTION["Lakeflow Jobs"]
# MAGIC direction TB
# MAGIC JOB["Update Index"]
# MAGIC style JOB fill:#000000,color:#FFFFFF
# MAGIC end
# MAGIC subgraph SERVING["Model Serving"]
# MAGIC direction TB
# MAGIC MODEL["RAG Chat"]
# MAGIC end
# MAGIC App -->|"upload/delete"| VOL
# MAGIC App -->|"start"| JOB
# MAGIC JOB -.->|"RAG"| MODEL
# MAGIC App -->|"query"| MODEL
# MAGIC VOL -.->|"read"| JOB
# MAGIC classDef plane fill:#F9F7F4,stroke:#303F47,color:#1B3139,stroke-width:1.5px
# MAGIC classDef app fill:#FF3621,stroke:#303F47,color:#FFFFFF,stroke-width:2px
# MAGIC classDef data fill:#FFAB00,stroke:#1B3139,color:#0B2026,stroke-width:2px
# MAGIC classDef runtime fill:#2272B4,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
# MAGIC class APP_LAYER,STORAGE,EXECUTION,SERVING plane
# MAGIC class U client
# MAGIC class App app
# MAGIC class VOL data
# MAGIC class MODEL runtime
# MAGIC linkStyle 0,1,2,3,4 stroke:#303F47,stroke-width:2px</div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 

# COMMAND ----------

# MAGIC %md
# MAGIC ### B1. Select Compute
# MAGIC
# MAGIC Use serverless compute to run the cells within this notebook. Before connecting, please:
# MAGIC - Verify in the **Environment** panel to the right that you are using *Standard v4* as the **Base environment**.<br/>
# MAGIC   ![Environment](./Includes/images/serverless_environment.png)
# MAGIC
# MAGIC - With settings applied, connect to a new serverless instance.<br/>
# MAGIC   ![Connect](./Includes/images/connect_serverless.png)
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B2. Run Setup
# MAGIC
# MAGIC <div style="
# MAGIC   border-left: 4px solid #ff9800;
# MAGIC   background: #fff3e0;
# MAGIC   padding: 14px 18px;
# MAGIC   border-radius: 4px;
# MAGIC   margin: 16px 0;
# MAGIC ">
# MAGIC   <strong style="display:block; color:#e65100; margin-bottom:6px; font-size: 1.1em;">
# MAGIC     Prerequisite
# MAGIC   </strong>
# MAGIC   <div style="color:#333;">
# MAGIC This setup requires specialized compute known as a <strong>Vector Search Endpoint</strong>. The Databricks Academy learning environment has these already set up, although you can verify by <a href="/compute/vector-search" target="_blank">checking here</a>. If you are working in an environment where there are none already set up, create one now by following <a href="https://docs.databricks.com/aws/en/vector-search/create-vector-search#create-a-vector-search-endpoint-using-the-ui" target="_blank">this document</a>.
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC Run the following cell, which sets up your environment. This will:
# MAGIC - Configure variables used throughout the notebooks
# MAGIC - Set up the infrastructure needed to support the RAG pipeline
# MAGIC - Create a blank Databricks App for you to work with
# MAGIC - Output important configuration information below
# MAGIC
# MAGIC <div style="
# MAGIC   border-left: 4px solid #1976d2;
# MAGIC   background: #e3f2fd;
# MAGIC   padding: 14px 18px;
# MAGIC   border-radius: 4px;
# MAGIC   margin: 16px 0;
# MAGIC ">
# MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size: 1.1em;">
# MAGIC     Please Be Patient
# MAGIC   </strong>
# MAGIC   <div style="color:#333;">
# MAGIC The setup may take a few minutes to complete the first time around.
# MAGIC   </div>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-2

# COMMAND ----------

# MAGIC %md
# MAGIC ### B3. Understanding the Output
# MAGIC The previous cell outputs some important pieces of information you'll need to configure your app:
# MAGIC - **Update Index Job**: the name of the job that updates the index. This job can be run [from the UI](/jobs?asset_type=jobs), but we'll also trigger it from the app.
# MAGIC - **Input Volume**: the file container where you upload documents (the corpus). You can manage the files using the [Catalog Explorer](/explore/data), but we'll also add management capability in the app.
# MAGIC - **Model Serving Endpoint**: exposes the LLM and makes it available for querying. You can query it [from the UI](/ml/endpoints), but we'll also integrate a chat client in the app.
# MAGIC - **App Name**: name of pre-created App for you to use.
# MAGIC - **App Source**: location of App source code.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B4. Using the RAG Pipeline (optional)
# MAGIC
# MAGIC You can perform all operational functions of the RAG pipeline directly from the workspace, as outlined in this section. You don't have to perform these functions like this now, since we'll build an app that will expose these functions. But if you want to explore and gain a deeper understanding of how the pipeline works, you can.
# MAGIC
# MAGIC 1. Use [Catalog Explorer](/explore/data) to upload or manage the files (images, PDFs) in the input volume named above.
# MAGIC 1. Locate the job named above in the [Jobs & Pipelines](/jobs?asset_type=jobs) page and run it.
# MAGIC 1. Once the job finishes, locate the model serving endpoint named above in the [Serving](/ml/endpoints) page and query it:
# MAGIC    - Click **Use** in the top-right corner
# MAGIC    - Replace the text (highlighted in the screenshot below) with a question of your own
# MAGIC    - Click **Send Request**
# MAGIC    - Look for answer within the **Response** area
# MAGIC
# MAGIC    ![Query](./Includes/images/query_endpoint.png)
# MAGIC
# MAGIC <div style="
# MAGIC   border-left: 4px solid #ff9800;
# MAGIC   background: #fff3e0;
# MAGIC   padding: 14px 18px;
# MAGIC   border-radius: 4px;
# MAGIC   margin: 16px 0;
# MAGIC ">
# MAGIC   <strong style="display:block; color:#e65100; margin-bottom:6px; font-size: 1.1em;">
# MAGIC     Model Serving Startup Time
# MAGIC   </strong>
# MAGIC   <div style="color:#333;">
# MAGIC After running the setup above, it can take 10 minutes or so for a new model serving endpoint to start up for the first time. You will not be able to query it during this time.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## C. Configure the App
# MAGIC
# MAGIC <div style="
# MAGIC   border-left: 4px solid #ff9800;
# MAGIC   background: #fff3e0;
# MAGIC   padding: 14px 18px;
# MAGIC   border-radius: 4px;
# MAGIC   margin: 16px 0;
# MAGIC ">
# MAGIC   <strong style="display:block; color:#e65100; margin-bottom:6px; font-size: 1.1em;">
# MAGIC     App Limitations
# MAGIC   </strong>
# MAGIC   <div style="color:#333;">
# MAGIC There's a limited number of app slots available in each workspace. So in this lab, we pre-create an app for you. Please work with this app; do not create additional ones. Creating more may prevent others in the learning environment from creating their own.
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC The app which we have pre-created for you is a blank slate. In this section we'll configure it to make it operational.
# MAGIC
# MAGIC Recall the app that was named in the setup cell output earlier; referring to that information:
# MAGIC 1. Go to the [**Apps** tab of the **Compute** page](/compute/apps).
# MAGIC 1. Locate the app that was named in the setup cell output earlier, and select it.
# MAGIC
# MAGIC <div style="
# MAGIC   border-left: 4px solid #f44336;
# MAGIC   background: #ffebee;
# MAGIC   padding: 14px 18px;
# MAGIC   border-radius: 4px;
# MAGIC   margin: 16px 0;
# MAGIC ">
# MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Note</strong>
# MAGIC   <div style="color:#333;">
# MAGIC     The app is not operational yet. While compute resources have been allocated, no actual code has been deployed yet so there is nothing to run.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C1. App Resources
# MAGIC
# MAGIC In a general web app setting, you must take care of supplying the additional resources your app may need to perform its functions. For example:
# MAGIC - If your app needs a table to persist state, you need to supply a database.
# MAGIC - If your app needs to be able to run long tasks asynchronously, you have to provide some sort of orchestration framework (like a task executor and a message queue).
# MAGIC
# MAGIC In Databricks, the platform supplies all these resources your app may need. They simply need to be exposed to the app. In this particular example, we will expose:
# MAGIC - the **input volume** that contains input documents to the RAG pipeline; app will expose file management over this collection
# MAGIC - the **job** that indexes the input files; app will expose a trigger to run the job to reindex a new collection of documents
# MAGIC - the **model serving endpoint**; app will provide a querying interface
# MAGIC - a **SQL warehouse**; app will use this to execute general SQL workloads and access Delta tables where needed
# MAGIC
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC flowchart LR
# MAGIC subgraph WS["Workspace"]
# MAGIC direction TB
# MAGIC VOL["Unity Catalog Volume"]
# MAGIC JOB["Lakeflow Job"]
# MAGIC END["Model serving endpoint"]
# MAGIC SQL["SQL warehouse"]
# MAGIC APP@{ shape: rounded, label: "App" }
# MAGIC end
# MAGIC APP -->|"list+create+delete"| VOL
# MAGIC APP -->|"trigger"| JOB
# MAGIC APP -->|"query"| END
# MAGIC APP -->|"execute DBSQL"| SQL
# MAGIC classDef plane fill:#F9F7F4,stroke:#303F47,color:#1B3139,stroke-width:1.5px
# MAGIC classDef client fill:#FF3621,stroke:#303F47,color:#FFFFFF,stroke-width:2px
# MAGIC classDef data fill:#FFAB00,stroke:#1B3139,color:#0B2026,stroke-width:2px
# MAGIC classDef runtime fill:#2272B4,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
# MAGIC class WS plane
# MAGIC class APP client
# MAGIC class VOL data
# MAGIC class JOB,END,SQL runtime
# MAGIC linkStyle 0,1,2,3 stroke:#303F47,stroke-width:2px
# MAGIC </div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 
# MAGIC
# MAGIC 1. In the main app page, click **Edit**.
# MAGIC 1. Click **Next: Configure** to advance to the resources page.
# MAGIC 1. Click **Add resource** to add the resources listed in the table below.
# MAGIC 1. When done, click **Save**.
# MAGIC
# MAGIC <table>
# MAGIC   <thead>
# MAGIC     <tr>
# MAGIC       <th>Resource type</th>
# MAGIC       <th>Resource name (from setup)</th>
# MAGIC       <th>Permission</th>
# MAGIC       <th>Resource key</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr>
# MAGIC       <td>UC volume</td>
# MAGIC       <td>Input Volume</td>
# MAGIC       <td>Can read and write</td>
# MAGIC       <td>volume</td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td>Job</td>
# MAGIC       <td>Update Index Job</td>
# MAGIC       <td>Can manage and run</td>
# MAGIC       <td>job</td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td>Serving endpoint</td>
# MAGIC       <td>Model Serving Endpoint</td>
# MAGIC       <td>Can query</td>
# MAGIC       <td>serving-endpoint</td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td>SQL warehouse</td>
# MAGIC       <td>Any available</td>
# MAGIC       <td>Can use</td>
# MAGIC       <td>sql-warehouse</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC <div style="
# MAGIC   border-left: 4px solid #1976d2;
# MAGIC   background: #e3f2fd;
# MAGIC   padding: 14px 18px;
# MAGIC   border-radius: 4px;
# MAGIC   margin: 16px 0;
# MAGIC ">
# MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size: 1.1em;">
# MAGIC     About the SQL Warehouse
# MAGIC   </strong>
# MAGIC   <div style="color:#333;">
# MAGIC In a real-world production scenario, you would set up a dedicated serverless SQL warehouse that is available at all times for app use, sized according to your app's needs. In this lab scenario, using any SQL warehouse you have available is sufficient.
# MAGIC   </div>
# MAGIC </div>
# MAGIC <style>
# MAGIC table{
# MAGIC   border-collapse: separate;
# MAGIC   border-spacing: 0;
# MAGIC   width: auto;
# MAGIC   max-width: 100%;
# MAGIC   margin: 16px 0;
# MAGIC   float: none;
# MAGIC   clear: both;
# MAGIC   display: table;
# MAGIC   font-size: 0.95em;
# MAGIC   line-height: 1.35;
# MAGIC   background: #ffffff;
# MAGIC   border-radius: 8px;
# MAGIC   overflow: hidden;
# MAGIC   box-shadow: 0 0 0 1px #303F47;
# MAGIC   margin-left: 2px !important;
# MAGIC   margin-right: 2px !important;
# MAGIC   box-sizing: border-box !important;
# MAGIC }
# MAGIC thead th{
# MAGIC   background: #DADADA;
# MAGIC   color: #1B3139;
# MAGIC   font-weight: 600;
# MAGIC   text-align: left;
# MAGIC   padding: 10px 12px;
# MAGIC }
# MAGIC tbody td{
# MAGIC   padding: 10px 12px;
# MAGIC   border-top: 1px solid #DCE0E2;
# MAGIC }
# MAGIC tbody tr:nth-child(odd){
# MAGIC   background: #FFFFFF !important;
# MAGIC }
# MAGIC tbody tr:nth-child(even){
# MAGIC   background: #F5F3F2 !important;
# MAGIC }
# MAGIC </style>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### C1.1 Resource-key Mapping
# MAGIC
# MAGIC Resources that are explicitly added to the app each have an associated **Resource key** which can then be mapped to an environment variable by your app's YAML file. Soon, we will see this mechanism in action.
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC flowchart LR
# MAGIC subgraph WS["Workspace"]
# MAGIC direction LR
# MAGIC RES@{ shape: processes, label: "Resources" }
# MAGIC subgraph APP["App"]
# MAGIC direction TB
# MAGIC YAML["app.yaml"]
# MAGIC CODE["App source code"]
# MAGIC end
# MAGIC end
# MAGIC RES -->|"keys"| YAML
# MAGIC style RES fill:#FF3621,color:#FFFFFF,stroke:#303F47
# MAGIC YAML -->|"env vars"| CODE
# MAGIC classDef plane fill:#F9F7F4,stroke:#303F47,color:#1B3139,stroke-width:1.5px
# MAGIC classDef runtime fill:#2272B4,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
# MAGIC classDef data fill:#FFAB00,stroke:#1B3139,color:#0B2026,stroke-width:2px
# MAGIC classDef app fill:#FF3621,stroke:#303F47,color:#FFFFFF,stroke-width:2px
# MAGIC class WS,APP plane
# MAGIC class YAML data
# MAGIC class CODE runtime
# MAGIC linkStyle 0,1 stroke:#303F47,stroke-width:2px
# MAGIC </div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C2. Configure Source
# MAGIC
# MAGIC Let's deploy source code to the app to make it operational.
# MAGIC
# MAGIC 1. Go to the [**Apps** tab of the **Compute** page](/compute/apps).
# MAGIC 1. Locate the app that was named in the setup cell output earlier, and select it.
# MAGIC 1. Click **Deploy**; this allows us to specify the location of the source code we want to deploy.
# MAGIC 1. In the **Create deployment** dialog, click the folder icon.
# MAGIC 1. Navigate to the App source, which was displayed in the setup cell output earlier.
# MAGIC 1. Click **Deploy**.
# MAGIC 1. After a few moments, the app will be ready to use.
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C3. App Usage
# MAGIC
# MAGIC Access the app through the provided URL. The user interface is divided into three columns:
# MAGIC 1. **Artifacts**: manage the input files.
# MAGIC    - Use the **Upload** area to select local files and click the **Save upload** button to upload them to the volume.
# MAGIC    - To delete, select a file from the dropdown and click the **Delete** button below.
# MAGIC 1. **Index**: rebuild the index and view status.
# MAGIC    - Click the **Rebuild index** button to trigger an index update, based on the files in the volume.
# MAGIC    - While an update is in progress, this button will be disabled. Use the **Refresh status** button to update the UI status periodically.
# MAGIC 1. **Chat**: when the index is ready, use the chat interface to submit plain language questions about the information contained in the documents.
# MAGIC
# MAGIC <div style="
# MAGIC   border-left: 4px solid #1976d2;
# MAGIC   background: #e3f2fd;
# MAGIC   padding: 14px 18px;
# MAGIC   border-radius: 4px;
# MAGIC   margin: 16px 0;
# MAGIC ">
# MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size: 1.1em;">
# MAGIC     What Documents to Upload?
# MAGIC   </strong>
# MAGIC   <div style="color:#333;">
# MAGIC The system currently accepts PDFs and images. In the interest of time, it's best to keep size and complexity to a minimum. If you can't think of any documents to use, refer to the appendix at the end of this notebook for some suggestions.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Web App Concerns
# MAGIC
# MAGIC In this section, we review some of the common big challenges concerning web apps that was summarized in the table at the beginning of this lab, and explore how we address these in the Databricks context.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D1. Security Boundaries
# MAGIC
# MAGIC In the **Authorization** tab for your app, notice that a service principal has been allocated to your app. This service principal constitutes the default identity under which your app will operate when accessing data or workspace resources. This constitutes the foundational piece of the security boundaries surrounding the App.
# MAGIC
# MAGIC Through this service principal, we can take advantage of Unity Catalog and workspace permissioning to maintain a clear security boundary for the app, as well as audit app behavior using standard observability functions built in to the workspace.
# MAGIC
# MAGIC 1. Navigate to the input volume in [Catalog Explorer](/explore/data).
# MAGIC    - In the **Permissions** tab, notice that the service principal has been granted `READ VOLUME` and `WRITE VOLUME`, allowing your app to do file management there.
# MAGIC    - Note also that the containing catalog and schema have `USE CATALOG` and `USE SCHEMA` respectively (these are pre-requisite permissions to access a volume in UC)
# MAGIC 1. Locate your job in the [Jobs & Pipelines](/jobs?asset_type=jobs) page.
# MAGIC    - In the **Permissions** area on the right-hand side, notice that the service principle has `Can Manage Run`, allowing your app to trigger the job. 
# MAGIC 1. Likewise, locate your model serving endpoint in the [Serving](/ml/endpoints) page.
# MAGIC    - Click **Permissions** at the top-right corner, and notice that the service principle has `Can Query`, allowing your app to query the endpoint. 
# MAGIC 1. Now, back in [Catalog Explorer](/explore/data), in the same schema as the volume, locate the model named `chatbot_model`.
# MAGIC    - In the **Permissions** tab, notice how the app service principal has no permissions. Even though this model is used indirectly by the app (through the model serving endpoint) direct access is not required.
# MAGIC
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC flowchart LR
# MAGIC subgraph WS["Workspace"]
# MAGIC direction TB
# MAGIC JOB["Lakeflow Job"]
# MAGIC END["Model serving endpoint"]
# MAGIC SQL["SQL warehouse"]
# MAGIC subgraph APP["App"]
# MAGIC SP["Service Principal"]
# MAGIC style SP fill:transparent,color:#FFFFFF,stroke-dasharray:2,2,stroke-width:2px,stroke:#303F47
# MAGIC end
# MAGIC end
# MAGIC subgraph MS["Data and AI Objects"]
# MAGIC VOL["Volume"]
# MAGIC TABLE@{ shape: div-rect, label: "Delta Table" }
# MAGIC end
# MAGIC WS -.- MS
# MAGIC SP -->|"READ VOLUME<br/>WRITE VOLUME"| VOL
# MAGIC SP -->|"CAN MANAGE RUN"| JOB
# MAGIC SP -->|"CAN QUERY"| END
# MAGIC SP -->|"CAN USE"| SQL
# MAGIC SQL -->|"SELECT<br/>MODIFY" | TABLE
# MAGIC classDef plane fill:#F9F7F4,stroke:#303F47,color:#1B3139,stroke-width:1.5px
# MAGIC classDef client fill:#FF3621,stroke:#303F47,color:#FFFFFF,stroke-width:2px
# MAGIC classDef data fill:#FFAB00,stroke:#1B3139,color:#0B2026,stroke-width:2px
# MAGIC classDef runtime fill:#2272B4,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
# MAGIC class WS,MS plane
# MAGIC class APP client
# MAGIC class VOL,TABLE data
# MAGIC class JOB,END,SQL runtime
# MAGIC linkStyle 0,1,2,3 stroke:#303F47,stroke-width:2px
# MAGIC </div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 
# MAGIC
# MAGIC In these instances, the permissions were all taken care of by Databricks when adding these resources to the app. But if you needed to grant additional access (for example, a table which the app would then access through a SQL warehouse), then you'd follow a similar model to grant the needed priliveges on the table.

# COMMAND ----------

# MAGIC %md
# MAGIC ### D2. Statelessness
# MAGIC
# MAGIC The statelessness property simply means that no state is maintained on the app side from request to request.
# MAGIC
# MAGIC Your app code may leverage temporary or session-based state to present content to the user; but if the user reloads the page, even only a second or two later, that state is completely gone and we must start from scratch.
# MAGIC
# MAGIC Although this is a drastic change from traditional stateful software design, it's not a difficult issue to resolve once you realize it's there. It requires rethinking how you code your app, while taking full advantage of the storage options you do have.
# MAGIC
# MAGIC In Databricks, there are several native ways to persist state, so that it can be immediately recalled on future requests.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### D2.1 Delta Tables
# MAGIC
# MAGIC Although designed and optimized for analytics workloads, Delta tables are still well suited for persisting structured data, like user inputs, preferences, or logs. Implementing this into your app requires:
# MAGIC - Access to a SQL warehouse to run SQL statements, since apps do not run on a Spark cluster and cannot use `spark.sql()` like in a notebook
# MAGIC - Applicable permissions on the target table (and containing schema and catalog)
# MAGIC
# MAGIC There are a few options for connecting to the SQL warehouse, depending on needs and preferences. Predominant options include:
# MAGIC - [Databricks SQL Connector](https://docs.databricks.com/aws/en/dev-tools/python-sql-connector) provides an interface that conforms to the Python DB API 2.0 specification
# MAGIC - [SQLAlchemy for Databricks](https://docs.databricks.com/aws/en/dev-tools/sqlalchemy) provides a suite of well known enterprise-level persistence patterns
# MAGIC - [Databricks SDK](https://docs.databricks.com/aws/en/dev-tools/sdk-python) provides an broad interface to all Databricks functionality, including interactions with SQL warehouses
# MAGIC
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC flowchart TB
# MAGIC subgraph WS["Workspace"]
# MAGIC direction TB
# MAGIC SQL["SQL warehouse"]
# MAGIC subgraph APP["App"]
# MAGIC SP["Service Principal"]
# MAGIC style SP fill:transparent,color:#FFFFFF,stroke-dasharray:2,2,stroke-width:2px,stroke:#303F47
# MAGIC end
# MAGIC end
# MAGIC subgraph MS["Data and AI Objects"]
# MAGIC TABLE@{ shape: div-rect, label: "Delta Table" }
# MAGIC end
# MAGIC SP -->|"CAN USE"| SQL
# MAGIC SP -->|"SELECT<br/>MODIFY" | TABLE
# MAGIC SQL -.-> TABLE
# MAGIC classDef plane fill:#F9F7F4,stroke:#303F47,color:#1B3139,stroke-width:1.5px
# MAGIC classDef client fill:#FF3621,stroke:#303F47,color:#FFFFFF,stroke-width:2px
# MAGIC classDef data fill:#FFAB00,stroke:#1B3139,color:#0B2026,stroke-width:2px
# MAGIC classDef runtime fill:#2272B4,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
# MAGIC class WS,MS plane
# MAGIC class APP client
# MAGIC class VOL,TABLE data
# MAGIC class JOB,END,SQL runtime
# MAGIC linkStyle 0,1,2 stroke:#303F47,stroke-width:2px
# MAGIC </div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### D2.2 Volumes
# MAGIC
# MAGIC Unity Catalog provides a persistent file store, ideal for stashing files and unstructured data. In fact, the example app included in the lab uses a volume as the major underpinning of its state store; it is where the RAG input files are stored. This files constitute the majority of the state of this app.
# MAGIC
# MAGIC Unlike tables, you do not need a SQL warehouse to interact with volumes. You only need applicable permissions (`READ VOLUME`, `WRITE VOLUME`).
# MAGIC
# MAGIC Direct file access is not available at the current time like it is in Spark clusters, so you need to use the [Databricks SDK](https://docs.databricks.com/aws/en/dev-tools/sdk-python).
# MAGIC
# MAGIC The following code from the included app exemplifies volume access through the SDK.
# MAGIC
# MAGIC <pre><code class="language-python">w = WorkspaceClient()
# MAGIC ...
# MAGIC def list_volume_files(root: str):
# MAGIC     items = w.files.list_directory_contents(directory_path=root)
# MAGIC     out = []
# MAGIC     for item in items:
# MAGIC         # skip directories
# MAGIC         if item.is_directory:
# MAGIC             continue
# MAGIC         out.append({
# MAGIC             "path": item.path,
# MAGIC             "name": item.name,
# MAGIC             "size": item.file_size,
# MAGIC             "mtime": item.last_modified
# MAGIC         })
# MAGIC
# MAGIC     return out
# MAGIC
# MAGIC def upload_file_to_volume(uploaded_file, root: str):
# MAGIC     dest_path = f"{root}/{uploaded_file.name}"
# MAGIC
# MAGIC     w.files.upload(dest_path, uploaded_file, overwrite=True)
# MAGIC     return dest_path
# MAGIC
# MAGIC def delete_file(path: str):
# MAGIC     w.files.delete(path)
# MAGIC </code></pre>
# MAGIC
# MAGIC <div style="
# MAGIC   border-left: 4px solid #ff9800;
# MAGIC   background: #fff3e0;
# MAGIC   padding: 14px 18px;
# MAGIC   border-radius: 4px;
# MAGIC   margin: 16px 0;
# MAGIC ">
# MAGIC   <strong style="display:block; color:#e65100; margin-bottom:6px; font-size: 1.1em;">
# MAGIC     Concurrency Alert
# MAGIC   </strong>
# MAGIC   <div style="color:#333;">
# MAGIC File operations in volumes are generally not atomic. To avoid concurrency issues, you may need to implement some from of mutual exclusion. For example, if your app writes configuration to a specific file, then all instances of your app will want to write to that file, possibly at the same time. To avoid contention, you will need to implement some form of file locking to avoid concurrent updates. 
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC <link href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism.min.css" rel="stylesheet" />
# MAGIC <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"></script>
# MAGIC <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-python.min.js"></script>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### D2.3 Lakebase
# MAGIC
# MAGIC At a glance, Lakebase appears to be similar to Delta tables, although beneath the surface the two mechanism are quite different.
# MAGIC
# MAGIC Lakebase provides PostgreSQL-compatible transactional database as Databricks resources. So like Delta tables, Lakebase provides tabular storage of structured data, just in a vastly different format that is specifically designed for operational, rather than analytical purposes.
# MAGIC
# MAGIC Implementing this into your app requires access to a Lakebase instance, which encompasses the compute and storage. No additional external privileges are required, although a role within the PosgreSQL database, as well as appropriate internal permissions, is required.
# MAGIC
# MAGIC There are a few options for connecting to a Lakebase instance, depending on needs and preferences. Predominant options include:
# MAGIC - [Psycopg3](https://www.psycopg.org/) is a PostgreSQL adapter that conforms to the Python DB API 2.0 specification
# MAGIC - [SQLAlchemy for Databricks](https://docs.databricks.com/aws/en/dev-tools/sqlalchemy) provides a suite of well known enterprise-level persistence patterns
# MAGIC
# MAGIC
# MAGIC <div class="mermaid" style="display:flex; justify-content:center;">
# MAGIC flowchart TB
# MAGIC subgraph WS["Workspace"]
# MAGIC direction LR
# MAGIC subgraph PG["Lakebase Instance"]
# MAGIC Role
# MAGIC style Role fill:transparent,color:#FFFFFF,stroke-dasharray:2,2,stroke-width:2px,stroke:#303F47
# MAGIC end
# MAGIC subgraph APP["App"]
# MAGIC SP["Service Principal"]
# MAGIC style SP fill:transparent,color:#FFFFFF,stroke-dasharray:2,2,stroke-width:2px,stroke:#303F47
# MAGIC end
# MAGIC end
# MAGIC SP -->|"CONNECT"| Role
# MAGIC classDef plane fill:#F9F7F4,stroke:#303F47,color:#1B3139,stroke-width:1.5px
# MAGIC classDef client fill:#FF3621,stroke:#303F47,color:#FFFFFF,stroke-width:2px
# MAGIC classDef data fill:#FFAB00,stroke:#1B3139,color:#0B2026,stroke-width:2px
# MAGIC classDef runtime fill:#2272B4,stroke:#1B3139,color:#FFFFFF,stroke-width:2px
# MAGIC class WS plane
# MAGIC class APP client
# MAGIC class PG runtime
# MAGIC linkStyle 0 stroke:#303F47,stroke-width:2px
# MAGIC </div>
# MAGIC <script type="module">
# MAGIC import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
# MAGIC </script> 
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D3. Long-running Tasks
# MAGIC
# MAGIC You never run long-running work inside the request/response path in an app, for a couple of good reasons:
# MAGIC - leaves the browser stalled, giving the appearance of the app being frozen or broken
# MAGIC - app compute is optimized for UI service, not long batch jobs
# MAGIC
# MAGIC Minimal solution:
# MAGIC - Factor out lengthy tasks and wrap them up into a Lakeflow job. [Lakeflow jobs](https://docs.databricks.com/aws/en/jobs/) provides sophisticated task orchestration and supports a variety of task formats.
# MAGIC - Add the job as an app resource
# MAGIC - Use [Databricks SDK](https://docs.databricks.com/aws/en/dev-tools/sdk-python) to trigger the job when needed. 
# MAGIC
# MAGIC A more complete solution would include:
# MAGIC - polling from the app side to update the UI; app can poll using the API or a status table if the job is logging to one
# MAGIC - threading information such as a request_id and user_id to the job for it to include in its logging, for end-to-end observability
# MAGIC
# MAGIC The following code from the included app exemplifies job triggering through the SDK.
# MAGIC
# MAGIC <pre><code class="language-python">INDEX_JOB_ID = os.getenv("DATABRICKS_JOB")
# MAGIC ...
# MAGIC w = WorkspaceClient()
# MAGIC ...
# MAGIC   token = st.session_state.index_idempotency_token
# MAGIC   if not token:
# MAGIC       token = str(uuid.uuid4())
# MAGIC       st.session_state.index_idempotency_token = token
# MAGIC       st.session_state.index_triggered_at = time.time()
# MAGIC
# MAGIC   try:
# MAGIC       with st.spinner("Triggering index rebuild job..."):
# MAGIC           run = w.jobs.run_now(
# MAGIC               job_id=INDEX_JOB_ID,
# MAGIC               idempotency_token=token,
# MAGIC               notebook_params={"VOLUME_PATH": VOLUME_PATH},
# MAGIC           )
# MAGIC       st.session_state.index_run_id = run.run_id
# MAGIC       st.success(f"Triggered rebuild (run_id={run.run_id}).")
# MAGIC </code></pre>
# MAGIC
# MAGIC <link href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism.min.css" rel="stylesheet" />
# MAGIC <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"></script>
# MAGIC <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-python.min.js"></script>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Appendix: Suggested Documents
# MAGIC
# MAGIC If you don't have any documents to use, consider downloading one of these resources to upload into the app.
# MAGIC
# MAGIC - [Standard Operating Procedures of Hand Tools](https://www.tri-c.edu/programs/engineering-technology/manufacturing-engineering/documents/cuyahoga-community-college-ideation-station-hand-tools-standard-operating-procedures.pdf) by Coyuhoga Community College
# MAGIC - [GenerLink documentation](https://globalpowerproducts.com/transfer-switches/generlink-transfer-switch/) by Global Power Products
# MAGIC
# MAGIC <div style="
# MAGIC   border-left: 4px solid #1976d2;
# MAGIC   background: #e3f2fd;
# MAGIC   padding: 14px 18px;
# MAGIC   border-radius: 4px;
# MAGIC   margin: 16px 0;
# MAGIC ">
# MAGIC   <strong style="display:block; color:#0d47a1; margin-bottom:6px; font-size: 1.1em;">
# MAGIC     Note
# MAGIC   </strong>
# MAGIC   <div style="color:#333;">
# MAGIC Currently the system is configured to generate responses in English only.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>