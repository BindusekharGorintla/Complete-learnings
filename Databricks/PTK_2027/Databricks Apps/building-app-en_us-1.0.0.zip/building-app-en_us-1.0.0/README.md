# Building Enterprise Grade Apps with Databricks

<!-- Replace the template below with information for your lab(s) -->
| Field           | Details       | Description                                                                 |
|-----------------|---------------|-----------------------------------------------------------------------------|
| Duration        | 60 minutes   | Estimated duration to complete the lab(s). |
| Level           | 200 | Target difficulty level for participants (100 = beginner, 200 = intermediate, 300 = advanced). |
| Lab Status      | Active | See descriptions in main repo README. |
| Course Location | N/A           | Indicates where the lab is hosted. <br> - **N/A** - Lab is only available in this repo. <br> - **Course name** - Lab has been moved into a full Databricks Academy course. |
| Developer       | David LeBlanc | Primary developer(s) of the lab, separated by commas.  |
| Reviewer        | Gourav Prajapati | Subject matter expert reviewer(s), separated by commas.|
| Product Version         | N/A          | Specify a product version if applicable If not, use **N/A**. | 
---

## Description  
This hands-on workshop explores how to design and implement enterprise-grade web applications using Databricks Apps as the orchestration and control plane. The focus is on real-world application concerns such as asynchronous execution, concurrency control, idempotency, durable state management, and secure resource access — all within a governed Databricks environment.

Participants work with a reference AI-powered application that coordinates long-running operations including document indexing, job orchestration, and model serving. Through guided exercises and instructor walkthroughs, learners examine how traditional web application challenges translate into Databricks-native architectural patterns.

The workshop covers three primary dimensions of enterprise application design on Databricks:
- Handling long-running and asynchronous operations using Databricks Workflows (Jobs)
- Managing concurrency, retries, and idempotency in a stateless application environment
- Securely connecting applications to Unity Catalog resources, Volumes, and Model Serving Endpoints

Through exercises, learners configure and wire application resources using YAML-based configuration, validate secure access to governed data assets, and observe how application code launches and tracks durable job execution. Instructor walkthroughs highlight how enterprise patterns such as request correlation, polling strategies, and failure handling are implemented in practice.

Key technical topics include async job orchestration from an application layer, idempotent request handling using durable state, structured logging and observability patterns, resource scoping with Unity Catalog permissions, and integration of retrieval-augmented generation (RAG) pipelines backed by Databricks model serving.

By the end of the workshop, participants understand not only how to deploy a Databricks App, but how to design one that behaves reliably under real-world enterprise conditions.


## Learning Objectives
- Work within Databricks Apps environmental constraints
- Apply best practices for security and permission management
- Troubleshoot common deployment and connectivity issues
- Apply fundamental app design and maintenance techniques

## Requirements & Prerequisites  
<!-- Example list below – update or replace with the specific requirements for your lab -->
Before starting this lab, ensure you have:  
- A Databricks workspace  
- A SQL warehouse (with `CAN MANAGE` permission)
- A vector search endpoint
- Catalog you own (or have `MANAGE` permission on) in Unity Catalog, or ability to create a catalog  


## Contents  
<!-- Replace the example below with the actual files included in your lab -->
This repository includes: 
- **1 Lecture - Reality of Web apps** notebook 
- **2 Lab - Enterprise Apps on Databricks** notebook
- **3 Lab - Enterprise Reliability Patterns in Databricks** notebook
- **rag_app** folder containing a working example app


## Getting Started  
<!-- Replace the example below with the actual files included in your lab -->
1. Open the main lecture notebook (for example, **1 Lecture - Reality of Web apps**).  
1. Follow the content.  
1. Open the **2 Lab - Enterprise Apps on Databricks** notebook and follow the instructions.
1. Repeat for any remaining lab notebooks listed in *Contents*. 
